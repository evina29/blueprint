/* Bing's Blueprint: paper slip scanner.
   Staff photograph a handwritten order form; Claude reads it into a digital
   order and the slip photo stays attached as the original record. */

const scan = { img: null, blob: null, busy: false, sample: null };

function sampleSlipData() {
  const iso_ = nextWeekday('saturday');
  const dt = parseDay(iso_);
  return {
    name: 'Margaret Russo', phone: '302-555-0177', date: `${dt.getMonth() + 1}/${dt.getDate()} (Sat)`, time: '2:00 pm',
    size: '16 ppl', flavor: 'Vanilla', filling: 'Cannoli cream', decor: 'pink rosettes + fresh berries',
    writing: 'Happy 80th Nonna', allergy: 'none', price: '~$95', taken: 'K.M.',
  };
}

async function drawSampleSlip() {
  const s = sampleSlipData();
  try { await document.fonts.load('40px "Caveat"'); } catch (e) { /* fall back to a script font */ }
  const W_ = 900, H_ = 1120;
  const c = document.createElement('canvas');
  c.width = W_; c.height = H_;
  const g = c.getContext('2d');
  g.fillStyle = '#f6f0e1'; g.fillRect(0, 0, W_, H_);
  g.fillStyle = 'rgba(120, 90, 40, .05)';
  for (let i = 0; i < 60; i++) g.fillRect(Math.random() * W_, Math.random() * H_, 2 + Math.random() * 40, 1);
  g.fillStyle = '#2a2a2a'; g.textAlign = 'center';
  g.font = '600 38px Georgia, serif'; g.fillText('CAKE ORDER FORM', W_ / 2, 78);
  g.font = 'italic 20px Georgia, serif'; g.fillStyle = '#777'; g.fillText('Sample slip made up for this demo', W_ / 2, 112);
  g.textAlign = 'left';
  const rows = [['Name', s.name], ['Phone', s.phone], ['Pickup date', s.date], ['Pickup time', s.time], ['Size / servings', s.size],
    ['Flavor', s.flavor], ['Filling', s.filling], ['Decorations', s.decor], ['Writing on cake', s.writing], ['Allergies', s.allergy],
    ['Price quoted', s.price], ['Taken by', s.taken]];
  let y = 186;
  rows.forEach(([lab, val], i) => {
    g.fillStyle = '#555'; g.font = '19px Arial, sans-serif'; g.fillText(lab.toUpperCase(), 56, y);
    g.strokeStyle = '#a9a294'; g.lineWidth = 1.2; g.beginPath(); g.moveTo(286, y + 8); g.lineTo(W_ - 56, y + 8); g.stroke();
    g.save(); g.translate(298 + (i % 3) * 4, y - 1); g.rotate(((i * 37) % 7 - 3) * 0.006);
    g.fillStyle = '#1f3c88'; g.font = '44px "Caveat", "Segoe Script", "Bradley Hand", cursive'; g.fillText(val, 0, 0); g.restore();
    y += 76;
  });
  g.strokeStyle = 'rgba(0,0,0,.07)'; g.lineWidth = 3; g.beginPath(); g.moveTo(0, H_ * 0.52); g.lineTo(W_, H_ * 0.52 + 10); g.stroke();
  const text = `${s.size} ${s.flavor}, ${s.filling} filling, ${s.decor}. Write "${s.writing}". Saturday ${s.time.replace(':00', '')}. Allergies ${s.allergy}. ${s.name} ${s.phone}. Budget about $95`;
  const blob = await new Promise((res) => c.toBlob(res, 'image/jpeg', 0.85));
  return { blob, url: c.toDataURL('image/jpeg', 0.6), text };
}

function viewScan() {
  const canRead = !!(AI && AI_IMAGES);
  return `<div class="row" style="margin-bottom:16px"><a class="back" href="#staff">← All orders</a></div>
  <div class="page-head"><div><span class="eyebrow">Switching from paper</span><h1>Scan a paper slip</h1></div></div>
  <p class="muted" style="margin-top:-10px;max-width:48em">Take a photo of a handwritten order form. ${canRead ? 'Claude' : 'The AI'} reads the handwriting and fills in a digital order, and the photo of the slip stays attached as the original record. On day one, every slip already in the pickup box gets a Cake Passport.</p>
  <div class="split">
    <div class="card scan-stage">
      ${scan.img ? `<img class="slip-img" src="${esc(scan.img)}" alt="Photo of the paper order slip">` : `<div class="slip-empty"><b>No slip yet</b><span class="small muted">Take a photo of a paper order form, or use the sample.</span></div>`}
      <div class="row" style="margin-top:16px">
        <label class="btn" for="scan-file" style="margin:0">${scan.img ? 'Use a different photo' : 'Take or choose a photo'}</label>
        <input id="scan-file" type="file" accept="image/*" hidden onchange="Scan.pick(this.files)">
        <button class="textlink small" onclick="Scan.useSample()">Use the sample slip</button>
      </div>
    </div>
    <div class="card">
      <span class="label">How it works</span>
      <ol class="small q-next"><li>${canRead ? 'Claude' : 'The AI'} reads every field on the slip, even messy handwriting.</li><li>You check the filled form against the slip, side by side.</li><li>Save. The slip photo stays on the order as the original.</li></ol>
      <button class="btn-primary btn-big btn-block" style="margin-top:18px" onclick="Scan.read()" ${!scan.img || scan.busy ? 'disabled' : ''}>${scan.busy ? (canRead ? 'Claude is reading the slip…' : 'Reading…') : 'Read the slip'}</button>
      ${canRead ? '' : `<p class="small muted" style="margin:14px 0 0">Reading handwriting needs the AI, which runs on the published page. Here, the sample slip is filled from its known text, and your own photos are attached so you can type from them.</p>`}
    </div>
  </div>`;
}

const Scan = {
  async pick(files) {
    const f = files && files[0];
    if (!f) return;
    try { scan.img = await resizeImage(f); scan.blob = f; scan.sample = null; } catch (e) { toast('That file could not be read as an image.'); return; }
    render();
  },
  async useSample() {
    const s = await drawSampleSlip();
    scan.img = s.url; scan.blob = s.blob; scan.sample = s.text;
    render();
  },
  async read() {
    if (!scan.img || scan.busy) return;
    scan.busy = true; render();
    const d = newDraft(true);
    d.channel = 'counter'; d.lane = 'yellow'; d.photos = [scan.img];
    let f = null, note = '', fromAI = false;
    if (AI && AI_IMAGES && scan.blob) {
      const today = parseDay(todayISO()).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      const prompt = `The attached image is a photo of a handwritten bakery cake order form. Read every field and turn it into the order form below. Reply with ONLY a JSON object:
{"name": string, "phone": "XXX-XXX-XXXX" or "", "pickupDate": "YYYY-MM-DD" or "", "pickupTime": one of ${JSON.stringify(PICKUP_TIMES)} or "",
 "lane": "green" | "yellow" | "red", "menu": {"<menu id>": quantity}, "servings": number, "flavor": string, "filling": string, "frosting": string,
 "addons": [decoration ids], "message": string, "event": string, "approxServings": number,
 "budget": number | null (use the quoted price if one is written), "allergy": string ("" if none), "description": "the design notes in one clean sentence",
 "summary": "one short sentence describing the order", "unclear": ["fields you could not read confidently"]}
Map what is written to the closest listed option (ppl = servings, a written time after noon = afternoon). Use only the ids and names listed. Today is ${today}.
${rateCardText()}`;
      try { f = await AI.json(prompt, { images: [scan.blob], modelTier: 'default' }); fromAI = true; }
      catch (e) { note = AI_ERR[e && e.code] || 'The AI could not read this photo. Type the details from the slip.'; f = null; }
    }
    if (!f && scan.sample) {
      f = Object.assign(localFill(expandShorthand(scan.sample)), localContact(scan.sample));
      note = note || 'AI isn’t available here, so the sample slip was filled from its known text.';
    }
    if (f && typeof f === 'object') {
      applyFill(d, f);
      if (f.name) d.name = String(f.name).slice(0, 60);
      if (f.phone && digits(f.phone).length === 10) d.phone = fmtPhone(f.phone);
      if (PICKUP_TIMES.includes(f.pickupTime)) d.pickupTime = f.pickupTime;
      if (f.description) d.description = String(f.description).slice(0, 400);
      d.aiNote = `${fromAI ? 'Claude read the slip' : 'Read from the slip'}: ${String(f.summary || '').replace(/^We set up /, '').slice(0, 160)}`;
      const unclear = (Array.isArray(f.unclear) ? f.unclear : []).slice(0, 3).map((x) => `Hard to read: ${String(x).slice(0, 60)}. Check it on the slip.`);
      d.aiQuestions = unclear.length ? unclear : (Array.isArray(f.questions) ? f.questions.slice(0, 2) : []);
    } else {
      d.aiNote = 'The slip photo is attached. Type the details from it below.';
      d.aiQuestions = [];
    }
    d.step = 0;
    drafts.staff = d;
    scan.busy = false; scan.img = null; scan.blob = null; scan.sample = null;
    go('#staff-new');
    if (note) toast(note);
  },
};

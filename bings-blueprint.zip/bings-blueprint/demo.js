/* Bing's Blueprint: presenter mode.
   A small bar with the five demo steps in order. Click a step or press 1-5
   (→ for the next step). Shift+D toggles it; opening the link with #demo turns it on. */

const DEMO_KEY = 'bb-demo';
let demoOn = (() => { try { return localStorage.getItem(DEMO_KEY) === '1'; } catch (e) { return false; } })();

function demoOrderForApproval() {
  return db.orders.find((o) => o.status === 'received' && o.lane === 'yellow' && !o.quotes.length)
    || db.orders.find((o) => o.lane === 'yellow' && o.status !== 'picked_up');
}

const DEMO_STEPS = [
  { label: 'Counter', is: (r) => r === 'counter', open() { counterQ = ''; go('#counter'); } },
  { label: 'Paper slip', is: (r) => r === 'staff-scan' || (r === 'staff-new' && drafts.staff && drafts.staff.photos && drafts.staff.photos.length), open() { scan.img = null; scan.blob = null; scan.sample = null; scan.busy = false; go('#staff-scan'); } },
  {
    label: 'Cake preview', is: (r) => r === 'order',
    open() {
      const d = newDraft(false);
      Object.assign(d, { lane: 'yellow', step: 1, servings: 12, flavor: 'Chocolate', filling: 'Chocolate mousse', frosting: 'White', addons: ['message', 'rosettes'], message: 'Happy Birthday Mom' });
      drafts.customer = d;
      go('#order');
    },
  },
  {
    label: 'Baker approves', is: (r) => r.startsWith('staff-order-'),
    open() {
      const o = demoOrderForApproval();
      if (!o) { toast('No custom order to show. Press Reset first.'); return; }
      delete assist[o.id]; qb = null; msgTab = 'customer';
      go('#staff-order-' + o.id);
    },
  },
  { label: 'Owner', is: (r) => r === 'owner', open() { briefText = ''; go('#owner'); } },
];

function demoCurrent() { const r = route(); return DEMO_STEPS.findIndex((s) => s.is(r)); }

function renderDemoBar() {
  let bar = document.getElementById('demobar');
  if (!demoOn) { if (bar) bar.remove(); return; }
  if (!bar) { bar = document.createElement('div'); bar.id = 'demobar'; bar.className = 'demobar no-print'; document.body.appendChild(bar); }
  const cur = demoCurrent();
  bar.innerHTML = `<span class="demobar-label">Demo</span>
    ${DEMO_STEPS.map((s, i) => `<button class="${i === cur ? 'on' : ''}" onclick="Demo.step(${i})" title="Press ${i + 1}"><b>${i + 1}</b>${s.label}</button>`).join('')}
    <span class="demobar-sep"></span>
    <button onclick="Demo.warm()" title="Ask for AI permission now, before you present">Warm up AI</button>
    <button onclick="Demo.reset()" title="Fresh sample orders for today">Reset</button>
    <button onclick="Demo.toggle(false)" aria-label="Hide presenter bar" title="Shift+D">✕</button>`;
}

const Demo = {
  step(i) { const s = DEMO_STEPS[i]; if (s) s.open(); setTimeout(renderDemoBar, 0); },
  next() { const c = demoCurrent(); Demo.step(Math.min(DEMO_STEPS.length - 1, c + 1)); },
  toggle(on) {
    demoOn = on == null ? !demoOn : !!on;
    try { localStorage.setItem(DEMO_KEY, demoOn ? '1' : '0'); } catch (e) { /* this view only */ }
    renderDemoBar();
    if (demoOn) toast('Presenter mode on. Press 1–5 or → to move through the demo.');
  },
  async warm() {
    if (!AI) { toast('The AI runs on the published page. Here the built-in reader takes over.'); return; }
    toast('Asking Claude…');
    try {
      await AI('Reply with exactly one word: ready', { modelTier: 'quick', cache: false });
      toast('AI is ready. No permission prompt will appear during the demo.');
    } catch (e) {
      toast(e && e.code === 'not_granted' ? 'AI was not allowed. Turn it on in this page’s permissions.' : 'Claude did not answer. Have the backup video ready.');
    }
  },
  async reset() {
    if (!(await ask('Reset every order to fresh sample data for today? Use this right before you present.', { ok: 'Reset demo data' }))) return;
    db = seed(); save();
    qb = null; drafts.customer = drafts.staff = null; verified.clear(); trackResult = null;
    counterQ = ''; Object.assign(scan, { img: null, blob: null, sample: null, busy: false });
    Object.keys(assist).forEach((k) => delete assist[k]);
    briefText = '';
    toast('Fresh demo data is ready. Taylor’s cake is ready for pickup today.');
    Demo.step(0);
  },
};

window.addEventListener('hashchange', () => setTimeout(renderDemoBar, 0));
document.addEventListener('keydown', (e) => {
  const a = document.activeElement;
  const typing = a && (/^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) || a.isContentEditable);
  if (typing || e.ctrlKey || e.metaKey || e.altKey) return;
  if (e.shiftKey && (e.key === 'D' || e.key === 'd')) { e.preventDefault(); Demo.toggle(); return; }
  if (!demoOn || e.shiftKey) return;
  if (/^[1-9]$/.test(e.key) && +e.key <= DEMO_STEPS.length) { e.preventDefault(); Demo.step(+e.key - 1); }
  else if (e.key === 'ArrowRight') { e.preventDefault(); Demo.next(); }
});
if (route() === 'demo') { demoOn = true; try { localStorage.setItem(DEMO_KEY, '1'); } catch (e) { /* ignore */ } counterQ = ''; location.replace('#counter'); }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', renderDemoBar); else renderDemoBar();

# Bing's Blueprint (prototype)

Plain HTML/CSS/JS. No build step, no accounts, no server code. Open `index.html` through any static host.

**Run locally:** `python -m http.server 8130` in this folder, then open http://localhost:8130

**Data:** saved in the browser's localStorage, so it survives a refresh. Open the Customer, Staff and
Kitchen views in separate tabs of the same browser and they update live. Different devices do NOT share
data (that would need a database; see "Next step" below). Staff → "Reset demo data" restores the
10 fictional sample orders.

## Screens
| URL | What it shows |
|---|---|
| `#/` | Customer home: Order, Track / reorder, Call me instead |
| `#/order` | 5-step order form: lane, details, own words + photos + budget + allergies, pickup, review |
| `#/track` | Find orders by phone, "Order again" (same as last year) |
| `#/passport/BB-xxxx` | Customer's Cake Passport: tracker, quote, Approve / Suggest a change, messages |
| `#/staff` | Search by ID / name / phone / pickup date, flags, overdue replies, CSV export |
| `#/staff/new` | Phone/counter entry with the same form, plus an entry timer for the time trial |
| `#/staff/order/BB-xxxx` | Quote builder (Design Score 1–5, editable lines), version history, chat + internal notes, edits, history log |
| `#/staff/box` | Pickup Box: 14-day calendar by pickup date |
| `#/staff/rates` | Rate card the owner edits |
| `#/kitchen` | Approved orders only: To bake → Baking → Ready |
| `#/print/DATE` | 6:30 AM Pickup Sheet, printable backup |

## 90-second demo path (slide 6)
1. Customer → Order a cake → **Custom** → 12 servings, Chocolate, drip + berries + **fondant flowers**.
2. Describe it, add a photo, budget **$100**. Tap **Apply** on "Buttercream rosettes instead of fondant". Estimate shows $100–$125.
3. Pickup + contact → Send. Show the Cake Passport number.
4. Staff tab → the new order is at the top → Design Score **3** → total **$112** → add a note → Send quote.
5. Kitchen tab: the order is NOT there yet.
6. Customer tab → Track → phone → Approve $112.
7. Kitchen tab: it's now in "To bake". Refresh the page and search the number: still there.

Bonus rule to show: revise the price on an approved order and it leaves the kitchen until the customer re-approves.

## Prototype limits (say these honestly if asked)
- No login on the Staff/Kitchen views; a real version would use staff accounts.
- No real texts/emails or payments; the deposit is a checkbox.
- localStorage only. For a real pilot, use the same workflow in a no-code tool (Airtable/Jotform) or
  connect a hosted database.

/* Bing's edition: settings loaded before app.js (local presentation copy only).
   Menu items and prices are taken from bingsbakery.com (November 2026). */
window.BB_BRAND = {
  name: 'Bing’s Bakery',
  rates: {
    flavors: [
      { name: 'Yellow', price: 0 }, { name: 'Chocolate', price: 0 }, { name: 'Vanilla', price: 0 },
      { name: 'Red velvet', price: 0 }, { name: 'Lemon', price: 0 },
    ],
    fillings: [
      { name: 'Cannoli cream', price: 0 }, { name: 'Vanilla custard', price: 0 }, { name: 'Raspberry', price: 0 },
      { name: 'Chocolate mousse', price: 0 }, { name: 'German chocolate', price: 0 }, { name: 'Peanut butter', price: 0 },
      { name: 'Cookies and cream', price: 0 }, { name: 'Buttercream', price: 0 },
    ],
    menu: [
      { id: 'cannoli', label: 'Cannoli Petit Cake (serves 8)', price: 28 },
      { id: 'boston', label: 'Boston Cream Petit Cake', price: 25 },
      { id: 'chocrasp', label: 'Chocolate Raspberry Petit Cake', price: 25 },
      { id: 'germanchoc', label: 'German Chocolate Petit Cake', price: 25 },
      { id: 'tiramisu', label: 'Tiramisu cake (serves 10)', price: 50 },
      { id: 'cupcake', label: 'Monster Cupcake (each)', price: 3 },
      { id: 'rainbow', label: 'Italian Rainbow Cookies (small)', price: 8.48 },
      { id: 'pumpkinpie', label: 'Pumpkin Pie, 9 inch (serves 10)', price: 17.95 },
      { id: 'pumpkinroll', label: 'Pumpkin Roll', price: 20 },
    ],
  },
};

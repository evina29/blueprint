/* Bing's Blueprint: 3D motion layer.
   Turntable cake (drag to spin), tilt cards, hero depth and screen entrances.
   Everything here is skipped for viewers who ask for reduced motion. */

const REDUCED = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

/* ---------- turntable cake ---------- */
const cakeReg = new Map();
let cakeSeq = 0;
const _cakeSVG = cakeSVG;
cakeSVG = function (lane, spec, opts = {}) {
  const html = _cakeSVG(lane, spec, opts);
  if (!html) return html;
  const id = 'c' + (++cakeSeq);
  cakeReg.set(id, { lane, spec: JSON.parse(JSON.stringify(spec || {})), opts: { ...opts }, offset: 0 });
  return html.replace('<svg ', `<svg data-cake="${id}" `);
};
const spin = { t0: performance.now(), last: 0, drag: null };
const autoRot = (now) => (REDUCED ? 0 : (now - spin.t0) * 0.00045);
function paintCake(el, rot) {
  const r = cakeReg.get(el.dataset.cake);
  if (!r) return;
  const full = _cakeSVG(r.lane, r.spec, { ...r.opts, rot });
  el.innerHTML = full.slice(full.indexOf('>') + 1, full.lastIndexOf('</svg>'));
}
function spinFrame() {
  const now = performance.now();
  if (document.hidden) return;
  if (REDUCED && !spin.drag) return;
  spin.last = now;
  document.querySelectorAll('svg[data-cake]').forEach((el) => {
    const r = cakeReg.get(el.dataset.cake);
    if (!r) return;
    paintCake(el, spin.drag && spin.drag.id === el.dataset.cake ? spin.drag.rot : autoRot(now) + r.offset);
  });
}
setInterval(spinFrame, 33);
setInterval(() => {
  const live = new Set([...document.querySelectorAll('svg[data-cake]')].map((el) => el.dataset.cake));
  [...cakeReg.keys()].forEach((k) => { if (!live.has(k)) cakeReg.delete(k); });
}, 5000);
document.addEventListener('pointerdown', (e) => {
  const el = e.target.closest && e.target.closest('svg[data-cake]');
  if (!el) return;
  const r = cakeReg.get(el.dataset.cake);
  if (!r) return;
  const now = performance.now();
  spin.drag = { id: el.dataset.cake, x: e.clientX, start: autoRot(now) + r.offset, rot: autoRot(now) + r.offset };
  el.classList.add('grabbing');
  try { el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
});
document.addEventListener('pointermove', (e) => {
  if (!spin.drag) return;
  spin.drag.rot = spin.drag.start + (e.clientX - spin.drag.x) * 0.014;
});
const endDrag = () => {
  if (!spin.drag) return;
  const r = cakeReg.get(spin.drag.id);
  if (r) r.offset = spin.drag.rot - autoRot(performance.now());
  document.querySelectorAll('svg.grabbing').forEach((el) => el.classList.remove('grabbing'));
  spin.drag = null;
};
document.addEventListener('pointerup', endDrag);
document.addEventListener('pointercancel', endDrag);

/* ---------- tilt cards + hero depth ---------- */
const TILT_SEL = '.tile, .lane-card, .kpi, .stub, .counter-row, .ticket, .cake-card, .stat, .wh-card';
if (!REDUCED && window.matchMedia && window.matchMedia('(hover: hover)').matches) {
  document.documentElement.classList.add('tilt-on');
  let cur = null;
  const reset = (el) => { el.classList.remove('tilting'); el.style.removeProperty('--rx'); el.style.removeProperty('--ry'); };
  document.addEventListener('pointermove', (e) => {
    if (spin.drag) return;
    const el = e.target.closest ? e.target.closest(TILT_SEL) : null;
    if (cur && cur !== el) reset(cur);
    cur = el;
    if (el) {
      const b = el.getBoundingClientRect();
      const px = (e.clientX - b.left) / b.width - 0.5, py = (e.clientY - b.top) / b.height - 0.5;
      const max = el.matches('.tile, .stub, .cake-card') ? 7 : 4;
      el.style.setProperty('--ry', (px * max * 2).toFixed(2) + 'deg');
      el.style.setProperty('--rx', (-py * max * 2).toFixed(2) + 'deg');
      el.style.setProperty('--mx', ((px + 0.5) * 100).toFixed(1) + '%');
      el.style.setProperty('--my', ((py + 0.5) * 100).toFixed(1) + '%');
      el.classList.add('tilting');
    }
    const hero = e.target.closest ? e.target.closest('.hero, .done-hero') : null;
    document.querySelectorAll('.hero-photo img').forEach((img) => {
      if (!hero || !hero.contains(img)) { img.style.removeProperty('--px'); img.style.removeProperty('--py'); return; }
      const b = hero.getBoundingClientRect();
      img.style.setProperty('--px', (((e.clientX - b.left) / b.width - 0.5) * -18).toFixed(1) + 'px');
      img.style.setProperty('--py', (((e.clientY - b.top) / b.height - 0.5) * -14).toFixed(1) + 'px');
    });
  }, { passive: true });
  document.addEventListener('pointerleave', () => { if (cur) reset(cur); cur = null; });
}

/* ---------- screen entrances (only when the screen changes) ---------- */
let lastEnter = null, enterTimer = null;
const _afterRender = typeof afterRender === 'function' ? afterRender : null;
afterRender = function (r) {
  if (_afterRender) _afterRender(r);
  if (REDUCED || r === lastEnter) return;
  lastEnter = r;
  const app = document.getElementById('app');
  app.classList.remove('enter');
  void app.offsetWidth;
  app.classList.add('enter');
  clearTimeout(enterTimer);
  enterTimer = setTimeout(() => app.classList.remove('enter'), 1600);
};

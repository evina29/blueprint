/* Bing's Blueprint: capacity guard, callbacks, wholesale standing orders,
   photo reading, quote comparison, read-aloud and the time trial. */

/* ================= #4 KITCHEN CAPACITY GUARD ================= */
function laborPoints(o) {
  if (['declined', 'picked_up'].includes(o.status)) return 0;
  if (o.channel === 'wholesale' || o.lane === 'green') return 1;
  if (o.lane === 'red') return 8;
  const q = latestQuote(o);
  return q && q.designScore ? q.designScore + 1 : 3;
}
const capacity = () => Math.max(1, +db.rates.dailyCapacity || 10);
function dayStatus(date) {
  const n = db.orders.filter((o) => o.pickupDate === date).reduce((t, o) => t + laborPoints(o), 0);
  const pct = n / capacity();
  return { n, pct, full: pct >= 1, busy: pct >= 0.6 && pct < 1, label: pct >= 1 ? 'Full' : pct >= 0.6 ? 'Busy' : 'Open' };
}
function capacityStrip(d) {
  const start = d.staff ? todayISO() : addDays(todayISO(), 1);
  const days = [];
  for (let s = start; days.length < 12; s = addDays(s, 1)) if (!isSunday(s)) days.push(s);
  const blockFull = !d.staff && d.lane !== 'green';
  return `<div class="cap-strip" role="group" aria-label="Pickup days and how busy the kitchen is">
    ${days.map((s) => {
      const st = dayStatus(s), dt = parseDay(s);
      const dis = blockFull && st.full;
      return `<button class="cap-day ${st.full ? 'full' : st.busy ? 'busy' : 'open'} ${d.pickupDate === s ? 'on' : ''}" ${dis ? 'disabled' : ''} onclick="W.set('pickupDate','${s}',true)" title="${st.label}: ${st.n} of ${capacity()} kitchen hours booked">
        <span>${dt.toLocaleDateString(undefined, { weekday: 'short' })}</span><b>${dt.getDate()}</b><small>${st.label}</small></button>`;
    }).join('')}</div>
    <div class="hint">${blockFull ? 'Full days are closed to new custom cakes so every order gets the time it needs.' : 'Staff can still book a full day if the kitchen agrees.'}</div>`;
}
function loadMeter(date) {
  const st = dayStatus(date);
  if (isSunday(date)) return '';
  return `<div class="load ${st.full ? 'full' : st.busy ? 'busy' : ''}" title="${st.n} of ${capacity()} kitchen hours booked"><span style="width:${Math.min(100, st.pct * 100)}%"></span></div>`;
}

/* ================= #6 CALLBACK REQUESTS ================= */
function defaultCallbacks() {
  return [{ id: 'CB-sample', name: 'Ruth Delgado', phone: '302-555-0122', when: 'Morning', note: 'Wants to order a cake for her husband’s retirement but prefers to talk it through.', at: Date.now() - 50 * 60000, done: false }];
}
const cbDraft = { name: '', phone: '', when: 'Morning', note: '', sent: null, error: '' };
function viewCallback() {
  if (cbDraft.sent) {
    return `<div class="card" style="max-width:620px;margin:0 auto;text-align:center">
      <span class="eyebrow">Request received</span><h1 style="font-size:2.3rem">We’ll call you.</h1>
      <p>A person from Bing’s will call <b>${esc(cbDraft.sent.phone)}</b> in the <b>${esc(cbDraft.sent.when.toLowerCase())}</b> on the next business day, and fill in your order with you.</p>
      <div class="row" style="justify-content:center;margin-top:18px"><a class="btn btn-primary" href="#home" onclick="cbDraft.sent=null">Back to the shop</a></div></div>`;
  }
  const chip = (v) => `<button class="chip ${cbDraft.when === v ? 'on' : ''}" onclick="cbDraft.when='${v}';render()">${v}</button>`;
  return `<div class="card" style="max-width:640px;margin:0 auto">
    <span class="eyebrow">Rather talk to a person?</span><h1 style="font-size:2.3rem">Ask us to call you</h1>
    <p class="muted">Leave your number and a good time. A baker calls you back and fills in the same order form for you, so you get the same Cake Passport as an online order.</p>
    <div class="grid2"><div><label for="cb-name">Your name</label><input id="cb-name" value="${esc(cbDraft.name)}" oninput="cbDraft.name=this.value"></div>
      <div><label for="cb-phone">Phone number</label><input id="cb-phone" type="tel" value="${esc(cbDraft.phone)}" oninput="cbDraft.phone=this.value"></div></div>
    <div class="field"><label>Best time to call</label><div class="chips">${chip('Morning')}${chip('Afternoon')}${chip('Evening')}</div></div>
    <div class="field"><label for="cb-note">What’s it about? (optional)</label><textarea id="cb-note" style="min-height:90px" oninput="cbDraft.note=this.value" placeholder="e.g. a birthday cake for 20 people next Saturday">${esc(cbDraft.note)}</textarea></div>
    ${cbDraft.error ? `<div class="error">${esc(cbDraft.error)}</div>` : ''}
    <div class="wiz-nav"><a class="btn btn-big" href="#home">Cancel</a><button class="btn-big btn-primary" onclick="CB.send()">Request a call</button></div>
    <p class="small muted" style="margin:14px 0 0">Or call us now: ${PHONE}</p></div>`;
}
function callbacksPanel() {
  const open = (db.callbacks || []).filter((c) => !c.done);
  if (!open.length) return '';
  return `<div class="card cb-panel"><div class="row"><h3 style="margin:0">Waiting for a call back <span class="tag t-amber">${open.length}</span></h3></div>
    ${open.map((c) => `<div class="cb-row"><div><b>${esc(c.name)}</b> · ${esc(c.phone)} · <span class="muted">${esc(c.when)}</span>
      <div class="small muted">${esc(c.note || 'No note')} · asked ${fmtTime(c.at)}</div></div>
      <div class="row"><button class="btn-sm btn-primary" onclick="CB.startOrder('${c.id}')">Start their order</button><button class="btn-sm" onclick="CB.done('${c.id}')">Mark called</button></div></div>`).join('')}</div>`;
}
const CB = {
  send() {
    if (!cbDraft.name.trim()) { cbDraft.error = 'Please enter your name.'; render(); return; }
    if (digits(cbDraft.phone).length !== 10) { cbDraft.error = 'Please enter a 10-digit phone number.'; render(); return; }
    const c = { id: 'CB-' + Date.now().toString(36), name: cbDraft.name.trim(), phone: fmtPhone(cbDraft.phone), when: cbDraft.when, note: cbDraft.note.trim(), at: Date.now(), done: false };
    db.callbacks = [c, ...(db.callbacks || [])];
    save();
    Object.assign(cbDraft, { name: '', phone: '', note: '', error: '', sent: c });
    render();
  },
  done(id) { const c = (db.callbacks || []).find((x) => x.id === id); if (c) { c.done = true; c.doneAt = Date.now(); save(); render(); } },
  startOrder(id) {
    const c = (db.callbacks || []).find((x) => x.id === id);
    if (!c) return;
    const d = newDraft(true);
    Object.assign(d, { name: c.name, phone: c.phone, ask: c.note || '', lane: 'yellow' });
    drafts.staff = d;
    c.done = true; c.doneAt = Date.now(); save();
    go('#staff-new');
  },
};

/* ================= #7 WHOLESALE STANDING ORDERS ================= */
const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
function defaultWholesale() {
  return [
    { id: 'W1', name: 'Corner Cup Café (sample)', contact: 'Sam P. · 302-555-0160', days: [2, 4, 6], active: true,
      items: [{ label: 'Cannoli (dozen)', qty: 4, price: 18 }, { label: 'Assorted pastry tray', qty: 2, price: 32 }] },
    { id: 'W2', name: 'Campus Roasters (sample)', contact: 'Lee R. · 302-555-0148', days: [1, 3, 5], active: true,
      items: [{ label: 'Mini cupcakes (dozen)', qty: 6, price: 12 }, { label: 'Cookie box (two dozen)', qty: 2, price: 20 }] },
  ];
}
const acctWeek = (a) => a.items.reduce((t, it) => t + (+it.qty || 0) * (+it.price || 0), 0) * a.days.length;
function viewWholesale() {
  const accts = db.wholesale || [];
  const t = todayISO();
  const upcoming = db.orders.filter((o) => o.channel === 'wholesale' && o.pickupDate >= t && o.status !== 'picked_up').length;
  return `<div class="row" style="margin-bottom:12px"><a class="back" href="#staff">← All orders</a></div>
  <div class="page-head"><div><span class="eyebrow">Bing’s other half</span><h1>Wholesale standing orders</h1></div><span class="spacer"></span>
    <button class="btn-primary" onclick="Wh.generate()">Create the next 7 days of orders</button></div>
  <p class="muted" style="margin-top:-10px;max-width:50em">Cafés and shops that order the same things every week. Set it once, and each delivery day becomes an order on the kitchen board, with a Cake Passport like any other. ${upcoming} upcoming wholesale orders are scheduled.</p>
  <div class="wh-grid">${accts.map((a, ai) => `<div class="card wh-card ${a.active ? '' : 'paused'}">
    <div class="row"><div><input class="wh-name" value="${esc(a.name)}" oninput="Wh.field(${ai},'name',this.value)" aria-label="Account name"><div class="small muted"><input class="wh-contact" value="${esc(a.contact)}" oninput="Wh.field(${ai},'contact',this.value)" aria-label="Contact"></div></div>
      <span class="spacer"></span><label class="check"><input type="checkbox" ${a.active ? 'checked' : ''} onchange="Wh.field(${ai},'active',this.checked,true)"> Active</label></div>
    <span class="label" style="display:block;margin-top:16px">Delivery days</span>
    <div class="chips">${[1, 2, 3, 4, 5, 6].map((n) => `<button class="chip ${a.days.includes(n) ? 'on' : ''}" onclick="Wh.day(${ai},${n})">${DOW[n]}</button>`).join('')}</div>
    <span class="label" style="display:block;margin-top:16px">Each delivery</span>
    ${a.items.map((it, ii) => `<div class="wh-item"><input value="${esc(it.label)}" oninput="Wh.item(${ai},${ii},'label',this.value)" aria-label="Item">
      <input type="number" min="0" value="${it.qty}" oninput="Wh.item(${ai},${ii},'qty',this.value)" aria-label="Quantity">
      <span class="muted small">×</span><input type="number" min="0" step="0.5" value="${it.price}" oninput="Wh.item(${ai},${ii},'price',this.value)" aria-label="Price each">
      <button class="btn-sm" onclick="Wh.removeItem(${ai},${ii})" aria-label="Remove item">✕</button></div>`).join('')}
    <div class="row" style="margin-top:8px"><button class="btn-sm" onclick="Wh.addItem(${ai})">+ Add item</button><span class="spacer"></span><span class="small">About <b id="wh-week-${ai}">${money(acctWeek(a))}</b> a week</span></div>
  </div>`).join('')}
  <div class="card wh-card wh-new"><h3>Add an account</h3><div class="field"><label for="wh-new-name">Business name</label><input id="wh-new-name"></div>
    <div class="field"><label for="wh-new-contact">Contact and phone</label><input id="wh-new-contact" placeholder="Name · 302-555-0100"></div>
    <button class="btn-primary" style="margin-top:16px" onclick="Wh.add()">Add account</button></div></div>`;
}
const Wh = {
  field(ai, k, v, rerender) { db.wholesale[ai][k] = v; save(); if (rerender) render(); },
  day(ai, n) { const a = db.wholesale[ai]; a.days = a.days.includes(n) ? a.days.filter((x) => x !== n) : [...a.days, n].sort(); save(); render(); },
  item(ai, ii, k, v) {
    const it = db.wholesale[ai].items[ii];
    it[k] = k === 'label' ? v : Math.max(0, +v || 0);
    save();
    const el = $('#wh-week-' + ai); if (el) el.textContent = money(acctWeek(db.wholesale[ai]));
  },
  addItem(ai) { db.wholesale[ai].items.push({ label: 'New item', qty: 1, price: 0 }); save(); render(); },
  removeItem(ai, ii) { db.wholesale[ai].items.splice(ii, 1); save(); render(); },
  add() {
    const name = $('#wh-new-name').value.trim();
    if (!name) { toast('Enter the business name.'); return; }
    db.wholesale.push({ id: 'W' + Date.now().toString(36), name, contact: $('#wh-new-contact').value.trim(), days: [2, 5], active: true, items: [{ label: 'Item', qty: 1, price: 0 }] });
    save(); render();
  },
  generate() {
    const now = Date.now();
    let n = 0;
    for (let i = 0; i < 7; i++) {
      const s = addDays(todayISO(), i);
      if (isSunday(s)) continue;
      const dow = parseDay(s).getDay();
      (db.wholesale || []).filter((a) => a.active && a.days.includes(dow)).forEach((a) => {
        const key = a.id + '@' + s;
        if (db.orders.some((o) => o.wholesaleKey === key)) return;
        const items = a.items.filter((it) => +it.qty > 0 && String(it.label).trim());
        if (!items.length) return;
        const lines = items.map((it) => ({ label: `${it.label} × ${it.qty}`, amount: it.qty * it.price }));
        const ph = (a.contact.match(/(\d{3})[\s.)-]*(\d{3})[\s.-]*(\d{4})/) || []).slice(1).join('-');
        db.orders.push({
          id: nextOrderId(), createdAt: now, channel: 'wholesale', lane: 'green', wholesaleKey: key,
          customer: { name: a.name, phone: ph || '', email: '' }, pickupDate: s, pickupTime: 'Morning (7–11)',
          spec: { items: items.map((it) => ({ label: it.label, qty: it.qty })) }, description: 'Standing wholesale order',
          budget: '', allergy: '', photos: [], status: 'approved', approvedVersion: 1, depositPaid: false, messages: [],
          quotes: [{ v: 1, lines, total: sum(lines), designScore: 0, note: '', at: now, status: 'approved' }],
          history: [{ at: now, text: `Created from ${a.name}’s standing order`, who: 'System' }],
        });
        n++;
      });
    }
    save();
    toast(n ? `Created ${n} wholesale orders. They’re on the kitchen board.` : 'The next 7 days are already scheduled.');
    render();
  },
};

/* ================= #5 AI READS THE INSPIRATION PHOTO ================= */
function photoReadHTML(d) {
  if (!d.photos.length || d.lane === 'green') return '';
  if (!(AI && AI_IMAGES)) return `<p class="hint">On the live page, Claude can look at your photo and suggest the matching decorations.</p>`;
  return `<div class="row" style="margin-top:10px"><button class="btn-sm btn-primary" id="photo-read" onclick="W.readPhoto()">Let Claude read my photo</button>
    <span class="small muted">Suggests decorations and a frosting color from your picture.</span></div>
    ${d.photoNote ? `<div class="ai-note" style="margin-top:12px"><div class="ai-head"><span class="ai-mark">AI</span><b>${esc(d.photoNote)}</b></div><p class="small muted" style="margin:6px 0 0">We updated your decorations. Change anything you like.</p></div>` : ''}`;
}
W.readPhoto = async function () {
  const d = draft();
  if (!d.photos.length || !AI) return;
  const btn = $('#photo-read');
  if (btn) { btn.disabled = true; btn.textContent = 'Claude is looking…'; }
  const prompt = `The attached image is a customer's inspiration photo for a custom cake from a family bakery. Reply with ONLY a JSON object:
{"addons": [decoration ids you can see in the photo], "frosting": the closest frosting color, "description": "one sentence describing the design for the baker",
 "note": "one friendly sentence for the customer saying what you matched, and anything the bakery may need to adjust"}
Use only these ids and names.
${rateCardText()}`;
  try {
    const f = await AI.json(prompt, { images: [dataUrlToBlob(d.photos[0])], modelTier: 'default' });
    if (d.lane === 'yellow') {
      const ok = (Array.isArray(f.addons) ? f.addons : []).filter((id) => db.rates.addons.some((a) => a.id === id) && id !== 'message');
      d.addons = [...new Set([...d.addons, ...ok])];
      if (FROSTING_NAMES.includes(f.frosting)) d.frosting = f.frosting;
    }
    if (f.description) d.description = d.description ? `${d.description} ${f.description}` : String(f.description);
    d.photoNote = String(f.note || 'We matched your photo.').slice(0, 220);
  } catch (e) {
    toast(e && e.code === 'not_granted' ? 'AI help is turned off for this page.' : 'Claude couldn’t read that photo. Describe it in words instead.');
  }
  render();
};

/* ================= #8 QUOTE COMPARISON ================= */
function quoteDiffHTML(o) {
  if (o.quotes.length < 2) return '';
  const cur = latestQuote(o), prev = o.quotes[o.quotes.length - 2];
  const pm = new Map(prev.lines.map((l) => [l.label, +l.amount])), cm = new Map(cur.lines.map((l) => [l.label, +l.amount]));
  const rows = [];
  cur.lines.forEach((l) => {
    if (!pm.has(l.label)) rows.push(`<tr class="add"><td>+ ${esc(l.label)}</td><td>${money(l.amount)}</td></tr>`);
    else if (pm.get(l.label) !== +l.amount) rows.push(`<tr class="chg"><td>${esc(l.label)}</td><td>${money(pm.get(l.label))} → ${money(l.amount)}</td></tr>`);
  });
  prev.lines.forEach((l) => { if (!cm.has(l.label)) rows.push(`<tr class="rem"><td>− ${esc(l.label)}</td><td>${money(l.amount)}</td></tr>`); });
  if (!rows.length) return '';
  const delta = cur.total - prev.total;
  return `<div class="diff"><span class="label">What changed from version ${prev.v}</span>
    <table class="lines">${rows.join('')}<tr class="total"><td>Total</td><td>${money(prev.total)} → ${money(cur.total)} <span class="${delta <= 0 ? 'save' : 'more'}">(${delta <= 0 ? 'save ' + money(-delta) : '+' + money(delta)})</span></td></tr></table></div>`;
}

/* ================= #10 READ THE QUOTE OUT LOUD ================= */
const canSpeak = () => typeof window.speechSynthesis !== 'undefined' && typeof window.SpeechSynthesisUtterance === 'function';
function speakButton(o) { return canSpeak() ? `<button class="btn-sm" style="margin-top:12px" onclick="Speak.quote('${o.id}')">Read this out loud</button>` : ''; }
const Speak = {
  quote(id) {
    const o = getOrder(id), q = latestQuote(o);
    if (!o || !canSpeak()) return;
    const say = (n) => `${Math.round(n * 100) / 100} dollars`;
    const parts = [`Order ${o.id.replace('-', ' ').split('').join(' ')}.`, CUSTOMER_STATUS[o.status]];
    if (q) { parts.push(`Your quote, version ${q.v}.`); q.lines.forEach((l) => parts.push(`${l.label.replace(/×/g, 'times')}: ${say(l.amount)}.`)); parts.push(`Total: ${say(q.total)}.`); }
    parts.push(`Pickup on ${fmtDay(o.pickupDate)}.`);
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(parts.join(' '));
      u.rate = 0.92;
      window.speechSynthesis.speak(u);
    } catch (e) { toast('Reading aloud isn’t available in this browser.'); }
  },
};

/* ================= #9 TIME TRIAL ================= */
const TRIAL_KEY = 'bb-trial';
function newTrial() { return { id: 'T' + Date.now().toString(36), paper: [] }; }
let trial = (() => { try { return JSON.parse(localStorage.getItem(TRIAL_KEY)) || newTrial(); } catch (e) { return newTrial(); } })();
function saveTrial() { try { localStorage.setItem(TRIAL_KEY, JSON.stringify(trial)); } catch (e) { /* this device only */ } }
let paperRun = null;
setInterval(() => { const el = $('#trial-clock'); if (el && paperRun) el.textContent = ((Date.now() - paperRun) / 1000).toFixed(1) + 's'; }, 100);
function trialDigital() { return db.orders.filter((o) => o.trial === trial.id && o.entrySeconds > 0).map((o) => o.entrySeconds); }
function trialSentence() {
  const p = median(trial.paper), g = median(trialDigital());
  if (p == null || g == null) return '';
  const n = Math.min(trial.paper.length, trialDigital().length);
  return `In our team test of ${n} order${n === 1 ? '' : 's'}, paper took ${Math.round(p)} seconds and Bing’s Blueprint took ${Math.round(g)} seconds (median).`;
}
function viewTrial() {
  const dig = trialDigital(), p = median(trial.paper), g = median(dig);
  const max = Math.max(p || 0, g || 0, 1);
  const list = (arr, kind) => arr.length ? `<ol class="trial-list">${arr.map((s, i) => `<li><span>${Math.round(s)}s</span>${kind === 'paper' ? `<button class="btn-sm" onclick="Trial.removePaper(${i})" aria-label="Remove">✕</button>` : ''}</li>`).join('')}</ol>` : '<p class="small muted">No entries yet.</p>';
  const faster = p && g ? Math.round(((p - g) / p) * 100) : null;
  return `<div class="row" style="margin-bottom:12px"><a class="back" href="#staff">← All orders</a></div>
  <div class="page-head"><div><span class="eyebrow">Evidence for the pitch</span><h1>Paper vs. Blueprint time trial</h1></div><span class="spacer"></span>
    <button class="btn-sm" onclick="Trial.reset()">Start a new trial</button></div>
  <p class="muted" style="margin-top:-10px;max-width:52em">Read the same test orders out loud, one at a time. For each one, write it on a paper form while the paper timer runs, then enter it with Quick entry (the timer there starts when the form opens). Use the same orders for both, and report the median.</p>
  <div class="grid2">
    <div class="card"><span class="label">Paper form</span><div class="trial-clock" id="trial-clock">${paperRun ? ((Date.now() - paperRun) / 1000).toFixed(1) + 's' : '0.0s'}</div>
      <button class="btn-primary btn-big btn-block" onclick="Trial.paper()">${paperRun ? 'Stop: order written' : 'Start timing a paper order'}</button>
      ${list(trial.paper, 'paper')}<p class="small">Median: <b>${p == null ? '—' : Math.round(p) + 's'}</b> · ${trial.paper.length} orders</p></div>
    <div class="card"><span class="label">Bing’s Blueprint</span><div class="trial-clock">${g == null ? '—' : Math.round(g) + 's'}</div>
      <button class="btn-primary btn-big btn-block" onclick="Trial.digital()">Start a timed Quick entry</button>
      ${list(dig, 'digital')}<p class="small">Median: <b>${g == null ? '—' : Math.round(g) + 's'}</b> · ${dig.length} orders</p></div>
  </div>
  ${p && g ? `<div class="card" style="margin-top:18px"><h3>Result</h3>
    <div class="bar-row trial-bar"><span class="bar-day">Paper</span><span class="bar-track"><span class="bar-fill" style="width:${(p / max) * 100}%"></span></span><span class="bar-n">${Math.round(p)}s</span></div>
    <div class="bar-row trial-bar"><span class="bar-day">Blueprint</span><span class="bar-track"><span class="bar-fill custom" style="width:${(g / max) * 100}%"></span></span><span class="bar-n">${Math.round(g)}s</span></div>
    <p style="margin:16px 0 8px"><b>${faster >= 0 ? `Blueprint was ${faster}% faster.` : `Paper was ${-faster}% faster. Practice Quick entry, or report it honestly.`}</b></p>
    <p class="ai-draft" id="trial-line">${esc(trialSentence())}</p>
    <button class="btn-sm" onclick="Trial.copy()">Copy this line for slide 6</button></div>` : ''}`;
}
const Trial = {
  paper() {
    if (paperRun) { trial.paper.push(Math.round((Date.now() - paperRun) / 100) / 10); paperRun = null; saveTrial(); }
    else paperRun = Date.now();
    render();
  },
  removePaper(i) { trial.paper.splice(i, 1); saveTrial(); render(); },
  digital() { const d = newDraft(true); d.lane = 'yellow'; d.trial = trial.id; drafts.staff = d; go('#staff-new'); },
  async reset() {
    if (!(await ask('Start a new trial? Paper times are cleared. Orders from the old trial stay in the system.', { ok: 'Start new trial' }))) return;
    trial = newTrial(); paperRun = null; saveTrial(); render();
  },
  copy() {
    const text = trialSentence();
    try { navigator.clipboard.writeText(text).then(() => toast('Copied. Paste it into slide 6.'), () => toast('Select the line above and copy it.')); }
    catch (e) { toast('Select the line above and copy it.'); }
  },
};

/* ================= boot: fill in data this version added ================= */
if (!Array.isArray(db.callbacks)) db.callbacks = defaultCallbacks();
if (!Array.isArray(db.wholesale)) db.wholesale = defaultWholesale();
if (!db.rates.dailyCapacity) db.rates.dailyCapacity = 10;

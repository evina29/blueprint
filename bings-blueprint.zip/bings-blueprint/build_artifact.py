"""Bundle index.html + styles.css + the scripts into one self-contained page.

Usage:
  python build_artifact.py           ->  dist/bings-blueprint.html     (the hosted, unbranded page)
  python build_artifact.py --bings   ->  dist/bings-presentation.html  (Bing's-branded copy; open locally, never publish)
"""
import base64, json, pathlib, re, sys

here = pathlib.Path(__file__).parent
bings = '--bings' in sys.argv
html = (here / 'index.html').read_text(encoding='utf-8')
css = (here / 'styles.css').read_text(encoding='utf-8')
scripts = re.findall(r'<script src="([^"]+)"></script>', html)
if bings:
    scripts = ['brand_config.js'] + scripts + ['brand.js']
    css += '\n' + (here / 'brand.css').read_text(encoding='utf-8')
js = '\n'.join((here / f).read_text(encoding='utf-8') for f in scripts)

body = re.search(r'<body>(.*)</body>', html, re.S).group(1)
body = re.sub(r'<script src="[^"]+"></script>\s*', '', body)
fonts = '\n'.join(re.findall(r'<link[^>]+fonts\.g[^>]+>', html))

def data_uri(path):
    mime = 'image/png' if path.suffix == '.png' else 'image/jpeg'
    return f'data:{mime};base64,' + base64.b64encode(path.read_bytes()).decode()

# Pages can't load files from other hosts, so embed the photos.
names = {'feature': 'writing', 'classic': 'classic', 'custom': 'custom', 'showpiece': 'wedding', 'baker': 'baker', 'candles': 'hero'}
imgs = {k: data_uri(here / 'img' / f'{v}.jpg') for k, v in names.items()}
if bings:
    for k in ['feature', 'classic', 'custom', 'showpiece', 'storefront', 'family']:
        imgs[k] = data_uri(here / 'img' / 'bings' / f'b-{k}.jpg')
    imgs['logo'] = data_uri(here / 'img' / 'bings' / 'b-logo.png')
js = 'window.BB_IMG = ' + json.dumps(imgs) + ';\n' + js

if bings:
    fonts = fonts.replace('family=Caveat', 'family=Berkshire+Swash&family=Caveat')
    page = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>Bing's Blueprint · a proposal for Bing's Bakery</title>
{fonts}
<style>
{css}
</style>
</head>
<body>
{body.strip()}
<script>
{js}
</script>
</body>
</html>
"""
    out = here / 'dist' / 'bings-presentation.html'
else:
    page = f"""<title>Bing's Blueprint</title>
<meta name="claude:viewport-fit-sides" content="cover">
{fonts}
<style>
{css}
</style>
{body.strip()}
<script>
{js}
</script>
"""
    out = here / 'dist' / 'bings-blueprint.html'
out.parent.mkdir(exist_ok=True)
out.write_text(page, encoding='utf-8')
print(f'wrote {out} ({len(page) // 1024} KB)')

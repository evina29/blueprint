# Photo credits

All photos are from Unsplash under the Unsplash License (free to use, no permission needed).
Resized and compressed for the web.

| File | Unsplash photo ID | Subject |
|---|---|---|
| writing.jpg | photo-1606983340126-99ab4feaa64a | Chocolate drip cake, buttercream roses, "Happy Birthday" |
| classic.jpg | photo-1578922864601-79dcc7cbcea9 | Pink cupcakes with birthday toppers |
| custom.jpg | photo-1606890737304-57a1ca8a5b62 | Layered chocolate cake with cherries |
| wedding.jpg | photo-1535141192574-5d4897c12636 | Three-tier cake with berries |
| baker.jpg | photo-1649773289945-93a96051fd18 | Baker piping pink buttercream |
| hero.jpg | photo-1545696563-af8f6ec2295a | Candles being lit on a birthday cake |

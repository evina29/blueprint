# Bing's Bakery images

Downloaded from bingsbakery.com on 2026-11-07 for the team's proposal to Bing's Bakery.
They belong to Bing's Bakery. Use them only in `dist/bings-presentation.html` when presenting to
the owner. Don't post that file or these images publicly.

| File | Source on bingsbakery.com |
|---|---|
| b-logo.png | /wp-content/uploads/2017/06/logo.png |
| b-feature.jpg | /wp-content/uploads/2017/09/Wedding-Cakes-15.jpg |
| b-custom.jpg | /wp-content/uploads/2017/09/Wedding-Cakes-13.jpg |
| b-showpiece.jpg | /wp-content/uploads/2017/09/Wedding-Cakes-14.jpg |
| b-classic.jpg | /wp-content/uploads/revslider/homeslider/background_slide1.jpg (cropped) |
| b-storefront.jpg | /wp-content/uploads/2021/06/609f632c468ce.image-1.jpg (cropped to the sign, no people) |
| b-family.jpg | /wp-content/uploads/2017/06/guzzi_family.jpg |

Menu items and prices in `brand_config.js` and the history in `brand.js` are from the same site.

/* Bing's edition: brand layer loaded after every other script.
   Local presentation copy only; never published. */

document.documentElement.classList.add('brand-bings');
document.title = 'Bing’s Blueprint · a proposal for Bing’s Bakery';
(() => {
  const b = document.querySelector('.banner');
  if (b) b.textContent = 'A student proposal for Bing’s Bakery · working prototype with sample orders';
  const brand = document.querySelector('.topbar .brand');
  if (brand) brand.innerHTML = `<img class="brand-logo" src="${IMG.logo}" alt="Bing’s Bakery, est. 1946"><span class="brand-text"><span class="brand-name">Bing’s</span><span class="brand-sub">Blueprint</span></span>`;
})();

const HERITAGE = [
  ['1871', 'Fader’s Bakery', 'Gotleib Fader bakes and delivers by horse-drawn wagon.'],
  ['1946', 'Bing’s Bakery', 'Russell and Selena Bing put their name on the sign.'],
  ['2005', 'The Guzzi family', 'Head baker Tom Guzzi and Carla keep the ovens going.'],
  ['2019', 'The online store', 'Standard orders go online.'],
  ['2026', 'Every order has a home', 'Custom cakes go online too, and no order is ever lost.'],
];

footHTML = function () {
  return `<footer class="site-foot"><div class="wrap">
    <div class="foot-grid">
      <div class="foot-brand"><img class="foot-logo" src="${IMG.logo}" alt="Bing’s Bakery, est. 1946"><p>Delaware’s longest-running bakery. Newark, Delaware, since 1871.</p></div>
      <div><h4>Order</h4><a href="#order">Order a cake</a><a href="#track">Track an order</a><a href="#callback">Ask us to call you</a></div>
      <div><h4>Hours</h4><p>Mon–Fri · 7am–6pm</p><p>Saturday · 7am–5pm</p><p>Sunday · Closed</p></div>
      <div><h4>Talk to us</h4><p>${PHONE}</p><p>Wedding cakes by appointment</p><p>Campus cakes for UD</p></div>
    </div>
    <div class="foot-note">A student proposal for Bing’s Bakery. Photos and menu from bingsbakery.com. Sample orders are fictional.</div>
  </div></footer>`;
};

viewHome = function () {
  const r = db.rates;
  const [lo, hi] = estimateRange(customLines({ servings: 12, flavor: 'Chocolate', filling: 'Raspberry', addons: ['drip', 'berries', 'rosettes'] }, '', r), r);
  const ticks = ['Delaware’s longest-running bakery', 'Serving Delaware since 1871', 'Quotes within one business day', 'Nothing is baked until you approve', 'Campus cakes delivered to UD', 'Photo scans still $10', `Rather call? ${PHONE}`];
  const tickHTML = ticks.map((t) => `<span>${esc(t)}</span>`).join('');
  return `
  <section class="hero">
    <div class="hero-photo">
      <img src="${IMG.feature}" alt="A tiered Bing’s cake with hand-piped pink and chocolate buttercream" style="object-position:50% 30%">
      <div class="sticker">Serving Delaware<b>since</b>1871</div>
    </div>
    <div class="hero-copy">
      <span class="eyebrow">Bing’s Bakery · Newark, Delaware</span>
      <h1>Every order <i>has a home.</i></h1>
      <p class="lede">The cakes Delaware has loved for generations, now as easy to order online as picking up the phone. Describe your cake in your own words, see a fair price right away, and approve the final quote from your phone. Every order, online, by phone or at the counter, is saved the moment it’s placed.</p>
      <div class="hero-ctas"><a class="btn btn-primary btn-big" href="#order">Order a cake</a><a class="btn btn-big" href="#track">Track an order</a></div>
      <div class="hero-meta">
        <span><b>Open</b>Mon–Fri 7–6 · Sat 7–5</span>
        <span><b>Rather call?</b><a href="tel:${digits(PHONE)}">${PHONE}</a></span>
        <span><b>Or</b><a href="#callback">Ask us to call you</a></span>
      </div>
    </div>
  </section>
  <div class="ticker" aria-hidden="true"><div class="ticker-track">${tickHTML}${tickHTML}</div></div>

  <section class="section"><div class="wrap">
    <div class="section-head"><span class="eyebrow">Three ways to order</span><h2>From a Monster Cupcake to a wedding cake</h2>
      <p>Classics are priced instantly. A custom cake gets a price range on the spot and a baker’s final quote. Wedding cakes still start with a conversation.</p></div>
    <div class="tiles">
      <article class="tile"><div class="tile-photo"><img src="${IMG.classic}" alt="Bing’s chocolate cupcakes with rainbow sprinkles" loading="lazy"><span class="tile-flag">Instant price</span></div>
        <div class="tile-body"><h3>Classic</h3><div class="tile-price">$3–$28<small>Monster Cupcakes to the Cannoli Petit Cake</small></div>
        <p>Petit cakes, cupcakes, cookies and this season’s pies, confirmed the moment you order.</p>
        <button class="btn btn-primary btn-block" onclick="W.startLane('green')">Order a classic</button></div></article>
      <article class="tile"><div class="tile-photo"><img src="${IMG.custom}" alt="A Bing’s tiered cake with orange flowers" loading="lazy"><span class="tile-flag">Instant price range</span></div>
        <div class="tile-body"><h3>Custom</h3><div class="tile-price">${money(lo)}–${money(hi)}<small>12 servings, berries and chocolate drip</small></div>
        <p>Pick size, flavor, filling and decorations. A Bing’s baker confirms the price within one business day.</p>
        <button class="btn btn-primary btn-block" onclick="W.startLane('yellow')">Design a custom cake</button></div></article>
      <article class="tile"><div class="tile-photo"><img src="${IMG.showpiece}" alt="A white Bing’s wedding cake with sugar flowers" loading="lazy"><span class="tile-flag">By appointment</span></div>
        <div class="tile-body"><h3>Wedding &amp; showpiece</h3><div class="tile-price">Baker’s quote<small>Recently engaged? Let’s talk.</small></div>
        <p>Share photos and a budget, and book your appointment. A baker builds your quote.</p>
        <button class="btn btn-primary btn-block" onclick="W.startLane('red')">Request a quote</button></div></article>
    </div>
  </div></section>

  <section class="story">
    <div class="story-photo story-collage">
      <img class="sc-sign" src="${IMG.storefront}" alt="The Bing’s Bakery sign above the shop" loading="lazy">
      <figure class="sc-family"><img src="${IMG.family}" alt="Bing’s bakers in the kitchen" loading="lazy"><figcaption>The bakers behind the name</figcaption></figure>
    </div>
    <div class="story-copy">
      <span class="eyebrow">Since 1871</span>
      <h2>Every generation kept the craft and changed the tools.</h2>
      <p>A horse-drawn wagon in 1871. A new name on the sign in 1946. An online store in 2019. Blueprint is the next tool: the same Bing’s baking, with every order on record and a baker approving every price.</p>
      <ul class="promises">
        <li><span class="n">i.</span><div><b>An itemized, fair price</b><span>Base, decorations and decorating labor, line by line.</span></div></li>
        <li><span class="n">ii.</span><div><b>Nothing baked without a yes</b><span>Bing’s bakers stay in control of every custom order.</span></div></li>
        <li><span class="n">iii.</span><div><b>Paper stays as the backup</b><span>The day’s pickups print every morning.</span></div></li>
      </ul>
    </div>
  </section>

  <section class="section"><div class="wrap">
    <div class="section-head"><span class="eyebrow">Delaware’s longest-running bakery</span><h2>155 years of Bing’s</h2></div>
    <ol class="heritage">${HERITAGE.map(([y, t, d], i) => `<li class="${i === HERITAGE.length - 1 ? 'now' : ''}"><span class="hy">${y}</span><b>${t}</b><span>${d}</span></li>`).join('')}</ol>
  </div></section>
  ${footHTML()}`;
};

function viewThanks() {
  return `<section class="thanks">
    <img class="thanks-logo" src="${IMG.logo}" alt="Bing’s Bakery, est. 1946">
    <span class="eyebrow">A proposal for Bing’s Bakery</span>
    <h1>Every order <i>has a home.</i></h1>
    <p class="thanks-lede">Keep the craftsmanship. Keep the personal service. Remove the paper risk.</p>
    <ol class="heritage compact">${HERITAGE.map(([y, t], i) => `<li class="${i === HERITAGE.length - 1 ? 'now' : ''}"><span class="hy">${y}</span><b>${t}</b></li>`).join('')}</ol>
    <p class="thanks-sign">Thank you for trusting us with a real challenge.</p>
  </section>`;
}

const _viewOwner = viewOwner;
viewOwner = function () { return _viewOwner().replace('How the bakery is doing', 'How Bing’s is doing'); };

if (typeof DEMO_STEPS !== 'undefined') DEMO_STEPS.push({ label: 'Thank you', is: (r) => r === 'thanks', open() { go('#thanks'); } });

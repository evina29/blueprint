/* Bing's Blueprint: live cake preview.
   Draws the cake from the order's choices (size, frosting, decorations,
   writing) so customers see it before ordering and bakers see the final look. */

const FROSTING = {
  White: ['#fbf7ef', '#e8dcc8'], Pink: ['#f6c6d2', '#e3a2b5'], Blue: ['#bcd6ee', '#97bcdf'], Lavender: ['#dacbef', '#bfa8e0'],
  Yellow: ['#f7e3a3', '#e8cd7c'], Mint: ['#cbe9d8', '#a6d6bb'], Chocolate: ['#8b5b3d', '#6c432c'],
};
const FROSTING_NAMES = Object.keys(FROSTING);

function cakeSVG(lane, spec, opts = {}) {
  if (lane === 'green') return '';
  spec = spec || {};
  const add = spec.addons || [];
  const [fr, frD] = FROSTING[spec.frosting] || FROSTING.White;
  const ink = spec.frosting === 'Chocolate' ? '#fbf1e2' : '#5a2c1c';
  const cx = 160;
  const rot = +opts.rot || 0;
  let tiers;
  if (lane === 'red') tiers = [{ w: 224, h: 66 }, { w: 164, h: 60 }, { w: 108, h: 54 }];
  else {
    const s = +spec.servings || 10;
    const w = s <= 8 ? 160 : s <= 12 ? 180 : s <= 20 ? 200 : 220;
    tiers = [{ w, h: s <= 12 ? 74 : 86 }];
    if (add.includes('tier')) tiers.push({ w: Math.round(w * 0.64), h: 62 });
  }
  const total = tiers.reduce((t, x) => t + x.h, 0);
  let y = Math.min(238, 120 + total);
  const out = [];
  const plateR = tiers[0].w / 2 + 26;
  out.push(`<ellipse cx="${cx}" cy="${y + 4}" rx="${plateR}" ry="${plateR * 0.2}" class="cake-plate"/>`);
  out.push(`<ellipse cx="${cx}" cy="${y + 1}" rx="${plateR - 8}" ry="${(plateR - 8) * 0.2}" class="cake-plate-top"/>`);
  let top = null;
  tiers.forEach((t) => {
    const rx = t.w / 2, e = rx * 0.32, yb = y, yt = y - t.h;
    out.push(`<path d="M${cx - rx},${yt} L${cx - rx},${yb} A${rx},${e} 0 0 0 ${cx + rx},${yb} L${cx + rx},${yt} Z" fill="${fr}"/>`);
    out.push(`<path d="M${cx + rx * 0.5},${yt + e * 0.87} L${cx + rx * 0.5},${yb + e * 0.87} A${rx},${e} 0 0 0 ${cx + rx},${yb} L${cx + rx},${yt} Z" fill="${frD}" opacity=".35"/>`);
    out.push(`<path d="M${cx - rx},${yb} A${rx},${e} 0 0 0 ${cx + rx},${yb}" fill="none" stroke="${frD}" stroke-width="2"/>`);
    {
      const xh = cx + rx * 0.62 * Math.cos(rot + 2.2), hw = rx * 0.07;
      const yAt = (x) => yb + e * Math.sqrt(Math.max(0, 1 - ((x - cx) / rx) ** 2));
      const x1 = Math.max(cx - rx + 2, xh - hw), x2 = Math.min(cx + rx - 2, xh + hw);
      out.push(`<path d="M${x1.toFixed(1)},${yt} L${x1.toFixed(1)},${yAt(x1).toFixed(1)} L${x2.toFixed(1)},${yAt(x2).toFixed(1)} L${x2.toFixed(1)},${yt} Z" fill="#ffffff" opacity=".26"/>`);
    }
    out.push(`<ellipse cx="${cx}" cy="${yt}" rx="${rx}" ry="${e}" fill="${fr}" stroke="${frD}" stroke-width="1.2"/>`);
    if (lane === 'red') {
      for (let a = 0; a <= 14; a++) { const g = Math.PI * a / 14; out.push(`<circle cx="${(cx + rx * Math.cos(g)).toFixed(1)}" cy="${(yb + e * Math.sin(g)).toFixed(1)}" r="3.2" fill="${frD}"/>`); }
    }
    top = { rx, e, yt, h: t.h };
    y = yt;
  });
  const { rx, e, yt, h } = top;
  const flower = (x, y0, r, petal, mid) => {
    let s = '';
    for (let k = 0; k < 5; k++) { const g = (Math.PI * 2 * k) / 5; s += `<ellipse cx="${(x + Math.cos(g) * r * 0.9).toFixed(1)}" cy="${(y0 + Math.sin(g) * r * 0.9).toFixed(1)}" rx="${r * 0.75}" ry="${r * 0.55}" transform="rotate(${(g * 180) / Math.PI} ${(x + Math.cos(g) * r * 0.9).toFixed(1)} ${(y0 + Math.sin(g) * r * 0.9).toFixed(1)})" fill="${petal}"/>`; }
    return s + `<circle cx="${x}" cy="${y0}" r="${r * 0.42}" fill="${mid}"/>`;
  };
  if (lane === 'red') {
    [[0.6, 0.35], [1.25, 0.55], [1.9, 0.75], [3.4, 0.5], [4.6, 0.65]].forEach(([base, fy], i) => {
      const g = base + rot, sn = Math.sin(g); if (sn < 0.12) return;
      const rr = rx * (1 + 0.28 * Math.min(2, i % 3));
      out.push(flower(cx + rr * Math.cos(g), yt + 40 + fy * 110 - (i % 3) * 6, 9 * (0.75 + 0.25 * sn), '#f3d3dc', '#e9b949'));
    });
    out.push(flower(cx - 6, yt - 6, 8, '#f3d3dc', '#e9b949'), flower(cx + 10, yt - 2, 7, '#fbeef1', '#e9b949'));
  }
  if (add.includes('fondant')) {
    for (let k = 0; k < 6; k++) {
      const g = (Math.PI * 2 * k) / 6 + rot + 0.3, sn = Math.sin(g); if (sn < 0.2) continue;
      out.push(flower(cx + rx * 0.86 * Math.cos(g), yt + h * 0.55 + e * sn * 0.45, 9 * (0.72 + 0.28 * sn), '#fbe3ea', '#f0c05a'));
    }
  }
  if (add.includes('drip')) {
    out.push(`<ellipse cx="${cx}" cy="${yt}" rx="${rx}" ry="${e}" fill="#4a2b1c"/>`);
    out.push(`<path d="M${cx - rx},${yt} A${rx},${e} 0 0 0 ${cx + rx},${yt}" fill="none" stroke="#4a2b1c" stroke-width="7"/>`);
    for (let i = 0; i < 26; i++) {
      const g = (Math.PI * 2 * (i + 0.5)) / 26 + rot; if (Math.sin(g) < 0.06) continue;
      const x = cx + rx * Math.cos(g), y0 = yt + e * Math.sin(g);
      const len = 9 + ((i * 7) % 5) * 5;
      out.push(`<rect x="${(x - 3.6).toFixed(1)}" y="${y0.toFixed(1)}" width="7.2" height="${len}" rx="3.6" fill="#4a2b1c"/>`);
    }
  }
  if (add.includes('photo')) {
    out.push(`<g transform="translate(${cx - 34},${yt - e * 0.55}) scale(1,0.42)"><rect width="68" height="54" rx="4" fill="#ffffff" stroke="#d8cbb8"/><rect x="6" y="6" width="56" height="42" fill="#cfe1ee"/><path d="M8 46 L26 26 L38 38 L46 30 L60 46 Z" fill="#7fa36b"/><circle cx="50" cy="16" r="5" fill="#f3d36b"/></g>`);
  }
  const rosette = (x, y0, r, col) => `<circle cx="${x.toFixed(1)}" cy="${y0.toFixed(1)}" r="${r.toFixed(1)}" fill="${col}"/><circle cx="${x.toFixed(1)}" cy="${y0.toFixed(1)}" r="${(r * 0.56).toFixed(1)}" fill="none" stroke="${fr}" stroke-width="1.6"/><circle cx="${x.toFixed(1)}" cy="${y0.toFixed(1)}" r="1.4" fill="${fr}"/>`;
  const ros = { back: [], front: [] };
  if (add.includes('rosettes')) {
    const nf = Math.max(12, Math.round(rx / 5.5));
    const col = add.includes('drip') ? '#f6e7d3' : frD;
    for (let i = 0; i < nf; i++) {
      const g = (Math.PI * 2 * i) / nf + rot, sn = Math.sin(g);
      const piece = rosette(cx + rx * 0.97 * Math.cos(g), yt + e * 0.97 * sn - 2, 7.5 * (0.8 + 0.2 * (sn + 1) / 2), col);
      (sn < 0 ? ros.back : ros.front).push(piece);
    }
    out.push(...ros.back);
  }
  if (add.includes('berries')) {
    const pts = [[-26, -6], [-12, -12], [4, -8], [18, -13], [30, -4], [-4, -2], [12, 0]];
    pts.map(([dx, dy], i) => {
      const px = dx / 90, py = dy / 22, c = Math.cos(rot), sn = Math.sin(rot);
      return { i, u: px * c - py * sn, v: px * sn + py * c };
    }).sort((a, b) => a.v - b.v).forEach(({ i, u, v }) => {
      const x = cx + u * rx, y0 = yt + v * e;
      if (i % 3 === 1) out.push(`<circle cx="${x.toFixed(1)}" cy="${y0.toFixed(1)}" r="5" fill="#2f3d72"/><circle cx="${(x - 1.6).toFixed(1)}" cy="${(y0 - 1.6).toFixed(1)}" r="1.4" fill="#8fa0d6"/>`);
      else out.push(`<path d="M${x.toFixed(1)},${(y0 + 8).toFixed(1)} C${(x - 9).toFixed(1)},${(y0 + 1).toFixed(1)} ${(x - 7).toFixed(1)},${(y0 - 7).toFixed(1)} ${x.toFixed(1)},${(y0 - 6).toFixed(1)} C${(x + 7).toFixed(1)},${(y0 - 7).toFixed(1)} ${(x + 9).toFixed(1)},${(y0 + 1).toFixed(1)} ${x.toFixed(1)},${(y0 + 8).toFixed(1)} Z" fill="#d23a3f"/><path d="M${(x - 4).toFixed(1)},${(y0 - 6).toFixed(1)} L${x.toFixed(1)},${(y0 - 3).toFixed(1)} L${(x + 4).toFixed(1)},${(y0 - 6).toFixed(1)}" stroke="#4e8a3a" stroke-width="2" fill="none"/>`);
    });
  }
  out.push(...ros.front);
  const msg = String(spec.message || '').trim();
  if (msg && add.includes('message')) {
    const fs = Math.max(14, Math.min(32, (rx * (add.includes('rosettes') ? 2.9 : 3.4)) / Math.max(6, msg.length)));
    const dy = add.includes('berries') || add.includes('photo') ? e * 0.48 : e * 0.15;
    const col = add.includes('drip') ? '#fbf1e2' : ink;
    out.push(`<text transform="translate(${cx},${(yt + dy).toFixed(1)}) scale(1,0.7)" text-anchor="middle" dominant-baseline="middle" font-family="Caveat, 'Segoe Script', cursive" font-size="${fs.toFixed(1)}" fill="${col}">${esc(msg)}</text>`);
  }
  const label = `Preview of a ${lane === 'red' ? 'three-tier showpiece' : (spec.servings || 10) + '-serving'} cake`;
  const vTop = Math.max(0, Math.floor(yt - e - 34)), vH = 268 - vTop;
  return `<svg class="cake-svg ${opts.small ? 'small' : ''}" viewBox="0 ${vTop} 320 ${vH}" role="img" aria-label="${esc(label)}">${out.join('')}</svg>`;
}

function frostingChips(d) {
  return `<div class="chips">${FROSTING_NAMES.map((n) => `<button class="chip ${d.frosting === n ? 'on' : ''}" onclick="W.set('frosting','${n}',true)"><span class="swatch" style="background:${FROSTING[n][0]}"></span>${n}</button>`).join('')}</div>`;
}

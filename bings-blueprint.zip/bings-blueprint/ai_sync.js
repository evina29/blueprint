/* Bing's Blueprint: AI helpers, live sync and the owner dashboard.
   Loaded after app.js. On claude.ai it uses Claude (sample) and the shared
   database (db). Anywhere else it falls back to a built-in keyword reader
   and this browser's storage, so every feature still works offline. */

/* ================= LIVE SYNC (shared order book) ================= */
const Sync = { db: null, on: false, canWrite: true, synced: new Map(), cfgJSON: '', chain: Promise.resolve(), loaded: false, empty: false };
let pendingRender = false;
function softRender() {
  const r = route();
  if (r === 'order' || r === 'staff-new') return;
  const a = document.activeElement;
  if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.id !== 'sf-q') { pendingRender = true; return; }
  render();
}
document.addEventListener('focusout', () => { if (pendingRender) { pendingRender = false; setTimeout(softRender, 50); } });

function nextOrderId() {
  const max = db.orders.reduce((m, o) => Math.max(m, +String(o.id).replace(/\D/g, '') || 0), 1000);
  const n = Math.max(max + 1, db.nextId || 0);
  db.nextId = n + 1;
  return 'BB-' + n;
}

function pushRemote() {
  if (!Sync.on || !Sync.canWrite) return;
  Sync.chain = Sync.chain.then(async () => {
    const col = Sync.db.collection('orders');
    const ids = new Set(db.orders.map((o) => o.id));
    for (const o of db.orders) {
      const j = JSON.stringify(o);
      if (Sync.synced.get(o.id) !== j) { Sync.synced.set(o.id, j); await col.doc(o.id).set(JSON.parse(j)); }
    }
    for (const id of [...Sync.synced.keys()]) {
      if (!ids.has(id)) { Sync.synced.delete(id); await col.doc(id).delete(); }
    }
    const c = JSON.stringify(cfgPayload());
    if (c !== Sync.cfgJSON) { Sync.cfgJSON = c; await Sync.db.doc('config/main').set(JSON.parse(c)); }
  }).catch((e) => {
    if (e && e.code === 'invalid_argument') { Sync.canWrite = false; toast('You can view the shared order book but not change it. Ask the owner for edit access.'); }
    else if (e && e.code === 'quota_exceeded') toast('The shared order book is full. Delete old orders, then try again.');
    else toast('Could not sync that change. It is saved on this device.');
  });
}

async function initSync() {
  if (!window.claude || typeof window.claude.use !== 'function') return;
  let rdb = null;
  try { rdb = await window.claude.use('db'); } catch (e) { rdb = null; }
  if (!rdb) return;
  Sync.db = rdb;
  try {
    const u = await window.claude.use('user');
    const w = u && typeof u.can === 'function' ? await u.can('data.write') : null;
    Sync.canWrite = w !== false;
  } catch (e) { /* keep default */ }
  rdb.doc('config/main').onSnapshot((snap) => {
    if (snap.exists) {
      const data = clone(snap.data());
      if (data.rates) db.rates = data.rates;
      if (Array.isArray(data.callbacks)) db.callbacks = data.callbacks;
      if (Array.isArray(data.wholesale)) db.wholesale = data.wholesale;
      Sync.cfgJSON = JSON.stringify(cfgPayload()); persist(db); softRender();
    }
  }, () => {});
  rdb.collection('orders').onSnapshot((snap) => {
    Sync.on = true;
    db.orders = snap.docs.map((d) => clone(d.data())).filter((o) => o && o.id);
    Sync.synced = new Map(db.orders.map((o) => [o.id, JSON.stringify(o)]));
    if (!snap.metadata.fromCache) { Sync.loaded = true; Sync.empty = snap.empty; }
    persist(db);
    softRender();
  }, () => { Sync.on = false; softRender(); });
}

function cfgPayload() { return { rates: db.rates, callbacks: db.callbacks || [], wholesale: db.wholesale || [] }; }
function syncPill() {
  if (Sync.on) return `<span class="sync on" title="Orders update live on every signed-in device">Live · synced across devices</span>`;
  return `<span class="sync" title="Orders are saved in this browser">Saved on this device</span>`;
}

/* ================= AI ================= */
let AI = null;
let AI_IMAGES = false;
(async () => {
  if (!window.claude || typeof window.claude.use !== 'function') return;
  try { AI = await window.claude.use('sample'); } catch (e) { AI = null; }
  if (AI) {
    try { const lim = await AI.limits(); AI_IMAGES = !!(lim && lim.images); } catch (e) { AI_IMAGES = false; }
    softRender();
    if (route() === 'order' || route() === 'staff-new') { const b = $('#ai-credit'); if (b) b.textContent = aiCredit(); }
  }
})();
const aiCredit = () => (AI ? 'Claude reads your words and fills in the form. You check everything before you send it.' : 'We read your words and fill in the form. You check everything before you send it.');
const AI_ERR = {
  not_granted: 'AI help is turned off for this page, so we used the built-in reader instead.',
  rate_limited: 'The AI is busy right now, so we used the built-in reader instead.',
};

function dataUrlToBlob(u) {
  const [head, b64] = String(u).split(',');
  const mime = (head.match(/data:([^;]+)/) || [])[1] || 'image/jpeg';
  const bin = atob(b64 || '');
  const arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: mime });
}

/* ---------- customer: describe it, we fill it in ---------- */
function rateCardText() {
  const r = db.rates;
  return [
    `Classic menu (id: label, price): ${r.menu.map((m) => `${m.id}: ${m.label}, $${m.price}`).join('; ')}`,
    `Custom cake serving options: ${r.servingOptions.join(', ')}`,
    `Flavors: ${r.flavors.map((f) => f.name).join(', ')}`,
    `Fillings: ${r.fillings.map((f) => f.name).join(', ')}`,
    `Frosting colors ("White" if not said): ${FROSTING_NAMES.join(', ')}`,
    `Decorations (id: label, price): ${r.addons.map((a) => `${a.id}: ${a.label}, $${a.price}`).join('; ')}`,
    `Showpiece occasions: Wedding, Anniversary, Corporate event, Sculpted / 3D cake, Other`,
  ].join('\n');
}

function aiFillBox(d) {
  return `<div class="ai-box">
    <div class="ai-head"><span class="ai-mark">AI</span><label for="w-ask" style="margin:0">Tell us what you want, in your own words</label></div>
    <textarea id="w-ask" oninput="W.set('ask',this.value)" placeholder="e.g. Chocolate cake for about 12 people for my mom’s birthday on Saturday, with berries and a chocolate drip. Write “Happy Birthday Mom”. Around $100. No nuts please.">${esc(d.ask || '')}</textarea>
    <div class="row" style="margin-top:12px"><button class="btn-primary" id="ai-fill-btn" onclick="W.smartFill()">Set up my order</button>
      <button class="textlink small" onclick="W.example()">Try an example</button>
      <span class="muted small" id="ai-credit" style="flex:1 1 100%">${aiCredit()}</span></div>
  </div>
  <div class="or-line"><span>or choose the type yourself</span></div>`;
}

function aiNoteHTML(d) {
  const q = (d.aiQuestions || []).map((x) => `<li>${esc(x)}</li>`).join('');
  return `<div class="ai-note"><div class="ai-head"><span class="ai-mark">AI</span><b>${esc(d.aiNote)}</b></div>
    ${q ? `<p class="small" style="margin:8px 0 4px">Worth checking:</p><ul class="small">${q}</ul>` : ''}
    <p class="small muted" style="margin:6px 0 0">Change anything below. Nothing is sent until you press the button on the last step.</p>
    <button class="textlink small" onclick="draft().aiNote='';render()">Dismiss</button></div>`;
}

function nextWeekday(name) {
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const target = days.indexOf(name);
  let s = addDays(todayISO(), 1);
  for (let i = 0; i < 7; i++) { if (parseDay(s).getDay() === target) return s; s = addDays(s, 1); }
  return '';
}

// Built-in reader: works with no AI and no network.
function localFill(text) {
  const t = String(text || ''), low = t.toLowerCase(), r = db.rates;
  const out = { addons: [], menu: {}, message: '', allergy: '', budget: null, pickupDate: '' };
  const num = (re) => { const m = low.match(re); return m ? +m[1] : null; };
  const people = num(/(\d{1,3})\s*(?:people|persons|servings|guests|kids|slices)/) || num(/(?:for|feeds|serves)\s*(?:about|around|roughly)?\s*(\d{1,3})\b/);
  const cupcakes = num(/(\d{1,3})\s*cupcakes?/);
  const showpiece = /wedding|tiers?\b|tiered|sculpt|3d|three[- ]tier|two[- ]tier/.test(low) || (people && people > 40);
  const menuHit = r.menu.filter((m) => low.includes(m.id) || low.includes(m.label.toLowerCase().split(' (')[0]));
  const customWords = /write|say|drip|berr|rosette|fondant|photo|picture|flavor|filling|decorat|custom|theme|colou?r/.test(low);
  if (showpiece) {
    out.lane = 'red';
    out.event = /wedding/.test(low) ? 'Wedding' : /anniversar/.test(low) ? 'Anniversary' : /sculpt|3d/.test(low) ? 'Sculpted / 3D cake' : /corporate|office|company/.test(low) ? 'Corporate event' : 'Other';
    out.approxServings = people || 100;
  } else if ((cupcakes || menuHit.length) && !customWords) {
    out.lane = 'green';
    if (cupcakes) out.menu.cupcake = cupcakes;
    menuHit.forEach((m) => { if (m.id !== 'cupcake') out.menu[m.id] = num(new RegExp('(\\d{1,2})\\s*' + m.id)) || 1; });
    if (!Object.keys(out.menu).length) out.menu[menuHit[0] ? menuHit[0].id : 'cupcake'] = cupcakes || 1;
  } else {
    out.lane = 'yellow';
    const opts = r.servingOptions;
    out.servings = people ? opts.reduce((b, s) => (Math.abs(s - people) < Math.abs(b - people) ? s : b), opts[0]) : 10;
    out.flavor = (r.flavors.find((f) => low.includes(f.name.toLowerCase())) || { name: /choc/.test(low) ? 'Chocolate' : 'Vanilla' }).name;
    out.filling = (r.fillings.find((f) => f.name !== 'None' && low.includes(f.name.toLowerCase())) || { name: /strawberr/.test(low) ? 'Fresh strawberry' : 'Buttercream' }).name;
    out.frosting = /chocolate (frosting|icing|buttercream)/.test(low) ? 'Chocolate' : /\bpink\b/.test(low) ? 'Pink' : /\b(blue|navy)\b/.test(low) ? 'Blue' : /\b(lavender|purple|lilac)\b/.test(low) ? 'Lavender' : /\byellow\b/.test(low) ? 'Yellow' : /\b(mint|green)\b/.test(low) ? 'Mint' : 'White';
    const kw = { photo: /photo|picture|edible image/, drip: /drip/, rosettes: /rosette|piped|roses/, berries: /berr|strawberr|raspberr|blueberr/, fondant: /fondant/ };
    Object.entries(kw).forEach(([id, re]) => { if (re.test(low)) out.addons.push(id); });
  }
  const quoted = t.match(/[“"']([^”"']{3,60})[”"']/);
  const said = t.match(/(?:that says|saying|write|say)\s*:?\s*([^.,;!\n]{3,50})/i);
  out.message = quoted ? quoted[1].trim() : said ? said[1].trim() : (/happy birthday/i.test(t) ? 'Happy Birthday' : '');
  if (out.message && out.lane === 'yellow' && !out.addons.includes('message')) out.addons.unshift('message');
  const money_ = low.match(/\$\s?(\d{2,4})/) || low.match(/(\d{2,4})\s*(?:dollars|bucks)/);
  if (money_) out.budget = +money_[1];
  const al = t.match(/[^.;!\n]*(?:allerg|nut[- ]free|no nuts|peanut|gluten|dairy[- ]free|no dairy|egg[- ]free|vegan)[^.;!\n]*/i);
  if (al) out.allergy = al[0].trim().replace(/^(and|but)\s+/i, '');
  if (/tomorrow/.test(low)) out.pickupDate = addDays(todayISO(), 1);
  else { const wd = low.match(/\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/); if (wd) out.pickupDate = nextWeekday(wd[1]); }
  const what = out.lane === 'red' ? `a ${out.event.toLowerCase()} quote for about ${out.approxServings} servings`
    : out.lane === 'green' ? 'a classic order from the menu'
      : `a ${out.servings}-serving ${out.flavor.toLowerCase()} custom cake`;
  out.summary = `We set up ${what}${out.addons.length ? ' with the requested decorations' : ''}.`;
  out.questions = [];
  if (!out.pickupDate) out.questions.push('Which day would you like to pick it up?');
  if (out.lane === 'yellow' && !people) out.questions.push('About how many people will it serve? We guessed 10.');
  return out;
}

function applyFill(d, f) {
  const r = db.rates;
  const lane = ['green', 'yellow', 'red'].includes(f.lane) ? f.lane : 'yellow';
  d.lane = lane;
  if (lane === 'green') {
    d.menu = {};
    Object.entries(f.menu || {}).forEach(([id, q]) => { if (r.menu.some((m) => m.id === id) && +q > 0) d.menu[id] = Math.min(200, Math.round(+q)); });
  } else if (lane === 'yellow') {
    const opts = r.servingOptions, want = +f.servings || 10;
    d.servings = opts.reduce((b, s) => (Math.abs(s - want) < Math.abs(b - want) ? s : b), opts[0]);
    if (r.flavors.some((x) => x.name === f.flavor)) d.flavor = f.flavor;
    if (r.fillings.some((x) => x.name === f.filling)) d.filling = f.filling;
    if (FROSTING_NAMES.includes(f.frosting)) d.frosting = f.frosting;
    d.addons = (Array.isArray(f.addons) ? f.addons : []).filter((id) => r.addons.some((a) => a.id === id));
    d.message = String(f.message || '').slice(0, 60);
    if (d.message && !d.addons.includes('message')) d.addons.unshift('message');
  } else {
    if (['Wedding', 'Anniversary', 'Corporate event', 'Sculpted / 3D cake', 'Other'].includes(f.event)) d.event = f.event;
    d.approxServings = Math.max(10, Math.round(+f.approxServings || 100));
  }
  if (f.budget && +f.budget > 0) d.budget = String(Math.round(+f.budget));
  if (f.allergy) d.allergy = String(f.allergy).slice(0, 120);
  const pd = String(f.pickupDate || '');
  if (/^\d{4}-\d{2}-\d{2}$/.test(pd) && pd > todayISO() && !isSunday(pd)) d.pickupDate = pd;
  d.description = d.description || d.ask || '';
  d.aiNote = String(f.summary || 'We filled in your order.').slice(0, 200);
  d.aiQuestions = (Array.isArray(f.questions) ? f.questions : []).slice(0, 2).map((q) => String(q).slice(0, 140));
  d.step = 1; d.error = '';
}

W.smartFill = async function () {
  const d = draft();
  const text = String(d.ask || '').trim();
  if (text.length < 6) { toast('Tell us a little about the cake first.'); return; }
  const btn = $('#ai-fill-btn');
  if (btn) { btn.disabled = true; btn.textContent = AI ? 'Claude is reading…' : 'Reading…'; }
  let f = null, note = '';
  if (AI) {
    const today = parseDay(todayISO()).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    const prompt = `You help customers of a family bakery fill in a cake order form. Read the customer's words and reply with ONLY a JSON object:
{"lane": "green" | "yellow" | "red",
 "menu": {"<menu id>": quantity},        // green only
 "servings": number,                     // yellow only, one of the serving options
 "flavor": string, "filling": string, "frosting": string,  // yellow only, exactly as listed
 "addons": [decoration ids],             // yellow only, only ones the customer asked for
 "message": string,                      // words to write on the cake, "" if none
 "event": string, "approxServings": number,  // red only
 "budget": number | null, "allergy": string, "pickupDate": "YYYY-MM-DD" | "",
 "summary": "one short, warm sentence saying what you set up",
 "questions": ["up to 2 short questions about anything unclear"]}
Lanes: green = items straight off the classic menu with no custom design. red = weddings, tiered or sculpted cakes, or more than 40 servings. Everything else is yellow.
Pick the nearest serving option. Use only the ids and names listed. Never add decorations the customer did not ask for. Today is ${today}; turn day names into the next matching date (the bakery is closed Sundays).
${rateCardText()}

Customer's words:
"""${text.slice(0, 2000)}"""`;
    try { f = await AI.json(prompt, { modelTier: 'quick' }); }
    catch (e) { note = AI_ERR[e && e.code] || 'The AI could not read that, so we used the built-in reader instead.'; f = null; }
  }
  if (!f || typeof f !== 'object') f = localFill(text);
  applyFill(d, f);
  render();
  if (note) toast(note);
};

/* ---------- staff: AI quote assistant ---------- */
const assist = {}; // orderId -> {busy, result, source}
function localAssist(o) {
  const s = o.spec || {}, add = s.addons || [];
  let score = o.lane === 'red' ? 5 : 1;
  if (o.lane === 'yellow') {
    score += add.includes('fondant') ? 2 : 0;
    score += add.includes('tier') ? 2 : 0;
    score += add.filter((a) => ['drip', 'rosettes', 'berries', 'photo'].includes(a)).length >= 2 ? 1 : 0;
    score += /sculpt|figure|3d|portrait|hand[- ]painted|ombre|lettering/i.test(o.description || '') ? 1 : 0;
    score = Math.max(1, Math.min(5, score));
  }
  const risks = [];
  if (o.allergy) risks.push(`Allergy noted: “${o.allergy}”. Confirm ingredients with the customer before baking.`);
  if (isRush(o.pickupDate, db.rates, iso(new Date(o.createdAt)))) risks.push('Rush order: pickup is within the rush window. Check the schedule.');
  if (o.budget && o.estimate && +o.budget < o.estimate[0]) risks.push(`Budget (${money(o.budget)}) is below the estimate (${money(o.estimate[0])}–${money(o.estimate[1])}). Offer a simpler option.`);
  if (add.includes('fondant')) risks.push('Fondant flowers need drying time. Make sure the date allows it.');
  if (!risks.length) risks.push('No obvious risks found.');
  const first = (o.customer.name || '').split(' ')[0] || 'there';
  return {
    designScore: score,
    reason: score >= 4 ? 'Several labor-heavy decorations.' : score === 3 ? 'Detailed decorating, but standard techniques.' : 'Simple decorating.',
    risks,
    customerNote: `Hi ${first}, thanks for your order! We’ve priced your cake below. ${o.allergy ? 'We noted your allergy and will confirm ingredients with you. ' : ''}Let us know if you’d like any changes.`,
  };
}

S.assist = async function (id) {
  const o = getOrder(id);
  if (!o) return;
  assist[id] = { busy: true };
  render();
  let res = null, source = 'Built-in check';
  if (AI) {
    const r = db.rates;
    const prompt = `You are an experienced head baker reviewing a custom cake request before staff send a quote. Reply with ONLY a JSON object:
{"designScore": 1-5, "reason": "one sentence on the decorating labor",
 "risks": ["short, specific things staff should check (allergies, timing, feasibility, budget gap)"],
 "customerNote": "a warm 2-3 sentence note to the customer to send with the quote, mentioning any change you'd suggest",
 "internalNote": "one sentence for the team"}
Design Score scale (decorating labor fee): ${[1, 2, 3, 4, 5].map((n) => `${n} ${DS_TEXT[n]} = $${r.designScore[n]}`).join('; ')}.
Today: ${todayISO()}. Rush window: pickup within ${r.rushDays} days.
Order ${o.id} (${LANE[o.lane][0]} lane, came in via ${o.channel}):
- Pickup: ${o.pickupDate} ${o.pickupTime}
- Details: ${specSummary(o).join('; ')}
- Customer's words: ${o.description || '(none)'}
- Budget: ${o.budget ? '$' + o.budget : 'not given'}; estimate shown: ${o.estimate ? '$' + o.estimate.join('–$') : 'n/a'}
- Allergies: ${o.allergy || 'none noted'}
- Latest messages: ${o.messages.filter((m) => !m.internal).slice(-3).map((m) => m.from + ': ' + m.text).join(' | ') || 'none'}
${o.photos.length && AI_IMAGES ? 'The attached images are the customer\'s inspiration photos: judge the decorating labor from them.' : ''}
Be practical and honest. Never promise that something is allergen-free.`;
    const opts = { modelTier: 'default' };
    if (o.photos.length && AI_IMAGES) { try { opts.images = o.photos.slice(0, 3).map(dataUrlToBlob); } catch (e) { /* send text only */ } }
    try { res = await AI.json(prompt, opts); source = 'Claude'; }
    catch (e) { res = null; if (e && e.code === 'not_granted') toast('AI help is turned off for this page. Showing the built-in check.'); }
  }
  if (!res || typeof res !== 'object') res = localAssist(o);
  const ds = Math.max(1, Math.min(5, Math.round(+res.designScore || 3)));
  assist[id] = { busy: false, source, result: { designScore: ds, reason: String(res.reason || ''), risks: (Array.isArray(res.risks) ? res.risks : []).slice(0, 5).map(String), customerNote: String(res.customerNote || ''), internalNote: String(res.internalNote || '') } };
  render();
};
S.useAssist = function (id, what) {
  const a = assist[id] && assist[id].result;
  if (!a) return;
  if (!qb || qb.id !== id) initQB(getOrder(id));
  if (what === 'score' || what === 'all') S.ds(a.designScore);
  if (what === 'note' || what === 'all') { qb.note = a.customerNote; }
  render();
  toast(what === 'all' ? 'Applied. Review the quote, then send it.' : 'Applied.');
};
function assistCard(o) {
  if (o.lane === 'green') return '';
  const a = assist[o.id];
  const engine = AI ? 'Claude' : 'built-in checker';
  if (!a) {
    return `<div class="card ai-card"><div class="ai-head"><span class="ai-mark">AI</span><h3 style="margin:0">Quote assistant</h3></div>
      <p class="small muted" style="margin:10px 0 14px">Reads the request${o.photos.length ? ' and inspiration photos' : ''}, suggests a Design Score, flags risks and drafts your note. You decide what to send.</p>
      <button class="btn-primary" onclick="S.assist('${o.id}')">Review this order with ${engine}</button></div>`;
  }
  if (a.busy) return `<div class="card ai-card"><div class="ai-head"><span class="ai-mark">AI</span><h3 style="margin:0">Quote assistant</h3></div><p class="ai-thinking">${AI ? 'Claude is reviewing the order…' : 'Checking the order…'}</p></div>`;
  const x = a.result;
  return `<div class="card ai-card"><div class="ai-head"><span class="ai-mark">AI</span><h3 style="margin:0">Quote assistant</h3><span class="spacer"></span><span class="small muted">${esc(a.source)}</span></div>
    <div class="ai-grid">
      <div><span class="label">Suggested Design Score</span><div class="ai-score">${x.designScore}<small>${DS_TEXT[x.designScore]} · ${money(db.rates.designScore[x.designScore])}</small></div><p class="small">${esc(x.reason)}</p></div>
      <div><span class="label">Check before sending</span><ul class="small ai-risks">${x.risks.map((r) => `<li>${esc(r)}</li>`).join('')}</ul></div>
    </div>
    ${x.customerNote ? `<span class="label">Draft note to customer</span><p class="ai-draft">${esc(x.customerNote)}</p>` : ''}
    ${x.internalNote ? `<p class="small muted">Team note: ${esc(x.internalNote)}</p>` : ''}
    <div class="row"><button class="btn-primary" onclick="S.useAssist('${o.id}','all')">Use score and note</button>
      <button onclick="S.useAssist('${o.id}','score')">Score only</button><button onclick="S.assist('${o.id}')">Ask again</button></div></div>`;
}

/* ================= OWNER DASHBOARD (measurement) ================= */
const median = (arr) => { if (!arr.length) return null; const s = [...arr].sort((a, b) => a - b); const m = Math.floor(s.length / 2); return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2; };
let briefText = '', briefBusy = false;
function ownerStats() {
  const os = db.orders.filter((o) => o.status !== 'declined');
  const quoted = os.filter((o) => o.lane !== 'green' && o.quotes.length);
  const turn = quoted.map((o) => (o.quotes[0].at - o.createdAt) / 36e5).filter((h) => h >= 0);
  const onTime = quoted.filter((o) => o.quotes[0].at <= replyDue({ createdAt: o.createdAt })).length;
  const entry = os.map((o) => o.entrySeconds).filter((s) => s > 0);
  const revised = os.filter((o) => o.history.some((h) => /revised after approval/i.test(h.text))).length;
  const approved = os.filter((o) => o.approvedVersion && ['approved', 'baking', 'ready', 'picked_up'].includes(o.status));
  const revenue = approved.reduce((t, o) => t + ((approvedQuote(o) || {}).total || 0), 0);
  const channels = ['web', 'phone', 'counter', 'wholesale'].map((c) => [c, os.filter((o) => o.channel === c).length]);
  const waiting = os.filter(needsStaff);
  const overdue = os.filter(isOverdue);
  return { os, quoted, turn, onTime, entry, revised, approved, revenue, channels, waiting, overdue };
}
function viewOwner() {
  const st = ownerStats(), t = todayISO();
  const medTurn = median(st.turn), medEntry = median(st.entry);
  const pct = st.quoted.length ? Math.round((st.onTime / st.quoted.length) * 100) : null;
  const kpi = (label, value, target, ok, note) => `<div class="kpi ${ok === true ? 'good' : ok === false ? 'watch' : ''}">
    <span class="label">${label}</span><b>${value}</b><span class="kpi-target">${target}</span>${note ? `<span class="kpi-note">${note}</span>` : ''}</div>`;
  const days = Array.from({ length: 7 }, (_, i) => addDays(t, i));
  const load = days.map((d) => ({ d, n: st.os.filter((o) => o.pickupDate === d).length, c: st.os.filter((o) => o.pickupDate === d && o.lane !== 'green').length }));
  const maxN = Math.max(1, ...load.map((x) => x.n));
  const total = st.os.length || 1;
  return `<div class="page-head"><div><span class="eyebrow">Owner · ${fmtDay(t)}</span><h1>How the bakery is doing</h1></div><span class="spacer"></span>${syncPill()}</div>
  <p class="muted" style="margin-top:-12px">Calculated live from every order in the system. Pilot targets are the ones from the six-week plan.</p>
  <div class="kpis">
    ${kpi('Untraceable orders', '0', `Target 0 · ${st.os.length} orders on record`, true, 'Every order has a Cake Passport')}
    ${kpi('Quotes sent within 1 business day', pct == null ? '—' : pct + '%', 'Target 100%', pct == null ? null : pct >= 90, medTurn == null ? '' : `Median ${medTurn < 1 ? Math.round(medTurn * 60) + ' min' : medTurn.toFixed(1) + ' h'} to first quote`)}
    ${kpi('Phone or counter entry time', medEntry == null ? '—' : Math.round(medEntry) + ' s', 'Target under 60 s (median)', medEntry == null ? null : medEntry < 60, `${st.entry.length} timed entries`)}
    ${kpi('Waiting on staff now', String(st.waiting.length), 'Target 0 overdue', st.overdue.length === 0, st.overdue.length ? `${st.overdue.length} past the reply promise` : 'None overdue')}
    ${kpi('Price changes after approval', String(st.revised), 'Each one re-approved by the customer', true, 'Kitchen never bakes an unapproved price')}
    ${kpi('Approved order value', money(st.revenue), `${st.approved.length} approved orders`, null, `Deposits collected on ${st.approved.filter((o) => o.depositPaid).length}`)}
  </div>
  <div class="grid2" style="margin-top:22px">
    <div class="card"><h3>Pickups this week</h3>
      <div class="bars">${load.map((x) => `<div class="bar-row"><span class="bar-day">${fmtDay(x.d)}</span>
        <span class="bar-track"><span class="bar-fill" style="width:${(x.n / maxN) * 100}%"></span><span class="bar-fill custom" style="width:${(x.c / maxN) * 100}%"></span></span>
        <span class="bar-n">${x.n}</span></div>`).join('')}</div>
      <p class="small muted" style="margin:10px 0 0"><span class="key custom"></span> custom or showpiece <span class="key"></span> classic</p></div>
    <div class="card"><h3>Where orders come from</h3>
      ${st.channels.map(([c, n]) => `<div class="bar-row"><span class="bar-day" style="text-transform:capitalize">${c === 'web' ? 'Online' : c}</span><span class="bar-track"><span class="bar-fill" style="width:${(n / total) * 100}%"></span></span><span class="bar-n">${Math.round((n / total) * 100)}%</span></div>`).join('')}
      <p class="small muted" style="margin:10px 0 0">Phone and counter orders use the same form, so they’re just as safe as online ones.</p></div>
  </div>
  <div class="card ai-card" style="margin-top:22px"><div class="ai-head"><span class="ai-mark">AI</span><h3 style="margin:0">Morning brief for the team</h3><span class="spacer"></span>
    <button class="btn-primary btn-sm" onclick="O.brief()" ${briefBusy ? 'disabled' : ''}>${briefText ? 'Write it again' : 'Write today’s brief'}</button></div>
    <div class="brief" id="brief">${briefBusy && !briefText ? `<p class="ai-thinking">${AI ? 'Claude is reading today’s orders…' : 'Putting it together…'}</p>` : briefText ? esc(briefText) : '<p class="muted small" style="margin:0">A short plan for today: what to bake, who is picking up, which quotes are due and any allergy orders.</p>'}</div></div>`;
}
function localBrief() {
  const t = todayISO(), tm = addDays(t, 1);
  const today = db.orders.filter((o) => o.pickupDate === t && o.status !== 'declined' && o.status !== 'picked_up');
  const tomorrow = db.orders.filter((o) => o.pickupDate === tm && IN_KITCHEN.includes(o.status));
  const waiting = db.orders.filter(needsStaff);
  const allergy = db.orders.filter((o) => o.allergy && !['declined', 'picked_up'].includes(o.status));
  const line = (o) => `• ${o.id} ${o.customer.name}: ${specSummary(o)[0] || ''} (${STATUS[o.status][0]})`;
  return [`Good morning! Here’s ${fmtDay(t)}.`, '', `PICKUPS TODAY (${today.length})`, ...(today.length ? today.map(line) : ['• None']),
    '', `BAKE FOR TOMORROW (${tomorrow.length})`, ...(tomorrow.length ? tomorrow.map(line) : ['• Nothing approved yet']),
    '', `QUOTES TO SEND (${waiting.length})`, ...(waiting.length ? waiting.map((o) => `• ${o.id} ${o.customer.name}, reply by ${fmtTime(replyDue(o))}`) : ['• All caught up']),
    '', `ALLERGY ORDERS (${allergy.length})`, ...(allergy.length ? allergy.map((o) => `• ${o.id}: ${o.allergy}`) : ['• None'])].join('\n');
}
const O = {
  async brief() {
    if (briefBusy) return;
    briefBusy = true; briefText = ''; render();
    const fallback = localBrief();
    if (AI) {
      const t = todayISO();
      const rel = db.orders.filter((o) => !['declined', 'picked_up'].includes(o.status) && o.pickupDate <= addDays(t, 3))
        .map((o) => `${o.id} | ${o.customer.name} | pickup ${o.pickupDate} ${o.pickupTime} | ${STATUS[o.status][0]} | ${specSummary(o).join('; ')}${o.allergy ? ' | ALLERGY: ' + o.allergy : ''}${needsStaff(o) ? ' | quote due ' + fmtTime(replyDue(o)) : ''}`).join('\n');
      const prompt = `Write a short morning brief for the staff of a small family bakery, in plain text (no markdown symbols). Today is ${fmtDay(t)}.
Use four short sections with these exact headings in capitals: PICKUPS TODAY, BAKE FOR TOMORROW, QUOTES TO SEND, ALLERGY ORDERS. One line per order with its number and the customer's first name. End with one encouraging sentence. Under 160 words. Only use the orders below.
${rel || '(no open orders in the next three days)'}`;
      try {
        await AI(prompt, { modelTier: 'default', cache: false, onText: ({ text }) => { briefText = text; const el = $('#brief'); if (el) el.textContent = text; } });
      } catch (e) { briefText = (e && e.text) || fallback; }
    } else briefText = fallback;
    briefBusy = false; render();
  },
};

/* ================= larger text ================= */
function applyTextSize() { let big = false; try { big = localStorage.getItem('bb-big') === '1'; } catch (e) { /* ignore */ } document.documentElement.classList.toggle('big', big); const b = $('#textsize'); if (b) b.setAttribute('aria-pressed', String(big)); }
function toggleTextSize() { let big = !document.documentElement.classList.contains('big'); try { localStorage.setItem('bb-big', big ? '1' : '0'); } catch (e) { /* ignore */ } document.documentElement.classList.toggle('big', big); const b = $('#textsize'); if (b) b.setAttribute('aria-pressed', String(big)); }
applyTextSize();

initSync();

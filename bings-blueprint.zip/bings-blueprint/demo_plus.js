/* Bing's Blueprint: staff quick entry, pickup counter and demo examples.
   Loaded after ai_sync.js. */

const EXAMPLE_CUSTOMER = 'Chocolate cake for about 12 people for my mom’s birthday on Saturday, with fresh berries, a chocolate drip and piped rosettes. Please write “Happy Birthday Mom”. Around $100. No nuts please, my nephew is allergic.';
const EXAMPLE_NOTES = '12 choc, drip + berries + rosettes. Write "Happy Birthday Mom". Sat pm pickup. NO NUTS, grandson allergic. Jane Doe 302-555-0101. Budget about $110';
const PICKUP_TIMES = ['Morning (7–11)', 'Afternoon (11–3)', 'Late (3–close)'];

W.example = function () { const d = draft(); d.ask = EXAMPLE_CUSTOMER; render(); const t = $('#w-ask'); if (t) t.focus(); };

/* ================= STAFF QUICK ENTRY (one screen) ================= */
function viewQuick() {
  if (!drafts.staff) { drafts.staff = newDraft(true); drafts.staff.lane = 'yellow'; }
  const d = drafts.staff, r = db.rates;
  const opt = (v, cur, label) => `<option value="${esc(v)}" ${String(cur) === String(v) ? 'selected' : ''}>${esc(label == null ? v : label)}</option>`;
  const chip = (on, act, label) => `<button class="chip ${on ? 'on' : ''}" onclick="${act}">${esc(label)}</button>`;
  let laneFields = '';
  if (d.lane === 'green') {
    laneFields = `<div class="q-menu">${r.menu.map((m) => `<label class="q-qty" for="q-m-${m.id}"><span>${esc(m.label)} <small class="muted">${money(m.price)}</small></span>
      <input id="q-m-${m.id}" type="number" min="0" value="${d.menu[m.id] || 0}" oninput="Q.qty('${m.id}',this.value)"></label>`).join('')}</div>`;
  } else if (d.lane === 'yellow') {
    laneFields = `<div class="q-row3">
        <div><label for="q-srv">Servings</label><select id="q-srv" onchange="W.set('servings',+this.value,true)">${r.servingOptions.map((s) => opt(s, d.servings)).join('')}</select></div>
        <div><label for="q-fl">Flavor</label><select id="q-fl" onchange="W.set('flavor',this.value,true)">${r.flavors.map((f) => opt(f.name, d.flavor, f.name + (f.price ? ` (+${money(f.price)})` : ''))).join('')}</select></div>
        <div><label for="q-fi">Filling</label><select id="q-fi" onchange="W.set('filling',this.value,true)">${r.fillings.map((f) => opt(f.name, d.filling, f.name + (f.price ? ` (+${money(f.price)})` : ''))).join('')}</select></div>
      </div>
      <div class="field"><label>Frosting color</label>${frostingChips(d)}</div>
      <div class="field"><label>Decorations</label><div class="chips">${r.addons.map((a) => `<button class="chip ${d.addons.includes(a.id) ? 'on' : ''}" onclick="W.toggleAddon('${a.id}')">${esc(a.label)}<small>+${money(a.price)}</small></button>`).join('')}</div></div>
      ${d.addons.includes('message') ? `<div class="field"><label for="q-msg">Writing on the cake</label><input id="q-msg" value="${esc(d.message)}" oninput="W.set('message',this.value,false,true)"></div>` : ''}`;
  } else {
    laneFields = `<div class="grid2"><div><label for="q-ev">Occasion</label><select id="q-ev" onchange="W.set('event',this.value,true)">${['Wedding', 'Anniversary', 'Corporate event', 'Sculpted / 3D cake', 'Other'].map((e) => opt(e, d.event)).join('')}</select></div>
      <div><label for="q-as">About how many servings</label><input id="q-as" type="number" min="10" value="${esc(d.approxServings)}" oninput="W.set('approxServings',+this.value)"></div></div>`;
  }
  return `<div class="row" style="margin-bottom:16px"><a class="back" href="#staff">← All orders</a><span class="spacer"></span>
      <span class="label" style="margin:0">Entry timer <b id="timer" class="q-timer">${Math.round((Date.now() - d.startedAt) / 1000)}s</b></span></div>
    <div class="page-head"><div><span class="eyebrow">${d.trial ? 'Time trial · digital entry' : 'Phone or counter order'}</span><h1>Quick entry</h1></div><span class="spacer"></span>
      <div class="chips">${chip(d.channel === 'phone', "W.set('channel','phone',true)", 'Phone call')}${chip(d.channel === 'counter', "W.set('channel','counter',true)", 'Walk-in')}</div></div>
    <div class="split">
      <div class="card">
        <div class="ai-box">
          <div class="ai-head"><span class="ai-mark">AI</span><label for="q-notes" style="margin:0">Type notes while you’re on the phone, like you would on paper</label></div>
          <textarea id="q-notes" oninput="W.set('ask',this.value)" placeholder="12 choc, drip + berries. Write &quot;Happy Birthday Mom&quot;. Sat pm. No nuts. Jane Doe 302-555-0101">${esc(d.ask || '')}</textarea>
          <div class="row" style="margin-top:12px"><button class="btn-primary" id="q-fill" onclick="Q.fill()">Fill the form from my notes</button>
            <button class="textlink small" onclick="Q.example()">Try example notes</button></div>
        </div>
        ${d.aiNote ? `<div class="ai-note" style="margin-top:16px"><div class="ai-head"><span class="ai-mark">AI</span><b>${esc(d.aiNote)}</b></div>
          ${(d.aiQuestions || []).length ? `<ul class="small" style="margin:8px 0 0">${d.aiQuestions.map((x) => `<li>${esc(x)}</li>`).join('')}</ul>` : ''}
          <p class="small muted" style="margin:6px 0 0">Read it back to the customer, fix anything below, then save.</p></div>` : ''}
        <div class="q-section"><span class="q-num">1</span><b>Customer</b></div>
        <div class="grid2"><div><label for="q-name">Name</label><input id="q-name" value="${esc(d.name)}" oninput="W.set('name',this.value)"></div>
          <div><label for="q-phone">Phone</label><input id="q-phone" type="tel" value="${esc(d.phone)}" oninput="W.set('phone',this.value)"></div></div>
        <div class="q-row3" style="margin-top:18px">
          <div><label for="q-date">Pickup date</label><input id="q-date" type="date" min="${todayISO()}" value="${esc(d.pickupDate)}" onchange="W.set('pickupDate',this.value,false,true)"></div>
          <div><label for="q-time">Pickup time</label><select id="q-time" onchange="W.set('pickupTime',this.value)">${PICKUP_TIMES.map((t) => opt(t, d.pickupTime)).join('')}</select></div>
          <div><label for="q-lane">Order type</label><select id="q-lane" onchange="W.set('lane',this.value,true)">${opt('green', d.lane, 'Classic (menu)')}${opt('yellow', d.lane, 'Custom cake')}${opt('red', d.lane, 'Showpiece (quote)')}</select></div>
        </div>
        <div class="q-section"><span class="q-num">2</span><b>The order</b></div>
        ${laneFields}
        <div class="q-section"><span class="q-num">3</span><b>Notes for the baker</b></div>
        <div class="field"><label for="q-desc">What the customer described</label><textarea id="q-desc" style="min-height:80px" oninput="W.set('description',this.value)">${esc(d.description)}</textarea></div>
        <div class="grid2" style="margin-top:18px"><div><label for="q-all">Allergies</label><input id="q-all" value="${esc(d.allergy)}" oninput="W.set('allergy',this.value)" placeholder="None"></div>
          <div><label for="q-bud">Budget</label><input id="q-bud" type="number" min="0" value="${esc(d.budget)}" oninput="W.set('budget',this.value,false,true)" placeholder="Optional"></div></div>
        ${d.error ? `<div class="error">${esc(d.error)}</div>` : ''}
        <div class="wiz-nav"><button class="btn-big" onclick="Q.clear()">Clear</button><button class="btn-big btn-primary" onclick="W.submit()">Save order</button></div>
      </div>
      <div><div id="pricebox">${priceBoxHTML(d)}</div>
        ${d.photos.length ? `<div class="card" style="margin-top:16px"><span class="label">Original paper slip</span><img class="slip-thumb" src="${esc(d.photos[0])}" alt="Photo of the original paper slip"></div>` : ''}
        <div class="card" style="margin-top:16px"><span class="label">When you save</span>
          <ul class="small q-next"><li>The order gets a Cake Passport number and is saved, so it can’t be lost.</li>
          <li>The customer gets the same confirmation as an online order (sent by text in the pilot).</li>
          <li>${d.lane === 'green' ? 'Classic orders go straight to the kitchen.' : 'A baker prices custom work before anything reaches the kitchen.'}</li></ul></div></div>
    </div>`;
}

function expandShorthand(t) {
  const days = { mon: 'monday', tue: 'tuesday', tues: 'tuesday', wed: 'wednesday', thu: 'thursday', thur: 'thursday', thurs: 'thursday', fri: 'friday', sat: 'saturday', sun: 'sunday' };
  return String(t)
    .replace(/\b(mon|tues?|wed|thu(?:rs?)?|fri|sat|sun)\b\.?/gi, (m, d) => days[d.toLowerCase()] || m)
    .replace(/\bb[- ]?day\b/gi, 'birthday').replace(/\bppl\b/gi, 'people').replace(/\bchoc\b/gi, 'chocolate').replace(/\bvan\b/gi, 'vanilla')
    .replace(/\b(\d{1,2})\s+(?=(chocolate|vanilla|lemon|red velvet|cannoli|tiramisu)\b)/i, '$1 servings ');
}
function localContact(text) {
  const out = {};
  const ph = text.match(/(\d{3})[\s.)-]*(\d{3})[\s.-]*(\d{4})/);
  if (ph) out.phone = ph[1] + '-' + ph[2] + '-' + ph[3];
  const noQuotes = text.replace(/[“"'][^”"']*[”"']/g, ' ');
  const skip = /^(Happy|Birthday|No|Write|Please|Budget|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday|Sat|Sun|Fri|Mom|Dad|Custom|Chocolate|Vanilla|Lemon|Red|Pickup|Grandson|Allergic|Nuts)$/i;
  const names = [...noQuotes.matchAll(/\b([A-Z][a-z]+)\s+([A-Z][a-z]+)\b/g)].filter((m) => !skip.test(m[1]) && !skip.test(m[2]));
  if (names.length) out.name = names[names.length - 1][1] + ' ' + names[names.length - 1][2];
  const low = text.toLowerCase();
  out.pickupTime = /\b(pm|afternoon|lunch)\b/.test(low) ? PICKUP_TIMES[1] : /\b(evening|late|after work|after 3)\b/.test(low) ? PICKUP_TIMES[2] : /\b(am|morning)\b/.test(low) ? PICKUP_TIMES[0] : '';
  return out;
}

const Q = {
  qty(id, v) { const d = drafts.staff; d.menu[id] = Math.max(0, Math.round(+v || 0)); d.error = ''; $('#pricebox').innerHTML = priceBoxHTML(d); },
  example() { drafts.staff.ask = EXAMPLE_NOTES; render(); const t = $('#q-notes'); if (t) t.focus(); },
  clear() { drafts.staff = null; render(); },
  async fill() {
    const d = drafts.staff;
    const text = String(d.ask || '').trim();
    if (text.length < 6) { toast('Type a few notes first.'); return; }
    const btn = $('#q-fill');
    if (btn) { btn.disabled = true; btn.textContent = AI ? 'Claude is reading your notes…' : 'Reading…'; }
    let f = null, note = '';
    if (AI) {
      const today = parseDay(todayISO()).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      const prompt = `A bakery employee typed quick shorthand notes while taking a cake order by phone. Turn them into the order form. Reply with ONLY a JSON object:
{"name": string, "phone": "XXX-XXX-XXXX" or "", "pickupDate": "YYYY-MM-DD" or "", "pickupTime": one of ${JSON.stringify(PICKUP_TIMES)} or "",
 "lane": "green" | "yellow" | "red", "menu": {"<menu id>": quantity}, "servings": number, "flavor": string, "filling": string, "frosting": string,
 "addons": [decoration ids], "message": string, "event": string, "approxServings": number,
 "budget": number | null, "allergy": string, "description": "the customer's design wishes in one clean sentence",
 "summary": "one short sentence the employee can read back to the customer",
 "questions": ["up to 2 things the employee forgot to ask"]}
Shorthand: choc = chocolate, sat = Saturday, pm = afternoon, bday = birthday, a bare number before a flavor is the servings.
Lanes: green = classic menu items only, red = weddings, tiered or sculpted cakes or more than 40 servings, otherwise yellow. Use only the ids and names listed. Never add decorations that are not in the notes. Today is ${today}; the bakery is closed Sundays.
${rateCardText()}

Notes:
"""${text.slice(0, 2000)}"""`;
      try { f = await AI.json(prompt, { modelTier: 'quick' }); }
      catch (e) { note = AI_ERR[e && e.code] || 'The AI could not read that, so we used the built-in reader instead.'; f = null; }
    }
    if (!f || typeof f !== 'object') {
      const t = expandShorthand(text);
      f = Object.assign(localFill(t), localContact(text));
      f.summary = `${f.name ? f.name + ': ' : ''}${f.summary.replace(/^We set up /, '').replace(/\.$/, '')}${f.pickupDate ? ', pickup ' + fmtDay(f.pickupDate) : ''}.`;
      f.questions = [!f.name && 'Ask for the customer’s name.', !f.phone && 'Ask for a phone number for the confirmation text.', !f.pickupDate && 'Ask which day they will pick it up.'].filter(Boolean).slice(0, 2);
    }
    const descBefore = d.description;
    applyFill(d, f);
    d.step = 0;
    if (f.name) d.name = String(f.name).slice(0, 60);
    if (f.phone && digits(f.phone).length === 10) d.phone = fmtPhone(f.phone);
    if (PICKUP_TIMES.includes(f.pickupTime)) d.pickupTime = f.pickupTime;
    d.description = String(f.description || descBefore || text).slice(0, 400);
    render();
    if (note) toast(note);
  },
};

/* ================= PICKUP COUNTER ================= */
let counterQ = '';
function counterMatches() {
  const t = todayISO();
  const q = counterQ.trim().toLowerCase(), qd = digits(q);
  const open = db.orders.filter((o) => o.status !== 'declined');
  if (!q) {
    return open.filter((o) => o.pickupDate === t)
      .sort((a, b) => (a.status === 'picked_up') - (b.status === 'picked_up') || a.pickupTime.localeCompare(b.pickupTime));
  }
  return open.filter((o) => o.id.toLowerCase().includes(q) || o.customer.name.toLowerCase().includes(q) || (qd.length >= 3 && digits(o.customer.phone).includes(qd)))
    .sort((a, b) => (b.pickupDate === t) - (a.pickupDate === t) || (a.status === 'picked_up') - (b.status === 'picked_up') || b.pickupDate.localeCompare(a.pickupDate));
}
function counterRow(o) {
  const t = todayISO(), r = db.rates;
  const total = orderTotal(o);
  const deposit = total != null && o.depositPaid ? total * r.depositPct / 100 : 0;
  const due = total != null ? total - deposit : null;
  const notToday = o.pickupDate !== t;
  let action;
  if (o.status === 'ready') action = `<button class="btn-primary btn-big" onclick="Counter.handOver('${o.id}')">Hand over · picked up</button>`;
  else if (o.status === 'picked_up') action = `<span class="counter-done">Picked up</span>`;
  else action = `<span class="counter-wait">Not ready yet<br><small>${STATUS[o.status][0]}</small></span>`;
  return `<article class="counter-row ${o.status === 'picked_up' ? 'is-done' : ''}">
    <div class="counter-who"><span class="stub-label">${o.id}</span><b>${esc(o.customer.name)}</b><span class="small muted">${esc(o.customer.phone)}</span></div>
    <div class="counter-what"><div class="row" style="gap:6px">${laneTag(o.lane)} ${statusTag(o.status)} ${notToday ? `<span class="tag t-amber">Pickup ${fmtDay(o.pickupDate)}</span>` : ''}</div>
      <div class="small" style="margin-top:6px">${specSummary(o).map(esc).join(' · ')}</div>
      <div class="small muted">${esc(o.pickupTime)}</div>
      ${o.allergy ? `<div class="red-box small" style="margin-top:8px">Allergy: ${esc(o.allergy)}</div>` : ''}</div>
    <div class="counter-money">${total != null ? `<span class="label">Balance due</span><b>${money(due)}</b><span class="small muted">${o.depositPaid ? `Deposit ${money(deposit)} paid` : `Total ${money(total)}`}</span>` : '<span class="small muted">Not priced yet</span>'}</div>
    <div class="counter-act">${action}<a class="textlink small" href="#staff-order-${o.id}">Open order</a></div>
  </article>`;
}
function counterListHTML() {
  const list = counterMatches();
  if (!list.length) {
    return counterQ.trim()
      ? `<div class="card"><p style="margin:0">No order matches “${esc(counterQ)}”. Try their phone number, or check the Pickup Box for nearby dates.</p></div>`
      : `<div class="card"><p style="margin:0">No pickups scheduled today.</p></div>`;
  }
  return list.map(counterRow).join('');
}
function viewCounter() {
  const t = todayISO();
  const today = db.orders.filter((o) => o.pickupDate === t && o.status !== 'declined');
  const ready = today.filter((o) => o.status === 'ready').length;
  const done = today.filter((o) => o.status === 'picked_up').length;
  return `<div class="page-head"><div><span class="eyebrow">Pickup counter · ${fmtDay(t)}</span><h1>Who’s picking up?</h1></div><span class="spacer"></span>${syncPill()}</div>
    <input id="counter-q" class="counter-search" type="search" autocomplete="off" placeholder="Type a name, phone number or Cake Passport #" value="${esc(counterQ)}" oninput="Counter.search(this.value)">
    <p class="small muted" style="margin:10px 0 22px"><b>${today.length}</b> pickups today · <b>${ready}</b> ready · <b>${done}</b> picked up. Every order is on record, so a missing paper slip never means a missing cake.</p>
    <div id="counter-list" class="counter-list">${counterListHTML()}</div>`;
}
const Counter = {
  search(v) { counterQ = v; const el = $('#counter-list'); if (el) el.innerHTML = counterListHTML(); },
  async handOver(id) {
    const o = getOrder(id);
    if (!o) return;
    o.status = 'picked_up'; log(o, 'Picked up at the counter', 'Counter'); save();
    toast(`${o.id} handed to ${o.customer.name}.`);
    render();
  },
};
function afterRender(r) {
  if (r === 'counter') { const el = $('#counter-q'); if (el && document.activeElement === document.body) { el.focus(); el.setSelectionRange(el.value.length, el.value.length); } }
}

// First paint waits until every script file has loaded.
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', render); else render();

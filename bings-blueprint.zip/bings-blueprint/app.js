'use strict';
/* Bing's Blueprint — prototype order system.
   Plain HTML/CSS/JS, no build step. Data lives in this browser's localStorage,
   and every open tab stays in sync (customer, staff and kitchen views). */

const KEY = 'bings-blueprint-v1';
const IMG = Object.assign({
  feature: 'img/writing.jpg', classic: 'img/classic.jpg', custom: 'img/custom.jpg',
  showpiece: 'img/wedding.jpg', baker: 'img/baker.jpg', candles: 'img/hero.jpg',
}, window.BB_IMG || {});
const LANE_IMG = { green: 'classic', yellow: 'custom', red: 'showpiece' };
const PHONE = '302-737-5310';

/* ---------- helpers ---------- */
const $ = (s) => document.querySelector(s);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => { const v = Math.round((+n || 0) * 100) / 100; return '$' + (Number.isInteger(v) ? v.toFixed(0) : v.toFixed(2)); };
const pad = (n) => String(n).padStart(2, '0');
const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseDay = (s) => new Date(s + 'T12:00:00');
const todayISO = () => iso(new Date());
const addDays = (s, n) => { const d = parseDay(s); d.setDate(d.getDate() + n); return iso(d); };
const daysBetween = (a, b) => Math.round((parseDay(b) - parseDay(a)) / 864e5);
const fmtDay = (s) => (s ? parseDay(s).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' }) : '—');
const fmtTime = (ms) => new Date(ms).toLocaleString(undefined, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
const digits = (s) => String(s || '').replace(/\D/g, '');
const fmtPhone = (s) => { const d = digits(s); return d.length === 10 ? `${d.slice(0, 3)}-${d.slice(3, 6)}-${d.slice(6)}` : String(s || ''); };
const isSunday = (s) => parseDay(s).getDay() === 0;
const sum = (lines) => lines.reduce((t, l) => t + (+l.amount || 0), 0);
const clone = (o) => JSON.parse(JSON.stringify(o));

function ask(message, { ok = 'Continue', input = false, placeholder = '' } = {}) {
  return new Promise((resolve) => {
    const m = $('#modal');
    m.innerHTML = `<div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="modal-text"><p id="modal-text">${esc(message)}</p>
      ${input ? `<textarea id="modal-input" placeholder="${esc(placeholder)}"></textarea>` : ''}
      <div class="row" style="margin-top:14px"><span class="spacer"></span><button id="modal-cancel">Cancel</button><button id="modal-ok" class="btn-primary">${esc(ok)}</button></div></div>`;
    m.hidden = false;
    const done = (v) => { m.hidden = true; m.innerHTML = ''; resolve(v); };
    $('#modal-cancel').onclick = () => done(null);
    $('#modal-ok').onclick = () => done(input ? $('#modal-input').value : true);
    (input ? $('#modal-input') : $('#modal-ok')).focus();
  });
}

function toast(text) {
  const t = $('#toast');
  t.textContent = text; t.hidden = false;
  clearTimeout(toast._t); toast._t = setTimeout(() => { t.hidden = true; }, 3800);
}

/* ---------- rate card (the owner edits these) ---------- */
const DEFAULT_RATES = {
  perServing: 3.5,
  servingOptions: [8, 10, 12, 16, 20, 24, 30, 40],
  flavors: [
    { name: 'Vanilla', price: 0 }, { name: 'Chocolate', price: 0 }, { name: 'Lemon', price: 0 },
    { name: 'Red velvet', price: 0 }, { name: 'Cannoli', price: 0 }, { name: 'Tiramisu', price: 0 },
  ],
  fillings: [
    { name: 'Buttercream', price: 0 }, { name: 'Cannoli cream', price: 0 }, { name: 'Chocolate mousse', price: 0 },
    { name: 'Fresh strawberry', price: 5 }, { name: 'None', price: 0 },
  ],
  addons: [
    { id: 'message', label: 'Written message', price: 5 },
    { id: 'photo', label: 'Photo scan (edible image)', price: 10 },
    { id: 'drip', label: 'Chocolate drip', price: 12 },
    { id: 'rosettes', label: 'Piped rosettes', price: 15 },
    { id: 'berries', label: 'Fresh berry topping', price: 18 },
    { id: 'fondant', label: 'Fondant flowers', price: 25 },
    { id: 'tier', label: 'Extra tier', price: 35 },
  ],
  designScore: { 1: 0, 2: 10, 3: 25, 4: 40, 5: 60 },
  rushFee: 15,
  rushDays: 3,
  depositPct: 50,
  dailyCapacity: 10,
  menu: [
    { id: 'petit', label: 'Petit cake (serves 8)', price: 25 },
    { id: 'cannoli', label: 'Cannoli petit cake (serves 8)', price: 28 },
    { id: 'tiramisu', label: 'Tiramisu cake (serves 10)', price: 50 },
    { id: 'cupcake', label: 'Cupcake (each)', price: 3 },
  ],
};
if (window.BB_BRAND && window.BB_BRAND.rates) Object.assign(DEFAULT_RATES, window.BB_BRAND.rates);
const DS_TEXT = { 1: 'Simple', 2: 'Light decorating', 3: 'Detailed', 4: 'Intricate', 5: 'Showpiece' };

/* ---------- pricing ---------- */
const isRush = (pickup, rates, from = todayISO()) => !!pickup && daysBetween(from, pickup) < rates.rushDays;

function customLines(spec, pickup, rates, from) {
  const L = [{ label: `Base: ${spec.servings} servings × ${money(rates.perServing)}`, amount: spec.servings * rates.perServing }];
  const fl = rates.flavors.find((f) => f.name === spec.flavor);
  if (fl && fl.price) L.push({ label: `Flavor: ${fl.name}`, amount: fl.price });
  const fi = rates.fillings.find((f) => f.name === spec.filling);
  if (fi && fi.price) L.push({ label: `Filling: ${fi.name}`, amount: fi.price });
  for (const id of spec.addons) {
    const a = rates.addons.find((x) => x.id === id);
    if (a) L.push({ label: a.label, amount: a.price });
  }
  if (isRush(pickup, rates, from)) L.push({ label: `Rush fee (pickup within ${rates.rushDays} days)`, amount: rates.rushFee });
  return L;
}
function greenLines(spec, rates) {
  return rates.menu.filter((m) => spec.menu[m.id] > 0)
    .map((m) => ({ label: `${m.label} × ${spec.menu[m.id]}`, amount: m.price * spec.menu[m.id] }));
}
function estimateRange(lines, rates) {
  const sub = sum(lines);
  const lo = Math.ceil((sub + rates.designScore[2]) / 5) * 5;
  const hi = Math.max(lo, Math.floor((sub + rates.designScore[4]) / 5) * 5);
  return [lo, hi];
}
const dsLine = (ds, rates) => ({ label: `Design Score ${ds}: ${DS_TEXT[ds]} (decorating labor)`, amount: rates.designScore[ds], ds: true });

/* ---------- store ---------- */
let db = load();
function load() {
  let d = null;
  try { d = JSON.parse(localStorage.getItem(KEY)); } catch (e) { d = null; }
  if (!d || !Array.isArray(d.orders)) { d = seed(); persist(d); }
  return d;
}
function persist(d) {
  try { localStorage.setItem(KEY, JSON.stringify(d)); return true; } catch (e) {
    toast('Could not save: browser storage is full. Remove some photos or reset the demo data.');
    return false;
  }
}
const save = () => { const ok = persist(db); if (typeof pushRemote === 'function') pushRemote(); return ok; };
const getOrder = (id) => db.orders.find((o) => o.id === id);
function log(o, text, who = 'Staff') { o.history.push({ at: Date.now(), text, who }); }

/* ---------- order status ---------- */
const STATUS = {
  received: ['New request', 't-blue'],
  change_requested: ['Change requested', 't-amber'],
  quote_ready: ['Quote sent', 't-amber'],
  approved: ['Approved', 't-green'],
  baking: ['Baking', 't-purple'],
  ready: ['Ready for pickup', 't-teal'],
  picked_up: ['Picked up', 't-gray'],
  declined: ['Declined', 't-red'],
};
const CUSTOMER_STATUS = {
  received: 'Received. A baker is reviewing your request.',
  change_requested: 'Got your change request. The baker will send an updated quote.',
  quote_ready: 'Your quote is ready. Please review and approve it below.',
  approved: 'Approved! Your cake is scheduled for the kitchen.',
  baking: 'Your cake is being made right now.',
  ready: 'Ready for pickup!',
  picked_up: 'Picked up. Enjoy!',
  declined: 'This order was declined. See the messages below.',
};
const TRACK = ['Received', 'Quote ready', 'Approved', 'Baking', 'Ready', 'Picked up'];
const TRACK_IDX = { received: 0, change_requested: 1, quote_ready: 1, approved: 2, baking: 3, ready: 4, picked_up: 5, declined: 0 };
const LANE = { green: ['Classic', 't-green'], yellow: ['Custom', 't-amber'], red: ['Showpiece', 't-red'] };
const IN_KITCHEN = ['approved', 'baking', 'ready'];
const statusTag = (s) => `<span class="tag ${STATUS[s][1]}">${STATUS[s][0]}</span>`;
const laneTag = (l) => `<span class="tag ${LANE[l][1]}">${LANE[l][0]}</span>`;

function replyDue(o) {
  const d = new Date(o.lastCustomerActionAt || o.createdAt);
  d.setDate(d.getDate() + 1);
  while (d.getDay() === 0) d.setDate(d.getDate() + 1);
  d.setHours(d.getDay() === 6 ? 17 : 18, 0, 0, 0);
  return d.getTime();
}
const needsStaff = (o) => ['received', 'change_requested'].includes(o.status);
const isOverdue = (o) => needsStaff(o) && Date.now() > replyDue(o);
const latestQuote = (o) => o.quotes[o.quotes.length - 1];
const approvedQuote = (o) => o.quotes.find((q) => q.v === o.approvedVersion);
function orderTotal(o) {
  const q = IN_KITCHEN.includes(o.status) || o.status === 'picked_up' ? approvedQuote(o) : latestQuote(o);
  return q ? q.total : null;
}
function flags(o) {
  const f = [];
  if (o.allergy) f.push(['Allergy', 't-red']);
  if (isRush(o.pickupDate, db.rates, iso(new Date(o.createdAt)))) f.push(['Rush', 't-amber']);
  if (o.lane === 'red') f.push(['Big event', 't-purple']);
  if (isOverdue(o)) f.push(['Reply overdue', 't-red']);
  return f;
}
const flagTags = (o) => flags(o).map(([t, c]) => `<span class="tag ${c}">${t}</span>`).join(' ');

function specSummary(o) {
  const s = o.spec, r = db.rates, out = [];
  if (s && Array.isArray(s.items)) { s.items.forEach((it) => out.push(`${it.qty} × ${it.label}`)); return out; }
  if (o.lane === 'green') {
    r.menu.forEach((m) => { if (s.menu[m.id] > 0) out.push(`${s.menu[m.id]} × ${m.label}`); });
  } else if (o.lane === 'yellow') {
    out.push(`${s.servings} servings · ${s.flavor} · ${s.filling} filling${s.frosting ? ' · ' + s.frosting.toLowerCase() + ' frosting' : ''}`);
    const ad = s.addons.map((id) => (r.addons.find((a) => a.id === id) || {}).label).filter(Boolean);
    if (ad.length) out.push('Decorations: ' + ad.join(', '));
    if (s.message) out.push(`Writing: “${s.message}”`);
  } else {
    out.push(`${s.event} · about ${s.approxServings} servings`);
  }
  return out;
}

/* ---------- demo data (all fictional) ---------- */
function seed() {
  const rates = clone(DEFAULT_RATES);
  const d = { nextId: 1001, orders: [], rates };
  const t = todayISO(), now = Date.now(), H = 36e5, D = 864e5;
  const biz = (n) => { let s = addDays(t, n); while (isSunday(s)) s = addDays(s, 1); return s; };
  const mk = (o) => {
    const order = Object.assign({
      id: 'BB-' + d.nextId++, channel: 'web', status: 'received', quotes: [], messages: [], history: [], photos: [],
      depositPaid: false, description: '', budget: '', allergy: '', pickupTime: 'Morning (7–11)', approvedVersion: null,
    }, o);
    order.history.unshift({ at: order.createdAt, text: `Order received via ${order.channel}`, who: order.channel === 'web' ? 'Customer' : 'Staff' });
    d.orders.push(order);
    return order;
  };
  const quote = (o, ds, status, note, at) => {
    const lines = o.lane === 'green' ? greenLines(o.spec, rates)
      : [...customLines(o.spec, o.pickupDate, rates, iso(new Date(o.createdAt))), dsLine(ds, rates)];
    o.quotes.forEach((q) => { if (q.status === 'sent') q.status = 'superseded'; });
    const q = { v: o.quotes.length + 1, lines, total: sum(lines), designScore: ds, note: note || '', at, status };
    o.quotes.push(q);
    o.history.push({ at, text: `Quote v${q.v} ${status === 'approved' && o.lane === 'green' ? 'auto-confirmed' : 'sent'}: ${money(q.total)}`, who: 'Staff' });
    if (status === 'approved') { o.approvedVersion = q.v; o.history.push({ at: at + H, text: `Customer approved v${q.v}`, who: 'Customer' }); }
    return q;
  };
  const custom = (servings, flavor, filling, addons, message = '') => ({ servings, flavor, filling, addons, message });

  // Last year's order for the "Same as last year" demo
  let o = mk({ createdAt: now - 365 * D, channel: 'phone', lane: 'yellow', customer: { name: 'Taylor Reed', phone: '302-555-0142', email: '' },
    pickupDate: addDays(t, -360), spec: custom(16, 'Chocolate', 'Cannoli cream', ['message', 'rosettes'], 'Happy 70th Grandpa Joe'),
    description: 'Chocolate cake for my grandfather, blue rosettes around the edge.' });
  quote(o, 2, 'approved', '', o.createdAt + 3 * H); o.status = 'picked_up'; o.depositPaid = true;

  o = mk({ createdAt: now - 3 * D, channel: 'counter', lane: 'green', customer: { name: 'Taylor Reed', phone: '302-555-0142', email: '' },
    pickupDate: t, pickupTime: 'Afternoon (11–3)', spec: { menu: { cannoli: 1, cupcake: 6 } } });
  quote(o, 0, 'approved', '', o.createdAt); o.status = 'ready'; log(o, 'Moved to Ready', 'Kitchen');

  o = mk({ createdAt: now - 2 * D, lane: 'yellow', customer: { name: 'Jordan Malik', phone: '302-555-0117', email: 'jordan@example.com' },
    pickupDate: biz(1), spec: custom(12, 'Chocolate', 'Chocolate mousse', ['drip', 'berries', 'rosettes']),
    description: 'Chocolate drip cake with fresh berries piled on top and rosettes around the base.', budget: '120' });
  quote(o, 3, 'approved', 'Looks great — we can do this exactly as described.', o.createdAt + 5 * H);
  o.status = 'baking'; o.depositPaid = true; log(o, 'Started baking', 'Kitchen');
  o.messages.push({ from: 'staff', internal: false, text: 'Looks great — we can do this exactly as described.', at: o.createdAt + 5 * H });

  o = mk({ createdAt: now - 3 * D, lane: 'yellow', customer: { name: 'Priya Shah', phone: '302-555-0163', email: '' },
    pickupDate: biz(4), spec: custom(10, 'Vanilla', 'Fresh strawberry', ['message', 'photo'], 'Happy 7th Birthday Ava!'),
    description: 'Pink and white, with a photo of Ava and her dog on top.', allergy: 'Tree nut allergy (guest)', budget: '75' });

  o = mk({ createdAt: now - 5 * H, lane: 'red', customer: { name: 'Morgan Ellis', phone: '302-555-0188', email: 'morgan@example.com' },
    pickupDate: biz(38), spec: { event: 'Wedding', approxServings: 120 }, budget: '900',
    description: 'Three tiers, white buttercream, pressed flowers cascading down one side. Venue is 20 minutes away.' });

  o = mk({ createdAt: now - 26 * H, lane: 'yellow', customer: { name: 'Sam Ortiz', phone: '302-555-0129', email: '' },
    pickupDate: biz(5), spec: custom(20, 'Lemon', 'Buttercream', ['fondant', 'message'], 'Congrats Dr. Ortiz'),
    description: 'Graduation cake, lemon, fondant flowers in yellow and navy.' });
  quote(o, 4, 'superseded', '', o.createdAt + 4 * H);
  o.spec.addons = ['rosettes', 'message'];
  quote(o, 3, 'sent', 'Our fondant flowers can’t be ready in navy by your date. Buttercream rosettes in your colors instead, which also lowers your price.', o.createdAt + 20 * H);
  o.status = 'quote_ready';
  o.messages.push({ from: 'staff', internal: false, text: 'Our fondant flowers can’t be ready in navy by your date. Buttercream rosettes in your colors instead, which also lowers your price.', at: o.createdAt + 20 * H });
  o.messages.push({ from: 'staff', internal: true, text: 'Navy fondant needs 3 days to dry. Offered rosettes.', at: o.createdAt + 19 * H });

  o = mk({ createdAt: now - 1 * D, channel: 'phone', lane: 'green', customer: { name: 'Chris Nguyen', phone: '302-555-0151', email: '' },
    pickupDate: biz(2), spec: { menu: { cupcake: 24 } }, entrySeconds: 41 });
  quote(o, 0, 'approved', '', o.createdAt);
  o.status = 'approved';

  o = mk({ createdAt: now - 20 * H, lane: 'yellow', customer: { name: 'Alex Kim', phone: '302-555-0174', email: '' },
    pickupDate: biz(6), spec: custom(16, 'Red velvet', 'Buttercream', ['drip', 'message'], 'Happy Anniversary'),
    description: 'Red velvet, white drip.' , lastCustomerActionAt: now - 2 * H });
  quote(o, 2, 'sent', '', o.createdAt + 6 * H);
  o.status = 'change_requested';
  o.messages.push({ from: 'customer', internal: false, text: 'Could we make it 20 servings instead? More family is coming.', at: now - 2 * H });
  log(o, 'Customer requested a change', 'Customer');

  o = mk({ createdAt: now - 6 * H, channel: 'counter', lane: 'green', customer: { name: 'Dana Brooks', phone: '302-555-0136', email: '' },
    pickupDate: biz(3), spec: { menu: { tiramisu: 1 } }, entrySeconds: 38 });
  quote(o, 0, 'approved', '', o.createdAt); o.status = 'approved';

  o = mk({ createdAt: now - 4 * H, lane: 'yellow', customer: { name: 'Riley Chen', phone: '302-555-0195', email: '' },
    pickupDate: biz(1), spec: custom(10, 'Cannoli', 'Cannoli cream', ['message'], 'Go Blue Hens!'),
    description: 'Simple white cake for a team party.' });
  quote(o, 1, 'approved', '', o.createdAt + H);
  o.status = 'approved';

  if (typeof defaultWholesale === 'function') { d.wholesale = defaultWholesale(); d.callbacks = defaultCallbacks(); }
  d.orders.forEach((x) => {
    if (x.lane === 'yellow' && !x.estimate) x.estimate = estimateRange(customLines(x.spec, x.pickupDate, rates, iso(new Date(x.createdAt))), rates);
  });
  return d;
}

/* ---------- router ---------- */
const route = () => location.hash.replace(/^#\/?/, '');
let lastRoute = null;
function render() {
  const r = route();
  let html = '', sec = 'customer', m;
  if (!r || r === 'home') html = viewHome();
  else if (r === 'order') html = viewWizard(false);
  else if ((m = r.match(/^done-(.+)$/))) html = viewDone(m[1]);
  else if (r === 'track') html = viewTrack();
  else if ((m = r.match(/^passport-(.+)$/))) html = viewPassport(m[1]);
  else if (r.startsWith('staff')) {
    sec = 'staff';
    if (r === 'staff-new') html = viewQuick();
    else if ((m = r.match(/^staff-order-(.+)$/))) html = viewStaffOrder(m[1]);
    else if (r === 'staff-scan') html = viewScan();
    else if (r === 'staff-wholesale') html = viewWholesale();
    else if (r === 'staff-box') html = viewBox();
    else if (r === 'staff-rates') html = viewRates();
    else html = viewStaff();
  } else if (r === 'trial') { sec = 'staff'; html = viewTrial();
  } else if (r === 'callback') { html = viewCallback();
  } else if (r === 'counter') { html = viewCounter();
  } else if (r === 'owner') { html = viewOwner();
  } else if (r === 'kitchen') { sec = 'kitchen'; html = viewKitchen(); }
  else if (r === 'thanks' && typeof viewThanks === 'function') html = viewThanks();
  else if ((m = r.match(/^print-?(.*)$/))) { sec = 'staff'; html = viewPrint(m[1]); }
  else html = viewHome();
  $('#app').innerHTML = html;
  $('#app').classList.toggle('full', !r || r === 'home' || r === 'thanks' || r.startsWith('done-'));
  const cur = r.startsWith('passport') || r.startsWith('done') ? 'track' : (r || 'home').split('-')[0];
  document.querySelectorAll('.topbar nav a').forEach((el) => el.classList.toggle('active', el.dataset.r === cur));
  if (r !== lastRoute) { window.scrollTo(0, 0); lastRoute = r; }
  if (typeof afterRender === 'function') afterRender(r);
}
window.addEventListener('hashchange', render);
window.addEventListener('storage', (e) => {
  if (e.key !== KEY) return;
  db = load();
  const r = route();
  if (!r.startsWith('order') && !r.startsWith('staff-new')) render();
});
const go = (h) => { if (location.hash === h) render(); else location.hash = h; };

/* ================= CUSTOMER ================= */
function stubHTML(o, extra = '') {
  const total = orderTotal(o);
  const price = total != null ? money(total) : o.estimate ? `${money(o.estimate[0])}–${money(o.estimate[1])}` : 'Baker’s quote';
  return `<div class="stub">
    <div class="stub-top">
      <div class="row"><span class="stub-label">Cake Passport</span><span class="spacer"></span>${laneTag(o.lane)}</div>
      <div class="stub-id">${o.id}</div>
      <dl class="stub-rows"><dt>Name</dt><dd>${esc(o.customer.name)}</dd><dt>Pickup</dt><dd>${fmtDay(o.pickupDate)}</dd>
        <dt>Order</dt><dd>${esc(specSummary(o)[0] || '')}</dd><dt>Price</dt><dd class="mono">${price}</dd></dl>
    </div>
    <div class="stub-perf"></div>
    <div class="stub-bottom"><div class="row"><span class="stub-label">Status</span><span class="spacer"></span>${statusTag(o.status)}</div>${extra}
      <div class="barcode" aria-hidden="true"></div></div>
  </div>`;
}

function footHTML() {
  return `<footer class="site-foot"><div class="wrap">
    <div class="foot-grid">
      <div class="foot-brand"><span class="brand-name">Bing’s</span><p>Every order gets a Cake Passport, so nothing is ever lost between the counter and the kitchen.</p></div>
      <div><h4>Order</h4><a href="#order">Order a cake</a><a href="#track">Track an order</a><a href="#track">Reorder a past cake</a></div>
      <div><h4>Hours</h4><p>Mon–Fri · 7am–6pm</p><p>Saturday · 7am–5pm</p><p>Sunday · Closed</p></div>
      <div><h4>Talk to us</h4><p>${PHONE}</p><p>Custom quotes within 1 business day</p></div>
    </div>
    <div class="foot-note">Student case-competition prototype. Not operated by Bing’s Bakery. Sample orders are fictional. Photos: Unsplash.</div>
  </div></footer>`;
}

function viewHome() {
  const r = db.rates;
  const classic = r.menu[1] || r.menu[0];
  const [lo, hi] = estimateRange(customLines({ servings: 12, flavor: 'Chocolate', filling: 'Buttercream', addons: ['drip', 'berries', 'rosettes'] }, '', r), r);
  const ticks = ['Quotes within one business day', 'No account needed', 'Nothing is baked until you approve', 'Same as last year in two taps', `Call us at ${PHONE}`, 'Every order gets a Cake Passport'];
  const tickHTML = ticks.map((t) => `<span>${esc(t)}</span>`).join('');
  return `
  <section class="hero">
    <div class="hero-photo">
      <img src="${IMG.feature}" alt="Chocolate drip cake with buttercream roses and Happy Birthday piped on top">
      <div class="sticker">Custom cakes<b>quoted</b>in one day</div>
    </div>
    <div class="hero-copy">
      <span class="eyebrow">Cakes made by hand, ordered with care</span>
      <h1>Every order <i>has a home.</i></h1>
      <p class="lede">Describe the cake you’re picturing, see a fair price right away, and approve the final quote from your phone. Online, by phone or at the counter, every order is saved the moment it’s placed.</p>
      <div class="hero-ctas"><a class="btn btn-primary btn-big" href="#order">Order a cake</a><a class="btn btn-big" href="#track">Track an order</a></div>
      <div class="hero-meta">
        <span><b>Open</b>Mon–Fri 7–6 · Sat 7–5</span>
        <span><b>Rather call?</b><a href="tel:${digits(PHONE)}">${PHONE}</a></span>
        <span><b>Or</b><a href="#callback">Ask us to call you</a></span>
      </div>
    </div>
  </section>
  <div class="ticker" aria-hidden="true"><div class="ticker-track">${tickHTML}${tickHTML}</div></div>

  <section class="section"><div class="wrap">
    <div class="section-head"><span class="eyebrow">Three ways to order</span><h2>Choose how much the baker steps in</h2>
      <p>A classic cake is priced instantly. A custom cake gets a price range on the spot and a baker’s final quote. A showpiece gets a consultation.</p></div>
    <div class="tiles">
      <article class="tile"><div class="tile-photo"><img src="${IMG.classic}" alt="Pink frosted birthday cupcakes" loading="lazy"><span class="tile-flag">Instant price</span></div>
        <div class="tile-body"><h3>Classic</h3><div class="tile-price">${money(classic.price)}<small>${esc(classic.label)}</small></div>
        <p>Menu cakes, cupcakes and pastries, confirmed the moment you order.</p>
        <button class="btn btn-primary btn-block" onclick="W.startLane('green')">Order a classic</button></div></article>
      <article class="tile"><div class="tile-photo"><img src="${IMG.custom}" alt="Layered chocolate cake with cherries and cream" loading="lazy"><span class="tile-flag">Instant price range</span></div>
        <div class="tile-body"><h3>Custom</h3><div class="tile-price">${money(lo)}–${money(hi)}<small>12 servings, berries and chocolate drip</small></div>
        <p>Pick size, flavor, filling and decorations. A baker confirms the price within one business day.</p>
        <button class="btn btn-primary btn-block" onclick="W.startLane('yellow')">Design a custom cake</button></div></article>
      <article class="tile"><div class="tile-photo"><img src="${IMG.showpiece}" alt="Three-tier white cake topped with fresh berries" loading="lazy"><span class="tile-flag">By consultation</span></div>
        <div class="tile-body"><h3>Showpiece</h3><div class="tile-price">Baker’s quote<small>Weddings, sculpted cakes, large events</small></div>
        <p>Share photos and a budget. A baker builds your quote and books a tasting.</p>
        <button class="btn btn-primary btn-block" onclick="W.startLane('red')">Request a quote</button></div></article>
    </div>
  </div></section>

  <section class="story">
    <div class="story-photo"><img src="${IMG.baker}" alt="A baker piping pink buttercream onto a layer cake" loading="lazy"></div>
    <div class="story-copy">
      <span class="eyebrow">The human touch stays</span>
      <h2>A baker reviews every design.</h2>
      <p>The system keeps the record. People still make the cake. Nothing reaches the kitchen until a baker has priced it and you have approved it.</p>
      <ul class="promises">
        <li><span class="n">i.</span><div><b>An itemized price</b><span>Base, decorations and decorating labor, line by line.</span></div></li>
        <li><span class="n">ii.</span><div><b>Nothing baked without your yes</b><span>Change your mind? The baker sends a new version to approve.</span></div></li>
        <li><span class="n">iii.</span><div><b>A paper copy every morning</b><span>The day’s pickups print at 6:30, so the counter always has a backup.</span></div></li>
      </ul>
    </div>
  </section>

  <section class="section"><div class="wrap">
    <div class="section-head"><span class="eyebrow">How it works</span><h2>From idea to pickup</h2></div>
    <div class="steps-row">
      <div><span class="n">1</span><b>Describe it</b><span>Your words, your photos, your budget.</span></div>
      <div><span class="n">2</span><b>See the price</b><span>An instant range, so there are no surprises.</span></div>
      <div><span class="n">3</span><b>Approve the quote</b><span>The baker confirms, you tap approve.</span></div>
      <div><span class="n">4</span><b>Pick it up</b><span>Follow it from Received to Ready.</span></div>
    </div>
  </div></section>
  ${footHTML()}`;
}

/* ---------- order wizard (customers online, staff on the phone/counter) ---------- */
const drafts = { customer: null, staff: null };
function newDraft(staff) {
  return {
    staff, channel: staff ? 'phone' : 'web', lane: null, step: 0, menu: {},
    servings: 10, flavor: 'Vanilla', filling: 'Buttercream', frosting: 'White', addons: [], message: '',
    event: 'Wedding', approxServings: 100, description: '', budget: '', allergy: '', photos: [],
    name: '', phone: '', email: '', pickupDate: '', pickupTime: 'Morning (7–11)', startedAt: Date.now(), error: '',
  };
}
const draft = () => drafts[route().startsWith('staff') ? 'staff' : 'customer'];
const STEP_NAMES = ['What are you ordering?', 'The details', 'Describe it', 'Pickup & contact', 'Review & submit'];
const STEP_SHORT = ['Order type', 'Details', 'Description', 'Pickup', 'Review'];

function draftPrice(d) {
  const r = db.rates;
  if (d.lane === 'green') { const lines = greenLines({ menu: d.menu }, r); return { kind: 'exact', lines, total: sum(lines) }; }
  if (d.lane === 'yellow') {
    const lines = customLines({ servings: d.servings, flavor: d.flavor, filling: d.filling, addons: d.addons }, d.pickupDate, r);
    const [lo, hi] = estimateRange(lines, r);
    return { kind: 'range', lines, lo, hi };
  }
  if (d.lane === 'red') return { kind: 'quote' };
  return null;
}
function priceBoxHTML(d) {
  const img = IMG[LANE_IMG[d.lane] || 'feature'];
  const top = d.lane === 'yellow' || d.lane === 'red'
    ? `<div class="pb-photo pb-cake">${cakeSVG(d.lane, draftSpec(d))}<span class="pb-cap">Live 3D preview · drag to spin</span></div>`
    : `<div class="pb-photo"><img src="${img}" alt=""></div>`;
  return `<div class="price-box">${top}<div class="pb-body">${priceInner(d)}</div></div>`;
}
function priceInner(d) {
  const p = draftPrice(d);
  if (!p) return `<div><h3>Your price</h3><p class="muted">Choose an order type to see pricing.</p></div>`;
  if (p.kind === 'quote') {
    return `<div><h3>Your price</h3><div class="price-big">Baker’s quote</div>
      <p class="muted">Showpiece cakes are quoted by a baker${d.budget ? `, working to your budget of <b>${money(d.budget)}</b>` : ''}. We’ll reply within 1 business day and can book a tasting.</p></div>`;
  }
  const rows = p.lines.map((l) => `<tr><td>${esc(l.label)}</td><td>${money(l.amount)}</td></tr>`).join('');
  if (p.kind === 'exact') {
    return `<div><h3>Your price</h3><div class="price-big">${money(p.total)}</div>
      ${p.lines.length ? `<table class="lines">${rows}</table>` : '<p class="muted">Add items to see your total.</p>'}
      <p class="muted small">Classic orders are confirmed instantly.</p></div>`;
  }
  // custom: range + design-to-budget help
  let budgetHTML = '';
  const b = +d.budget;
  if (b > 0) {
    if (p.hi <= b) budgetHTML = `<div class="ok-box">Fits your budget of ${money(b)}</div>`;
    else {
      const sw = [];
      if (d.addons.includes('fondant')) sw.push({ text: 'Buttercream rosettes instead of fondant flowers', save: priceOf('fondant') - priceOf('rosettes'), act: "W.swap('fondant','rosettes')" });
      d.addons.filter((id) => id !== 'message').map((id) => db.rates.addons.find((a) => a.id === id)).filter(Boolean)
        .sort((x, y) => y.price - x.price).slice(0, 3)
        .forEach((a) => sw.push({ text: `Skip ${a.label.toLowerCase()}`, save: a.price, act: `W.toggleAddon('${a.id}')` }));
      const bigger = db.rates.servingOptions.filter((s) => s < d.servings).pop();
      if (bigger) sw.push({ text: `${bigger} servings instead of ${d.servings}`, save: (d.servings - bigger) * db.rates.perServing, act: `W.set('servings',${bigger},true)` });
      budgetHTML = `<div class="warn-box">${p.lo <= b ? `Your budget of ${money(b)} is inside the range. The baker will aim for it.` : `This is above your budget of ${money(b)}. Ways to save:`}</div>
        ${sw.map((s) => `<div class="swap"><span>${esc(s.text)} · <b>save ${money(s.save)}</b></span><button class="btn-sm" onclick="${s.act}">Apply</button></div>`).join('')}`;
    }
  }
  return `<div><h3>Your estimate</h3><div class="price-big">${money(p.lo)}–${money(p.hi)}</div>
    <table class="lines">${rows}<tr><td>Decorating labor (set by the baker)</td><td>${money(db.rates.designScore[2])}–${money(db.rates.designScore[4])}</td></tr></table>
    <p class="muted small">A baker reviews your design and confirms the final price within 1 business day. Nothing is charged until you approve it.</p>
    ${budgetHTML}</div>`;
}
const priceOf = (id) => (db.rates.addons.find((a) => a.id === id) || { price: 0 }).price;

function viewWizard(staff) {
  const key = staff ? 'staff' : 'customer';
  if (!drafts[key]) drafts[key] = newDraft(staff);
  const d = drafts[key];
  const steps = STEP_SHORT.map((t, i) => `<div class="${i <= d.step ? 'done' : ''}">${t}</div>`).join('');
  return `<div class="wizard">
    ${staff ? `<div class="row" style="margin-bottom:16px"><a class="back" href="#staff">← Staff dashboard</a><span class="spacer"></span>
      <span class="muted small">Entry timer: <b id="timer">${Math.round((Date.now() - d.startedAt) / 1000)}s</b></span></div>` : ''}
    <div class="steps">${steps}</div>
    <div class="split">
      <div class="card">
        <span class="eyebrow">Step ${d.step + 1} of ${STEP_NAMES.length}${d.staff ? ' · phone or counter order' : ''}</span>
        <h2 class="step-title">${STEP_NAMES[d.step]}</h2>
        ${d.aiNote && d.step > 0 ? aiNoteHTML(d) : ''}
        ${wizardStep(d)}
        ${d.error ? `<div class="error">${esc(d.error)}</div>` : ''}
        <div class="wiz-nav">
          ${d.step > 0 ? `<button class="btn-big" onclick="W.back()">Back</button>` : `<button class="btn-big" onclick="W.reset()">Start over</button>`}
          ${d.step < STEP_NAMES.length - 1
            ? `<button class="btn-big btn-primary" onclick="W.next()">Next</button>`
            : `<button class="btn-big btn-primary" onclick="W.submit()">${d.lane === 'green' ? 'Place order' : 'Send my request'}</button>`}
        </div>
        ${!staff ? `<p class="muted small" style="margin-top:14px">Rather talk to a person? <a href="tel:${digits(PHONE)}">Call me instead · ${PHONE}</a> or <a href="#callback">ask us to call you</a>.</p>` : ''}
      </div>
      <div id="pricebox">${priceBoxHTML(d)}</div>
    </div></div>`;
}

function wizardStep(d) {
  const r = db.rates;
  const chip = (on, act, label, extra = '') => `<button class="chip ${on ? 'on' : ''}" onclick="${act}">${esc(label)}${extra}</button>`;
  if (d.step === 0) {
    const card = (lane, dot, title, body, pricing) => `<button class="lane-card ${d.lane === lane ? 'on' : ''}" onclick="W.set('lane','${lane}',true)">
      <span class="lc-photo"><img src="${IMG[LANE_IMG[lane]]}" alt=""></span>
      <span class="lc-body"><b>${title}</b><span class="muted small">${body}</span><span class="pricing">${pricing}</span></span></button>`;
    return `${d.staff ? `<label>How did this order come in?</label><div class="chips" style="margin-bottom:16px">
        ${chip(d.channel === 'phone', "W.set('channel','phone',true)", 'Phone')}${chip(d.channel === 'counter', "W.set('channel','counter',true)", 'Counter / walk-in')}</div>` : ''}
      ${d.staff ? '' : aiFillBox(d)}
      <div class="lane-cards">
      ${card('green', 'dot-green', 'Classic', 'Menu cakes, cupcakes and pastries.', 'Exact price now')}
      ${card('yellow', 'dot-yellow', 'Custom cake', 'Choose size, flavor and decorations.', 'Instant price range')}
      ${card('red', 'dot-red', 'Showpiece', 'Weddings, sculpted or very large cakes.', 'Baker’s quote')}
      </div>`;
  }
  if (d.step === 1) {
    if (d.lane === 'green') {
      return r.menu.map((m) => `<div class="qty-row"><div><b>${esc(m.label)}</b><div class="muted small">${money(m.price)}</div></div>
        <div class="stepper"><button onclick="W.qty('${m.id}',-1)" aria-label="Fewer">−</button><span>${d.menu[m.id] || 0}</span>
        <button onclick="W.qty('${m.id}',1)" aria-label="More">+</button></div></div>`).join('');
    }
    if (d.lane === 'yellow') {
      return `<div class="field"><label>How many servings?</label><div class="chips">${r.servingOptions.map((s) => chip(d.servings === s, `W.set('servings',${s},true)`, String(s))).join('')}</div></div>
        <div class="field"><label>Cake flavor</label><div class="chips">${r.flavors.map((f) => chip(d.flavor === f.name, `W.set('flavor',${esc(JSON.stringify(f.name))},true)`, f.name, f.price ? `<small>+${money(f.price)}</small>` : '')).join('')}</div></div>
        <div class="field"><label>Filling</label><div class="chips">${r.fillings.map((f) => chip(d.filling === f.name, `W.set('filling',${esc(JSON.stringify(f.name))},true)`, f.name, f.price ? `<small>+${money(f.price)}</small>` : '')).join('')}</div></div>
        <div class="field"><label>Frosting color</label>${frostingChips(d)}</div>
        <div class="field"><label>Decorations</label><div class="chips">${r.addons.map((a) => chip(d.addons.includes(a.id), `W.toggleAddon('${a.id}')`, a.label, `<small>+${money(a.price)}</small>`)).join('')}</div></div>
        ${d.addons.includes('message') ? `<div class="field"><label for="w-msg">What should it say?</label><input id="w-msg" value="${esc(d.message)}" oninput="W.set('message',this.value,false,true)" placeholder="Happy Birthday Sam!"></div>` : ''}`;
    }
    return `<div class="field"><label>What’s the occasion?</label><div class="chips">${['Wedding', 'Anniversary', 'Corporate event', 'Sculpted / 3D cake', 'Other'].map((e) => chip(d.event === e, `W.set('event',${esc(JSON.stringify(e))},true)`, e)).join('')}</div></div>
      <div class="grid2" style="margin-top:14px"><div><label for="w-srv">About how many servings?</label><input id="w-srv" type="number" min="10" value="${esc(d.approxServings)}" oninput="W.set('approxServings',+this.value)"></div>
      <div><label for="w-bud">Your budget (optional)</label><input id="w-bud" type="number" min="0" value="${esc(d.budget)}" oninput="W.set('budget',this.value,false,true)" placeholder="e.g. 600"></div></div>`;
  }
  if (d.step === 2) {
    return `<div class="field"><label for="w-desc">Tell us about your cake in your own words</label>
        <textarea id="w-desc" oninput="W.set('description',this.value)" placeholder="Colors, theme, who it’s for, anything you’re picturing…">${esc(d.description)}</textarea>
        <div class="hint">On a phone, tap the microphone on your keyboard to speak instead of typing.</div></div>
      <div class="field"><label>Inspiration photos (up to 3)</label>
        <div class="photos">${d.photos.map((p, i) => `<div class="photo"><img src="${esc(p)}" alt="Inspiration photo ${i + 1}"><button onclick="W.removePhoto(${i})">✕</button></div>`).join('')}</div>
        ${d.photos.length < 3 ? `<label class="upload" style="margin-top:8px">Add a photo from your camera or gallery<input type="file" accept="image/*" multiple onchange="W.addPhotos(this.files)"></label>` : ''}</div>
      ${photoReadHTML(d)}
      ${d.lane === 'yellow' ? `<div class="field"><label for="w-bud">About how much would you like to spend? (optional)</label><input id="w-bud" type="number" min="0" value="${esc(d.budget)}" oninput="W.set('budget',this.value,false,true)" placeholder="e.g. 80"><div class="hint">We’ll show you what fits.</div></div>` : ''}
      <div class="field"><label for="w-all">Allergies or dietary needs</label><input id="w-all" value="${esc(d.allergy)}" oninput="W.set('allergy',this.value)" placeholder="e.g. nut allergy, dairy-free"><div class="hint">Any allergy note flags your order for a person to review.</div></div>`;
  }
  if (d.step === 3) {
    const min = d.staff ? todayISO() : addDays(todayISO(), 1);
    return `<div class="grid2"><div><label for="w-name">Your name</label><input id="w-name" autocomplete="name" value="${esc(d.name)}" oninput="W.set('name',this.value)"></div>
      <div><label for="w-phone">Phone number</label><input id="w-phone" type="tel" autocomplete="tel" value="${esc(d.phone)}" oninput="W.set('phone',this.value)" placeholder="302-555-0100"><div class="hint">Your phone number is your ID. No account needed.</div></div></div>
      <div class="field"><label for="w-email">Email (optional)</label><input id="w-email" type="email" value="${esc(d.email)}" oninput="W.set('email',this.value)"></div>
      <div class="field"><label for="w-date">Pickup date</label><input id="w-date" type="date" min="${min}" value="${esc(d.pickupDate)}" onchange="W.set('pickupDate',this.value,true)">
        <div class="hint">Closed Sundays.${d.lane === 'yellow' ? ` Pickups within ${db.rates.rushDays} days add a ${money(db.rates.rushFee)} rush fee.` : ''}</div></div>
      <div class="field"><label>Kitchen availability</label>${capacityStrip(d)}</div>
      <div class="field"><label>Pickup time</label><div class="chips">${['Morning (7–11)', 'Afternoon (11–3)', 'Late (3–close)'].map((t) => chip(d.pickupTime === t, `W.set('pickupTime',${esc(JSON.stringify(t))},true)`, t)).join('')}</div></div>`;
  }
  // review
  const fake = { lane: d.lane, spec: draftSpec(d) };
  return `<dl class="kv">
      <dt>Order type</dt><dd>${laneTag(d.lane)}</dd>
      <dt>Details</dt><dd>${specSummary(fake).map(esc).join('<br>') || '—'}</dd>
      ${d.description ? `<dt>Your words</dt><dd>${esc(d.description)}</dd>` : ''}
      ${d.photos.length ? `<dt>Photos</dt><dd>${d.photos.length} attached</dd>` : ''}
      ${d.allergy ? `<dt>Allergies</dt><dd>${esc(d.allergy)}</dd>` : ''}
      <dt>Pickup</dt><dd>${fmtDay(d.pickupDate)} · ${esc(d.pickupTime)}</dd>
      <dt>Name</dt><dd>${esc(d.name)}</dd><dt>Phone</dt><dd>${esc(fmtPhone(d.phone))}</dd>
    </dl>
    <p class="muted small" style="margin-top:14px">${d.lane === 'green' ? 'Your order is confirmed as soon as you place it. Pay at pickup.'
      : 'Nothing is charged now. A baker will review your request and send a quote for you to approve.'}</p>`;
}
function draftSpec(d) {
  if (d.lane === 'green') return { menu: { ...d.menu } };
  if (d.lane === 'yellow') return { servings: d.servings, flavor: d.flavor, filling: d.filling, frosting: d.frosting || 'White', addons: [...d.addons], message: d.addons.includes('message') ? d.message : '' };
  return { event: d.event, approxServings: d.approxServings };
}

function resizeImage(file) {
  return new Promise((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => {
      const img = new Image();
      img.onload = () => {
        const s = Math.min(1, 640 / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        res(c.toDataURL('image/jpeg', 0.62));
      };
      img.onerror = rej; img.src = fr.result;
    };
    fr.onerror = rej; fr.readAsDataURL(file);
  });
}

const W = {
  set(k, v, rerender = false, price = false) {
    const d = draft(); d[k] = v; d.error = '';
    if (rerender) render(); else if (price) $('#pricebox').innerHTML = priceBoxHTML(d);
  },
  startLane(lane) { const d = newDraft(false); d.lane = lane; d.step = 1; drafts.customer = d; go('#order'); },
  qty(id, delta) { const d = draft(); d.menu[id] = Math.max(0, (d.menu[id] || 0) + delta); d.error = ''; render(); },
  toggleAddon(id) {
    const d = draft(); d.addons = d.addons.includes(id) ? d.addons.filter((x) => x !== id) : [...d.addons, id]; render();
  },
  swap(from, to) { const d = draft(); d.addons = d.addons.filter((x) => x !== from); if (!d.addons.includes(to)) d.addons.push(to); render(); },
  async addPhotos(files) {
    const d = draft();
    for (const f of [...files].slice(0, 3 - d.photos.length)) {
      try { d.photos.push(await resizeImage(f)); } catch (e) { toast('That file could not be read as an image.'); }
    }
    render();
  },
  removePhoto(i) { draft().photos.splice(i, 1); render(); },
  validate(d) {
    if (d.step === 0 && !d.lane) return 'Choose an order type.';
    if (d.step === 1 && d.lane === 'green' && !Object.values(d.menu).some((q) => q > 0)) return 'Add at least one item.';
    if (d.step === 1 && d.lane === 'yellow' && d.addons.includes('message') && !d.message.trim()) return 'Tell us what the writing should say, or turn off “Written message”.';
    if (d.step === 2 && d.lane === 'red' && d.description.trim().length < 10) return 'Please describe your cake so the baker can quote it.';
    if (d.step === 3) {
      if (!d.name.trim()) return 'Please enter a name.';
      if (digits(d.phone).length !== 10) return 'Please enter a 10-digit phone number.';
      if (!d.pickupDate) return 'Please choose a pickup date.';
      if (isSunday(d.pickupDate)) return 'We’re closed on Sundays. Please pick another day.';
      if (!d.staff && d.lane !== 'green' && typeof dayStatus === 'function' && dayStatus(d.pickupDate).full) return 'That day is fully booked for custom cakes. Please pick another day, or ask us to call you.';
      if (d.pickupDate < (d.staff ? todayISO() : addDays(todayISO(), 1))) return 'Please choose a date from tomorrow on.';
    }
    return '';
  },
  next() { const d = draft(); d.error = W.validate(d); if (!d.error) d.step++; render(); },
  back() { const d = draft(); d.error = ''; d.step = Math.max(0, d.step - 1); render(); },
  reset() { drafts[route().startsWith('staff') ? 'staff' : 'customer'] = null; render(); },
  submit() {
    const d = draft();
    for (let s = 0; s < 4; s++) { const e = W.validate({ ...d, step: s }); if (e) { d.error = e; d.step = s; render(); return; } }
    const now = Date.now();
    const o = {
      id: nextOrderId(), createdAt: now, channel: d.channel, lane: d.lane,
      customer: { name: d.name.trim(), phone: fmtPhone(d.phone), email: d.email.trim() },
      pickupDate: d.pickupDate, pickupTime: d.pickupTime, spec: draftSpec(d),
      description: d.description.trim(), budget: d.lane === 'green' ? '' : d.budget, allergy: d.allergy.trim(), photos: [...d.photos],
      status: 'received', quotes: [], messages: [], history: [], depositPaid: false, approvedVersion: null,
      entrySeconds: d.staff ? Math.round((now - d.startedAt) / 1000) : null, trial: d.trial || null,
    };
    log(o, `Order received via ${o.channel}`, d.staff ? 'Staff' : 'Customer');
    if (o.lane === 'green') {
      const lines = greenLines(o.spec, db.rates);
      o.quotes.push({ v: 1, lines, total: sum(lines), designScore: 0, note: '', at: now, status: 'approved' });
      o.approvedVersion = 1; o.status = 'approved';
      log(o, `Classic order auto-confirmed at ${money(sum(lines))}`, 'System');
    } else if (o.lane === 'yellow') {
      o.estimate = estimateRange(customLines(o.spec, o.pickupDate, db.rates), db.rates);
    }
    db.orders.push(o);
    if (!save()) { db.orders.pop(); db.nextId--; return; }
    drafts[d.staff ? 'staff' : 'customer'] = null;
    if (d.staff) { toast(`Saved ${o.id} · entered in ${o.entrySeconds}s`); go(d.trial ? '#trial' : '#staff-order-' + o.id); }
    else { verified.add(o.id); go('#done-' + o.id); }
  },
};
setInterval(() => { const t = $('#timer'); const d = drafts.staff; if (t && d) t.textContent = Math.round((Date.now() - d.startedAt) / 1000) + 's'; }, 1000);

/* ---------- confirmation, tracking, passport ---------- */
const verified = new Set();
function trackerHTML(o) {
  const idx = TRACK_IDX[o.status];
  return `<div class="tracker">${TRACK.map((t, i) => `<div class="${i <= idx ? 'done' : ''} ${i === idx ? 'now' : ''}">${t}</div>`).join('')}</div>`;
}
function viewDone(id) {
  const o = getOrder(id);
  if (!o) return `<div class="wrap" style="padding-block:60px"><div class="card">Order not found. <a href="#home">Home</a></div></div>`;
  const msg = o.lane === 'green' ? `Confirmed at <b>${money(orderTotal(o))}</b>. Pay when you pick it up.`
    : o.lane === 'yellow' ? `Your estimate is <b>${money(o.estimate[0])}–${money(o.estimate[1])}</b>. A baker will send your final quote by <b>${fmtTime(replyDue(o))}</b>.`
      : `A baker will reply with your quote by <b>${fmtTime(replyDue(o))}</b>.`;
  return `<section class="done-hero">
    <div class="hero-photo"><img src="${IMG.candles}" alt="Candles being lit on a birthday cake"></div>
    <div class="done-copy">
      <span class="eyebrow" style="margin:0">${o.lane === 'green' ? 'Order confirmed' : 'Request received'}</span>
      <h1>Your cake has a home.</h1>
      <p style="margin:0;color:var(--ink-2)">${msg}</p>
      ${stubHTML(o, trackerHTML(o))}
      <div class="row"><a class="btn btn-primary btn-big" href="#passport-${o.id}">Track this order</a><a class="btn btn-big" href="#home">Back to the shop</a></div>
      ${phoneMock(o, { first: true })}
      <p class="muted small" style="margin:0">Keep your Cake Passport number to check on your order any time.</p>
    </div>
  </section>${footHTML()}`;
}
let trackResult = null;
function viewTrack() {
  let res = '';
  if (trackResult) {
    const list = trackResult.map((id) => getOrder(id)).filter(Boolean).sort((a, b) => b.createdAt - a.createdAt);
    res = list.length ? `<div class="card"><h3>Your orders</h3>${list.map((o) => `
      <div class="qty-row"><div><b>${o.id}</b> ${statusTag(o.status)}<div class="muted small">${specSummary(o).map(esc).join(' · ')}</div>
      <div class="muted small">Pickup ${fmtDay(o.pickupDate)}</div></div>
      <div class="row"><a class="btn" href="#passport-${o.id}">Open</a><button class="btn-primary" onclick="C.reorder('${o.id}')">Order again</button></div></div>`).join('')}</div>`
      : `<div class="card"><p>No orders found for that phone number. Try again, or <a href="tel:${digits(PHONE)}">call us at ${PHONE}</a>.</p></div>`;
  }
  return `<div style="max-width:720px;margin:0 auto">
    <div class="card"><h2>Track or reorder</h2>
      <p class="muted">Enter the phone number you ordered with. Add your Cake Passport number to jump straight to one order.</p>
      <div class="grid2"><div><label for="t-phone">Phone number</label><input id="t-phone" type="tel" placeholder="302-555-0100"></div>
      <div><label for="t-id">Cake Passport # (optional)</label><input id="t-id" placeholder="BB-1001"></div></div>
      <div class="row" style="margin-top:14px"><button class="btn-primary btn-big" onclick="C.lookup()">Find my orders</button></div>
      <p class="muted small" style="margin-top:10px">Same as last year? Find your old order and tap <b>Order again</b>.</p>
    </div>${res}</div>`;
}
function viewPassport(id) {
  const o = getOrder(id);
  if (!o || !verified.has(id)) {
    return `<div class="card" style="max-width:520px;margin:0 auto"><h2>Open ${esc(id || 'your order')}</h2>
      <p class="muted">To protect your details, confirm the phone number on this order.</p>
      <label for="v-phone">Phone number</label><input id="v-phone" type="tel">
      <div class="row" style="margin-top:12px"><button class="btn-primary" onclick="C.verify('${esc(id)}')">Open my order</button></div></div>`;
  }
  const q = latestQuote(o);
  const quoteHTML = q ? `<div class="card"><div class="row"><h3 style="margin:0">Quote v${q.v}</h3><span class="spacer"></span>
      ${q.status === 'approved' ? '<span class="tag t-green">Approved</span>' : q.status === 'sent' ? '<span class="tag t-amber">Waiting for you</span>' : '<span class="tag t-gray">Replaced</span>'}</div>
      ${q.note ? `<p class="warn-box">${esc(q.note)}</p>` : ''}
      ${quoteDiffHTML(o)}
      <table class="lines" style="margin-top:10px">${q.lines.map((l) => `<tr><td>${esc(l.label)}</td><td>${money(l.amount)}</td></tr>`).join('')}
      <tr class="total"><td>Total</td><td>${money(q.total)}</td></tr></table>
      ${speakButton(o)}
      ${o.status === 'quote_ready' && q.status === 'sent' ? `
        <p class="muted small">Approving locks this price for 7 days. A ${db.rates.depositPct}% deposit (${money(q.total * db.rates.depositPct / 100)}) starts the bake, payable at the counter or by phone.</p>
        <div class="row"><button class="btn-green btn-big" onclick="C.approve('${o.id}')">Approve ${money(q.total)}</button>
        <button class="btn-big" onclick="document.getElementById('chg').hidden=false">Suggest a change</button></div>
        <div id="chg" hidden style="margin-top:10px"><textarea id="chg-text" placeholder="What would you like changed?"></textarea>
        <button class="btn-primary" style="margin-top:8px" onclick="C.requestChange('${o.id}')">Send to the baker</button></div>` : ''}
      ${o.priceLockedUntil && q.status === 'approved' ? `<p class="muted small">Price locked until ${fmtTime(o.priceLockedUntil)}. Deposit ${o.depositPaid ? 'received ✓' : `due: ${money(q.total * db.rates.depositPct / 100)}`}.</p>` : ''}
    </div>`
    : o.lane === 'yellow' ? `<div class="card"><h3>Your estimate</h3><div class="price-big">${money(o.estimate[0])}–${money(o.estimate[1])}</div><p class="muted">A baker will send your final quote by ${fmtTime(replyDue(o))}.</p></div>`
      : `<div class="card"><h3>Quote in progress</h3><p class="muted">A baker will reply by ${fmtTime(replyDue(o))}.</p></div>`;
  const msgs = o.messages.filter((m) => !m.internal);
  return `<div style="max-width:900px;margin:0 auto">
    <div class="card"><div class="row"><div><div class="stub-label">Cake Passport</div><div class="passport-id">${o.id}</div></div><span class="spacer"></span>${laneTag(o.lane)} ${statusTag(o.status)}</div>
      ${trackerHTML(o)}<p class="status-line">${CUSTOMER_STATUS[o.status]}</p>
      <dl class="kv"><dt>Pickup</dt><dd>${fmtDay(o.pickupDate)} · ${esc(o.pickupTime)}</dd><dt>Details</dt><dd>${specSummary(o).map(esc).join('<br>')}</dd>
      ${o.description ? `<dt>Your words</dt><dd>${esc(o.description)}</dd>` : ''}${o.allergy ? `<dt>Allergies</dt><dd>${esc(o.allergy)}</dd>` : ''}</dl>
      ${o.photos.length ? `<div class="photos" style="margin-top:10px">${o.photos.map((p) => `<div class="photo"><img src="${esc(p)}" alt="Inspiration photo"></div>`).join('')}</div>` : ''}
    </div>
    ${o.lane !== 'green' ? `<div class="card cake-card">${cakeSVG(o.lane, o.spec)}<p class="small muted" style="margin:0;text-align:center">How your cake will look, roughly. The baker finishes every detail by hand.</p></div>` : ''}
    ${quoteHTML}
    <div class="card"><h3>Messages with the bakery</h3>
      <div class="thread">${msgs.length ? msgs.map((m) => `<div class="msg ${m.from}"><div>${esc(m.text)}</div><div class="meta">${m.from === 'staff' ? "Bing's" : 'You'} · ${fmtTime(m.at)}</div></div>`).join('') : '<p class="muted">No messages yet.</p>'}</div>
      <div class="row" style="margin-top:10px"><input id="c-msg" placeholder="Write a message…" style="flex:1"><button class="btn-primary" onclick="C.send('${o.id}')">Send</button></div>
    </div>
    <div class="row" style="margin-top:16px"><button onclick="C.reorder('${o.id}')">Order this again</button><a class="btn" href="tel:${digits(PHONE)}">Call ${PHONE}</a></div>
  </div>`;
}

const C = {
  lookup() {
    const ph = digits($('#t-phone').value), id = $('#t-id').value.trim().toUpperCase();
    if (ph.length !== 10) { toast('Enter the 10-digit phone number you ordered with.'); return; }
    const mine = db.orders.filter((o) => digits(o.customer.phone) === ph);
    mine.forEach((o) => verified.add(o.id));
    if (id && mine.some((o) => o.id === id)) { go('#passport-' + id); return; }
    trackResult = mine.map((o) => o.id); render();
  },
  verify(id) {
    const o = getOrder(id);
    if (o && digits(o.customer.phone) === digits($('#v-phone').value)) { verified.add(id); render(); } else toast('That phone number doesn’t match this order.');
  },
  approve(id) {
    const o = getOrder(id), q = latestQuote(o);
    q.status = 'approved'; o.approvedVersion = q.v; o.status = 'approved';
    o.priceLockedUntil = Date.now() + 7 * 864e5;
    log(o, `Customer approved quote v${q.v} (${money(q.total)}). Price locked 7 days.`, 'Customer');
    save(); toast('Approved! Your cake is now scheduled.'); render();
  },
  requestChange(id) {
    const text = $('#chg-text').value.trim();
    if (!text) { toast('Tell the baker what you’d like changed.'); return; }
    const o = getOrder(id);
    o.messages.push({ from: 'customer', internal: false, text, at: Date.now() });
    o.status = 'change_requested'; o.lastCustomerActionAt = Date.now();
    log(o, 'Customer requested a change', 'Customer');
    save(); toast('Sent. The baker will reply within 1 business day.'); render();
  },
  send(id) {
    const el = $('#c-msg'); const text = el.value.trim(); if (!text) return;
    const o = getOrder(id);
    o.messages.push({ from: 'customer', internal: false, text, at: Date.now() });
    save(); render();
  },
  reorder(id) {
    const o = getOrder(id), d = newDraft(false);
    Object.assign(d, { lane: o.lane, name: o.customer.name, phone: o.customer.phone, email: o.customer.email || '', description: o.description, allergy: o.allergy, budget: o.budget || '' });
    if (o.lane === 'green') d.menu = { ...o.spec.menu };
    else if (o.lane === 'yellow') Object.assign(d, { servings: o.spec.servings, flavor: o.spec.flavor, filling: o.spec.filling, frosting: o.spec.frosting || 'White', addons: [...o.spec.addons], message: o.spec.message || '' });
    else Object.assign(d, { event: o.spec.event, approxServings: o.spec.approxServings });
    d.step = 1; drafts.customer = d;
    toast('Copied your past order. Change anything you like, then pick a new pickup date.');
    go('#order');
  },
};

/* ================= STAFF ================= */
const sf = { q: '', status: 'open', date: '', lane: '' };
function viewStaff() {
  const t = todayISO();
  const open = db.orders.filter((o) => !['picked_up', 'declined'].includes(o.status));
  const stats = [
    ['Need a reply', open.filter(needsStaff).length, open.some(isOverdue)],
    ['Waiting on customer', open.filter((o) => o.status === 'quote_ready').length],
    ['In the kitchen', open.filter((o) => IN_KITCHEN.includes(o.status)).length],
    ['Pickups today', db.orders.filter((o) => o.pickupDate === t && o.status !== 'declined').length],
  ];
  const q = sf.q.trim().toLowerCase(), qd = digits(q);
  let list = db.orders.filter((o) => {
    if (sf.status === 'open' && ['picked_up', 'declined'].includes(o.status)) return false;
    if (sf.status === 'action' && !needsStaff(o)) return false;
    if (!['open', 'action', 'all'].includes(sf.status) && o.status !== sf.status) return false;
    if (sf.date && o.pickupDate !== sf.date) return false;
    if (sf.lane && o.lane !== sf.lane) return false;
    if (q && !(o.id.toLowerCase().includes(q) || o.customer.name.toLowerCase().includes(q) || (qd.length >= 3 && digits(o.customer.phone).includes(qd)))) return false;
    return true;
  });
  list.sort((a, b) => (isOverdue(b) - isOverdue(a)) || (needsStaff(b) - needsStaff(a)) || a.pickupDate.localeCompare(b.pickupDate));
  const opt = (v, l, cur) => `<option value="${v}" ${cur === v ? 'selected' : ''}>${l}</option>`;
  return `
  <div class="page-head"><div><div class="eyebrow">Staff · ${fmtDay(t)}</div><h1>Orders</h1></div>${syncPill()}<span class="spacer"></span>
    <a class="btn btn-primary" href="#staff-new" onclick="drafts.staff=null">+ Quick phone order</a>
    <a class="btn" href="#staff-scan">Scan a paper slip</a>
    <a class="btn" href="#staff-wholesale">Wholesale</a>
    <a class="btn" href="#trial">Time trial</a>
    <a class="btn" href="#counter">Pickup counter</a>
    <a class="btn" href="#staff-box">Pickup Box</a>
    <a class="btn" href="#print-${t}">Today’s Pickup Sheet</a>
    <a class="btn" href="#owner">Owner dashboard</a>
    <a class="btn" href="#staff-rates">Rate card</a></div>
  <div class="stats">${stats.map(([l, n, alert]) => `<div class="stat ${alert ? 'alert' : ''}"><b>${n}</b>${l}${alert ? ' · <span class="tag t-red">overdue</span>' : ''}</div>`).join('')}</div>
  ${callbacksPanel()}
  <div class="filters">
    <input id="sf-q" placeholder="Search Cake Passport #, name, or phone" value="${esc(sf.q)}" oninput="S.filter('q',this.value)">
    <select onchange="S.filter('status',this.value,true)">${opt('open', 'All open', sf.status)}${opt('action', 'Needs reply', sf.status)}${Object.keys(STATUS).map((s) => opt(s, STATUS[s][0], sf.status)).join('')}${opt('all', 'Everything', sf.status)}</select>
    <input type="date" value="${sf.date}" onchange="S.filter('date',this.value,true)" title="Pickup date">
    <select onchange="S.filter('lane',this.value,true)">${opt('', 'All lanes', sf.lane)}${opt('green', 'Classic', sf.lane)}${opt('yellow', 'Custom', sf.lane)}${opt('red', 'Showpiece', sf.lane)}</select>
  </div>
  <div class="table-wrap" id="staff-table">${staffTable(list)}</div>
  <div class="row" style="margin-top:14px"><button class="btn-sm" onclick="S.exportCSV()">Copy all orders for a spreadsheet</button>
    <span class="spacer"></span><button class="btn-sm" onclick="Demo.toggle(true)">Presenter mode (Shift+D)</button><button class="btn-sm btn-danger" onclick="S.resetDemo()">Reset demo data</button></div>`;
}
function staffTable(list) {
  if (!list.length) return `<p style="padding:16px" class="muted">No orders match.</p>`;
  return `<table class="table"><thead><tr><th>Passport</th><th>Customer</th><th>Pickup</th><th>Type</th><th>Status</th><th>Flags</th><th>Total</th></tr></thead><tbody>
    ${list.map((o) => `<tr class="click" onclick="go('#staff-order-${o.id}')"><td><b>${o.id}</b><div class="muted small">${o.channel}</div></td>
      <td>${esc(o.customer.name)}<div class="muted small">${esc(o.customer.phone)}</div></td>
      <td>${fmtDay(o.pickupDate)}<div class="muted small">${esc(o.pickupTime)}</div></td>
      <td>${laneTag(o.lane)}</td><td>${statusTag(o.status)}${needsStaff(o) ? `<div class="muted small">reply by ${fmtTime(replyDue(o))}</div>` : ''}</td>
      <td><div class="flags">${flagTags(o)}</div></td><td>${orderTotal(o) != null ? money(orderTotal(o)) : o.estimate ? `<span class="muted">${money(o.estimate[0])}–${money(o.estimate[1])}</span>` : '—'}</td></tr>`).join('')}
  </tbody></table>`;
}

let qb = null, msgTab = 'customer';
function initQB(o) {
  const r = db.rates, last = latestQuote(o);
  if (last) qb = { id: o.id, ds: last.designScore || 0, lines: last.lines.map((l) => ({ ...l })), note: '' };
  else if (o.lane === 'yellow') qb = { id: o.id, ds: 3, lines: [...customLines(o.spec, o.pickupDate, r, iso(new Date(o.createdAt))), dsLine(3, r)], note: '' };
  else if (o.lane === 'red') qb = { id: o.id, ds: 5, lines: [{ label: `${o.spec.event} cake, about ${o.spec.approxServings} servings`, amount: Math.round(o.spec.approxServings * r.perServing) }, dsLine(5, r)], note: '' };
  else qb = { id: o.id, ds: 0, lines: greenLines(o.spec, r), note: '' };
}
function viewStaffOrder(id) {
  const o = getOrder(id);
  if (!o) return `<div class="card">Order not found. <a href="#staff">Back</a></div>`;
  if (!qb || qb.id !== id) initQB(o);
  const r = db.rates;
  const next = { approved: ['Start baking', 'baking'], baking: ['Mark ready for pickup', 'ready'], ready: ['Picked up', 'picked_up'] }[o.status];
  const msgs = o.messages.filter((m) => (msgTab === 'internal' ? m.internal : !m.internal));
  const inProd = IN_KITCHEN.includes(o.status);
  return `
  <div class="row" style="margin-bottom:12px"><a class="back" href="#staff">← All orders</a></div>
  <div class="card"><div class="order-head"><div><div class="stub-label">Cake Passport</div><div class="passport-id">${o.id}</div></div>
    <span class="spacer"></span>${laneTag(o.lane)} ${statusTag(o.status)} <div class="flags">${flagTags(o)}</div></div>
    <div class="muted small">Came in via ${o.channel} · ${fmtTime(o.createdAt)}${o.entrySeconds ? ` · entered in ${o.entrySeconds}s` : ''}${needsStaff(o) ? ` · <b>reply by ${fmtTime(replyDue(o))}</b>` : ''}</div>
    ${o.allergy ? `<div class="red-box" style="margin-top:10px">Allergy: ${esc(o.allergy)}. A person must confirm before baking.</div>` : ''}
    <div class="row" style="margin-top:14px">
      ${next ? `<button class="btn-primary" onclick="S.setStatus('${o.id}','${next[1]}')">${next[0]}</button>` : ''}
      ${o.status !== 'declined' && o.status !== 'picked_up' ? `<button class="btn-danger" onclick="S.decline('${o.id}')">Can’t do it</button>` : ''}
      ${o.approvedVersion ? `<label class="check"><input type="checkbox" ${o.depositPaid ? 'checked' : ''} onchange="S.deposit('${o.id}',this.checked)"> Deposit received (${r.depositPct}%: ${money((approvedQuote(o) || { total: 0 }).total * r.depositPct / 100)})</label>` : ''}
      <span class="spacer"></span><a class="btn btn-sm" href="#print-${o.pickupDate}">Pickup Sheet for ${fmtDay(o.pickupDate)}</a>
    </div>
  </div>
  <div class="split" style="margin-top:16px">
    <div>
      ${assistCard(o)}
      <div class="card"><h3>Quote builder</h3>
        ${o.lane !== 'green' ? `<label>Design Score (decorating labor)</label><div class="ds-btns">${[1, 2, 3, 4, 5].map((n) => `<button class="${qb.ds === n ? 'on' : ''}" onclick="S.ds(${n})">${n}<small>${DS_TEXT[n]} · ${money(r.designScore[n])}</small></button>`).join('')}</div>` : '<p class="muted small">Classic orders are priced from the menu. Adjust only if something changed.</p>'}
        <div style="margin-top:14px" id="qb-lines">${qbLines()}</div>
        <div class="row"><button class="btn-sm" onclick="S.addLine()">+ Add line</button><span class="spacer"></span><span class="muted small">Total</span> <span class="qb-total" id="qb-total">${money(sum(qb.lines))}</span></div>
        ${o.budget ? `<p class="muted small">Customer’s budget: ${money(o.budget)}</p>` : ''}
        <div class="field" style="margin-top:12px"><label for="qb-note">Note to customer (e.g. a decoration you can’t do, and what you suggest instead)</label>
          <textarea id="qb-note" style="min-height:70px" oninput="qb.note=this.value" placeholder="Optional">${esc(qb.note)}</textarea></div>
        <div class="row" style="margin-top:10px"><button class="btn-primary" onclick="S.sendQuote('${o.id}')">${o.quotes.length ? `Send revised quote (v${o.quotes.length + 1})` : 'Send quote (v1)'}</button>
          ${o.quotes.length ? `<button class="btn-sm" onclick="qb=null;render()">Reset to latest</button>` : ''}</div>
        ${inProd ? `<p class="warn-box small">This order is approved. A revised quote pulls it out of the kitchen until the customer approves the new price.</p>` : ''}
      </div>
      <div class="card"><h3>Version history</h3>
        ${o.quotes.length ? `<ul class="versions">${o.quotes.slice().reverse().map((q) => `<li><span><b>v${q.v}</b> · ${fmtTime(q.at)}${q.designScore ? ` · Design Score ${q.designScore}` : ''}${q.note ? `<div class="muted small">“${esc(q.note)}”</div>` : ''}</span>
          <span>${money(q.total)} ${q.v === o.approvedVersion ? '<span class="tag t-green">approved</span>' : q.status === 'sent' ? '<span class="tag t-amber">sent</span>' : '<span class="tag t-gray">replaced</span>'}</span></li>`).join('')}</ul>`
          : `<p class="muted">No quote yet.${o.estimate ? ` Customer saw an estimate of ${money(o.estimate[0])}–${money(o.estimate[1])}.` : ''}</p>`}
      </div>
      <div class="card"><h3>Messages</h3>
        <div class="tabs"><button class="btn-sm ${msgTab === 'customer' ? 'on' : ''}" onclick="msgTab='customer';render()">With customer</button>
          <button class="btn-sm ${msgTab === 'internal' ? 'on' : ''}" onclick="msgTab='internal';render()">Internal notes (staff only)</button></div>
        <div class="thread">${msgs.length ? msgs.map((m) => `<div class="msg ${m.internal ? 'internal' : m.from}"><div>${esc(m.text)}</div><div class="meta">${m.internal ? 'Internal' : m.from === 'staff' ? 'Staff' : 'Customer'} · ${fmtTime(m.at)}</div></div>`).join('') : '<p class="muted">Nothing here yet.</p>'}</div>
        <div class="row" style="margin-top:10px"><input id="s-msg" placeholder="${msgTab === 'internal' ? 'Note for the team (customer never sees this)…' : 'Message the customer…'}" style="flex:1">
          <button class="btn-primary" onclick="S.send('${o.id}')">${msgTab === 'internal' ? 'Add note' : 'Send'}</button></div>
      </div>
    </div>
    <div>
      <div class="card"><h3>Order details</h3>
        ${o.lane !== 'green' ? `<div class="cake-card inset">${cakeSVG(o.lane, o.spec)}</div>` : ''}
        <div class="field"><label for="e-name">Name</label><input id="e-name" value="${esc(o.customer.name)}"></div>
        <div class="field"><label for="e-phone">Phone</label><input id="e-phone" value="${esc(o.customer.phone)}"></div>
        <div class="grid2" style="margin-top:14px"><div><label for="e-date">Pickup date</label><input id="e-date" type="date" value="${o.pickupDate}"></div>
          <div><label for="e-time">Time</label><select id="e-time">${['Morning (7–11)', 'Afternoon (11–3)', 'Late (3–close)'].map((t) => `<option ${o.pickupTime === t ? 'selected' : ''}>${t}</option>`).join('')}</select></div></div>
        <div class="field"><label for="e-all">Allergies</label><input id="e-all" value="${esc(o.allergy)}"></div>
        <div class="field"><label for="e-desc">Customer’s description</label><textarea id="e-desc">${esc(o.description)}</textarea></div>
        <div class="field"><label>Specs</label><div>${specSummary(o).map(esc).join('<br>')}</div></div>
        ${o.photos.length ? `<div class="field"><label>Photos</label><div class="photos">${o.photos.map((p) => `<div class="photo"><img src="${esc(p)}" alt="Inspiration photo"></div>`).join('')}</div></div>` : ''}
        <button class="btn-primary" style="margin-top:14px" onclick="S.saveEdits('${o.id}')">Save changes</button>
      </div>
      ${smsCard(o)}
      <div class="card"><h3>History</h3><ul class="history">${o.history.slice().reverse().map((h) => `<li><span>${fmtTime(h.at)}</span>${esc(h.who)}: ${esc(h.text)}</li>`).join('')}</ul></div>
    </div>
  </div>`;
}
function qbLines() {
  return qb.lines.map((l, i) => `<div class="qb-line"><input value="${esc(l.label)}" oninput="qb.lines[${i}].label=this.value" aria-label="Line item">
    <input type="number" step="0.5" value="${l.amount}" oninput="S.amt(${i},this.value)" aria-label="Amount"><button class="btn-sm" onclick="S.removeLine(${i})" aria-label="Remove line">✕</button></div>`).join('');
}

const S = {
  filter(k, v, now) {
    sf[k] = v;
    if (now) { render(); return; }
    clearTimeout(S._t); S._t = setTimeout(() => { const pos = $('#sf-q').selectionStart; render(); const el = $('#sf-q'); el.focus(); el.setSelectionRange(pos, pos); }, 150);
  },
  ds(n) {
    qb.ds = n; const line = dsLine(n, db.rates);
    const i = qb.lines.findIndex((l) => l.ds);
    if (i >= 0) qb.lines[i] = line; else qb.lines.push(line);
    render();
  },
  amt(i, v) { qb.lines[i].amount = +v || 0; $('#qb-total').textContent = money(sum(qb.lines)); },
  addLine() { qb.lines.push({ label: 'Adjustment', amount: 0 }); $('#qb-lines').innerHTML = qbLines(); },
  removeLine(i) { qb.lines.splice(i, 1); $('#qb-lines').innerHTML = qbLines(); $('#qb-total').textContent = money(sum(qb.lines)); },
  async sendQuote(id) {
    const o = getOrder(id);
    const lines = qb.lines.filter((l) => l.label.trim()).map((l) => ({ label: l.label.trim(), amount: +l.amount || 0, ...(l.ds ? { ds: true } : {}) }));
    if (!lines.length) { toast('Add at least one line.'); return; }
    const total = sum(lines);
    if (total <= 0) { toast('The total must be more than $0.'); return; }
    const inProd = IN_KITCHEN.includes(o.status);
    if (inProd && !(await ask('This order is already approved. Sending a new price pulls it from the kitchen until the customer approves again.', { ok: 'Send revised quote' }))) return;
    o.quotes.forEach((q) => { if (q.status === 'sent') q.status = 'superseded'; });
    const q = { v: o.quotes.length + 1, lines, total, designScore: o.lane === 'green' ? 0 : qb.ds, note: qb.note.trim(), at: Date.now(), status: 'sent' };
    o.quotes.push(q); o.status = 'quote_ready';
    if (q.note) o.messages.push({ from: 'staff', internal: false, text: q.note, at: q.at });
    log(o, `Quote v${q.v} sent: ${money(total)}${inProd ? ' (revised after approval; pulled from kitchen until re-approved)' : ''}`);
    save(); qb = null; toast(`Quote v${q.v} sent to ${o.customer.name}`); render();
  },
  async setStatus(id, s) {
    const o = getOrder(id);
    if (s === 'baking' && o.allergy && !(await ask(`Allergy on this order: “${o.allergy}”. Has a person confirmed it?`, { ok: 'Yes, start baking' }))) return;
    o.status = s; log(o, `Moved to ${STATUS[s][0]}`); save(); render();
  },
  async decline(id) {
    const reason = await ask('Why can’t we take this order? The customer will see this message.', { ok: 'Decline order', input: true, placeholder: 'e.g. We’re fully booked that weekend. Could you pick Sunday the 15th?' });
    if (reason === null) return;
    const o = getOrder(id);
    o.status = 'declined';
    if (reason.trim()) o.messages.push({ from: 'staff', internal: false, text: reason.trim(), at: Date.now() });
    log(o, 'Declined' + (reason.trim() ? `: ${reason.trim()}` : '')); save(); render();
  },
  deposit(id, v) { const o = getOrder(id); o.depositPaid = v; log(o, v ? 'Deposit received' : 'Deposit unmarked'); save(); render(); },
  send(id) {
    const text = $('#s-msg').value.trim(); if (!text) return;
    const o = getOrder(id);
    o.messages.push({ from: 'staff', internal: msgTab === 'internal', text, at: Date.now() });
    save(); render();
  },
  saveEdits(id) {
    const o = getOrder(id), changed = [];
    const upd = (label, get, set, val) => { if (String(get()) !== String(val)) { set(val); changed.push(label); } };
    upd('name', () => o.customer.name, (v) => { o.customer.name = v; }, $('#e-name').value.trim());
    upd('phone', () => o.customer.phone, (v) => { o.customer.phone = v; }, fmtPhone($('#e-phone').value));
    upd('pickup date', () => o.pickupDate, (v) => { o.pickupDate = v; }, $('#e-date').value);
    upd('pickup time', () => o.pickupTime, (v) => { o.pickupTime = v; }, $('#e-time').value);
    upd('allergies', () => o.allergy, (v) => { o.allergy = v; }, $('#e-all').value.trim());
    upd('description', () => o.description, (v) => { o.description = v; }, $('#e-desc').value.trim());
    if (!changed.length) { toast('No changes.'); return; }
    log(o, 'Edited ' + changed.join(', ')); save(); toast('Saved.'); render();
  },
  exportCSV() {
    const rows = [['Passport', 'Created', 'Channel', 'Type', 'Status', 'Name', 'Phone', 'Pickup date', 'Pickup time', 'Total', 'Deposit paid', 'Allergies', 'Details']];
    db.orders.forEach((o) => rows.push([o.id, new Date(o.createdAt).toISOString(), o.channel, LANE[o.lane][0], STATUS[o.status][0], o.customer.name, o.customer.phone,
      o.pickupDate, o.pickupTime, orderTotal(o) ?? '', o.depositPaid ? 'yes' : 'no', o.allergy, specSummary(o).join('; ')]));
    const csv = rows.map((r) => r.map((c) => `"${String(c ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
    const fallback = () => ask('Select all of this and copy it, then paste it into a spreadsheet:', { ok: 'Done', input: true })
      .then(() => {});
    try {
      navigator.clipboard.writeText(csv).then(() => toast(`Copied ${db.orders.length} orders. Paste into Excel or Google Sheets.`), () => { fallback(); setTimeout(() => { const t = $('#modal-input'); if (t) { t.value = csv; t.select(); } }); });
    } catch (e) { fallback(); setTimeout(() => { const t = $('#modal-input'); if (t) { t.value = csv; t.select(); } }); }
  },
  async resetDemo() {
    if (!(await ask('Replace all orders with the fictional demo data?', { ok: 'Reset demo data' }))) return;
    db = seed(); save(); qb = null; drafts.customer = drafts.staff = null; verified.clear(); trackResult = null;
    if (typeof counterQ !== 'undefined') counterQ = ''; toast('Demo data reset.'); render();
  },
};

/* ---------- Pickup Box (the paper box, made digital) ---------- */
let boxStart = null;
function viewBox() {
  const t = todayISO();
  if (!boxStart) boxStart = t;
  const days = Array.from({ length: 14 }, (_, i) => addDays(boxStart, i));
  const day = (s) => {
    const list = db.orders.filter((o) => o.pickupDate === s && o.status !== 'declined').sort((a, b) => a.pickupTime.localeCompare(b.pickupTime));
    const closed = isSunday(s);
    return `<div class="box-day ${s === t ? 'today' : ''} ${closed && !list.length ? 'closed' : ''}"><h4>${fmtDay(s)} ${list.length ? `<a class="small" href="#print-${s}">sheet</a>` : ''}</h4>${loadMeter(s)}
      ${closed && !list.length ? '<div class="muted small">Closed</div>' : ''}
      ${list.map((o) => `<a class="mini" href="#staff-order-${o.id}"><b>${o.id} · ${esc(o.customer.name)}</b>${statusTag(o.status)} ${o.allergy ? '<span class="tag t-red">Allergy</span>' : ''}
        <div class="muted">${esc(specSummary(o)[0] || '')}</div></a>`).join('')}</div>`;
  };
  return `<div class="row" style="margin-bottom:12px"><a class="back" href="#staff">← All orders</a><span class="spacer"></span>
      <button class="btn-sm" onclick="boxStart=addDays(boxStart,-7);render()">← Earlier</button><button class="btn-sm" onclick="boxStart=todayISO();render()">Today</button><button class="btn-sm" onclick="boxStart=addDays(boxStart,7);render()">Later →</button></div>
    <div class="page-head" style="margin-top:12px"><div><div class="eyebrow">Next two weeks</div><h1>Pickup Box</h1></div></div>
    <p class="muted" style="margin-top:-8px">Every order, filed by pickup date, just like the box at the counter. Nothing here can be misfiled.</p>
    <div class="box-scroll"><div class="box-grid">${days.slice(0, 7).map(day).join('')}</div>
    <div class="box-grid">${days.slice(7).map(day).join('')}</div></div>`;
}

/* ---------- Rate card (owner sets every price) ---------- */
function viewRates() {
  const r = db.rates;
  const num = (id, v, step = 1) => `<input id="${id}" type="number" step="${step}" min="0" value="${v}">`;
  return `<div class="row" style="margin-bottom:12px"><a class="back" href="#staff">← All orders</a></div>
  <div class="page-head" style="margin-top:12px"><div><div class="eyebrow">Owner settings</div><h1>Rate card</h1></div></div><p class="muted">The owner sets every amount. Changes apply to new estimates and quotes; sent quotes keep their price.</p>
  <div class="grid2">
    <div class="card"><h3>Custom cakes</h3>
      <div class="field"><label>Base price per serving</label>${num('r-ps', r.perServing, 0.25)}</div>
      <div class="grid2" style="margin-top:14px"><div><label>Rush fee</label>${num('r-rf', r.rushFee)}</div><div><label>Rush if pickup within (days)</label>${num('r-rd', r.rushDays)}</div></div>
      <div class="field"><label>Deposit to start baking (%)</label>${num('r-dp', r.depositPct)}</div>
      <div class="field"><label>Kitchen capacity per day (decorating hours)</label>${num('r-cap', r.dailyCapacity || 10)}<div class="hint">A classic order counts 1, a custom cake its Design Score + 1, a showpiece 8.</div></div>
      <h3 style="margin-top:18px">Design Score fees</h3>
      ${[1, 2, 3, 4, 5].map((n) => `<div class="qty-row"><span>Score ${n}: ${DS_TEXT[n]}</span><span style="width:110px">${num('r-ds' + n, r.designScore[n])}</span></div>`).join('')}
    </div>
    <div class="card"><h3>Decorations</h3>
      ${r.addons.map((a, i) => `<div class="qty-row"><span>${esc(a.label)}</span><span style="width:110px">${num('r-ad' + i, a.price, 0.5)}</span></div>`).join('')}
      <h3 style="margin-top:18px">Classic menu</h3>
      ${r.menu.map((m, i) => `<div class="qty-row"><span>${esc(m.label)}</span><span style="width:110px">${num('r-mn' + i, m.price, 0.5)}</span></div>`).join('')}
      <h3 style="margin-top:18px">Filling upcharges</h3>
      ${r.fillings.map((f, i) => `<div class="qty-row"><span>${esc(f.name)}</span><span style="width:110px">${num('r-fi' + i, f.price, 0.5)}</span></div>`).join('')}
    </div>
  </div>
  <div class="row" style="margin-top:16px"><button class="btn-primary btn-big" onclick="R.save()">Save rate card</button><button onclick="R.defaults()">Restore example prices</button></div>`;
}
const R = {
  save() {
    const r = db.rates, v = (id) => Math.max(0, +$('#' + id).value || 0);
    r.perServing = v('r-ps'); r.rushFee = v('r-rf'); r.rushDays = Math.round(v('r-rd')); r.depositPct = Math.min(100, v('r-dp')); r.dailyCapacity = Math.max(1, Math.round(v('r-cap')));
    [1, 2, 3, 4, 5].forEach((n) => { r.designScore[n] = v('r-ds' + n); });
    r.addons.forEach((a, i) => { a.price = v('r-ad' + i); });
    r.menu.forEach((m, i) => { m.price = v('r-mn' + i); });
    r.fillings.forEach((f, i) => { f.price = v('r-fi' + i); });
    save(); toast('Rate card saved.');
  },
  async defaults() { if (await ask('Restore the example prices?', { ok: 'Restore' })) { db.rates = clone(DEFAULT_RATES); save(); render(); } },
};

/* ================= KITCHEN ================= */
let kRange = 'all';
function viewKitchen() {
  const t = todayISO();
  const inRange = (o) => kRange === 'all' || (kRange === 'today' ? o.pickupDate === t : o.pickupDate <= addDays(t, 2));
  const col = (status, title, btn) => {
    const list = db.orders.filter((o) => o.status === status && inRange(o)).sort((a, b) => a.pickupDate.localeCompare(b.pickupDate) || a.pickupTime.localeCompare(b.pickupTime));
    return `<div class="k-col"><h3>${title} <span class="tag t-gray">${list.length}</span></h3>
      ${list.map((o) => ticket(o, btn)).join('') || '<p class="muted small">Nothing here.</p>'}</div>`;
  };
  return `<div class="page-head"><div><div class="eyebrow">Kitchen · ${fmtDay(t)}</div><h1>Kitchen board</h1></div><span class="spacer"></span>
      ${['today', 'soon', 'all'].map((k) => `<button class="btn-sm ${kRange === k ? 'btn-primary' : ''}" onclick="kRange='${k}';render()">${{ today: 'Today', soon: 'Next 3 days', all: 'All' }[k]}</button>`).join('')}</div>
    <p class="muted">Only approved orders appear here, with the final approved instructions. If a price is revised, the order leaves this board until the customer approves again.</p>
    <div class="kitchen">${col('approved', 'To bake', ['Start baking', 'baking'])}${col('baking', 'Baking', ['Ready for pickup', 'ready'])}${col('ready', 'Ready for pickup', ['Picked up', 'picked_up'])}</div>`;
}
function ticket(o, [label, next]) {
  const q = approvedQuote(o);
  const staffNotes = o.messages.filter((m) => m.internal).slice(-1)[0];
  return `<div class="ticket lane-${o.lane}">
    <div class="row"><span class="tid">${o.id}</span><span class="spacer"></span>${laneTag(o.lane)}</div>
    <div class="when">${fmtDay(o.pickupDate)} · ${esc(o.pickupTime)}</div>
    <div class="muted small">${esc(o.customer.name)} · approved v${q ? q.v : '?'}${o.depositPaid ? ' · deposit ✓' : ''}</div>
    ${o.allergy ? `<div class="red-box small" style="margin-top:6px">ALLERGY: ${esc(o.allergy)}</div>` : ''}
    <ul>${specSummary(o).map((s) => `<li>${esc(s)}</li>`).join('')}${q && q.designScore ? `<li>Design Score ${q.designScore}: ${DS_TEXT[q.designScore]}</li>` : ''}</ul>
    ${o.description ? `<div class="small">“${esc(o.description)}”</div>` : ''}
    ${q && q.note ? `<div class="small" style="margin-top:4px"><b>Baker’s note:</b> ${esc(q.note)}</div>` : ''}
    ${staffNotes ? `<div class="small" style="margin-top:4px"><b>Internal:</b> ${esc(staffNotes.text)}</div>` : ''}
    ${o.lane !== 'green' ? `<div class="ticket-cake">${cakeSVG(o.lane, o.spec, { small: true })}</div>` : ''}
    ${o.photos[0] ? `<img src="${esc(o.photos[0])}" alt="Inspiration photo">` : ''}
    <div class="row" style="margin-top:10px"><button class="btn-primary btn-sm" onclick="K.move('${o.id}','${next}')">${label}</button><a class="btn btn-sm" href="#staff-order-${o.id}">Open</a></div>
  </div>`;
}
const K = {
  async move(id, s) {
    const o = getOrder(id);
    if (s === 'baking' && o.allergy && !(await ask(`Allergy on this order: “${o.allergy}”. Has a person confirmed it?`, { ok: 'Yes, start baking' }))) return;
    o.status = s; log(o, `Moved to ${STATUS[s][0]}`, 'Kitchen'); save(); render();
  },
};

/* ================= PRINTED PICKUP SHEET (paper is the backup) ================= */
function viewPrint(day) {
  const s = day || todayISO();
  const list = db.orders.filter((o) => o.pickupDate === s && o.status !== 'declined').sort((a, b) => a.pickupTime.localeCompare(b.pickupTime));
  return `<div class="row no-print" style="margin-bottom:12px"><a class="back" href="#staff">← All orders</a><span class="spacer"></span>
      <input type="date" value="${s}" style="width:auto" onchange="go('#print-'+this.value)"></div>
    <div class="card sheet"><h1>Bing’s Pickup Sheet · ${fmtDay(s)}</h1>
    <p class="small">Printed ${fmtTime(Date.now())} · ${list.length} order${list.length === 1 ? '' : 's'}. If the system is down, this sheet is today’s record. Write new orders on the back and enter them later.</p>
    ${list.length ? `<table><thead><tr><th>✓</th><th>Passport</th><th>Time</th><th>Customer</th><th>Order</th><th>Status</th><th>Total / deposit</th></tr></thead><tbody>
      ${list.map((o) => `<tr><td><span class="box"></span></td><td><b>${o.id}</b></td><td>${esc(o.pickupTime)}</td><td>${esc(o.customer.name)}<br>${esc(o.customer.phone)}</td>
        <td>${specSummary(o).map(esc).join('<br>')}${o.allergy ? `<br><b>ALLERGY: ${esc(o.allergy)}</b>` : ''}</td><td>${STATUS[o.status][0]}</td>
        <td>${orderTotal(o) != null ? money(orderTotal(o)) : 'not quoted'}<br>${o.depositPaid ? 'deposit paid' : 'no deposit'}</td></tr>`).join('')}
    </tbody></table>` : '<p>No pickups this day.</p>'}</div>`;
}

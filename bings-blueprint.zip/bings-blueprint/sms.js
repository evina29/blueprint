/* Bing's Blueprint: text message preview.
   Shows the exact texts a customer would get at each step. This prototype
   sends nothing; in the pilot a texting service (e.g. Twilio, about 1 cent
   per text) would send them automatically. */

const SMS_STAGES = ['received', 'quote_ready', 'approved', 'baking', 'ready', 'picked_up'];

function smsText(o, stage) {
  const first = (o.customer.name || '').split(' ')[0] || 'there';
  const q = latestQuote(o), aq = approvedQuote(o);
  const pickup = `${fmtDay(o.pickupDate)}, ${String(o.pickupTime).replace(/\s*\(.*\)/, '').toLowerCase()}`;
  const link = '[tracking link]';
  switch (stage) {
    case 'received':
      if (o.lane === 'green') return `Bing's Bakery: Thanks ${first}! Your order is confirmed: ${money(orderTotal(o) || 0)}, pickup ${pickup}. Cake Passport ${o.id}. ${link}`;
      return `Bing's Bakery: Thanks ${first}! We got your cake request. Cake Passport ${o.id}.${o.estimate ? ` Estimate ${money(o.estimate[0])}–${money(o.estimate[1])}.` : ''} A baker will send your quote by ${fmtTime(replyDue(o))}. ${link}`;
    case 'quote_ready':
      return `Your quote for ${o.id} is ready: ${q ? money(q.total) : ''}.${q && q.note ? ' The baker left you a note.' : ''} Review and approve: ${link}. Reply CALL to talk to a baker.`;
    case 'approved':
      return `Approved! ${o.id} is scheduled for ${pickup}.${aq && o.lane !== 'green' ? ` A ${db.rates.depositPct}% deposit (${money(aq.total * db.rates.depositPct / 100)}) starts the bake.` : ''}`;
    case 'baking':
      return `Your cake (${o.id}) is being made right now.`;
    case 'ready': {
      const tot = orderTotal(o) || 0, dep = o.depositPaid ? tot * db.rates.depositPct / 100 : 0;
      return `${o.id} is ready for pickup! Balance due ${money(tot - dep)}. See you soon.`;
    }
    case 'picked_up':
      return `Thanks for choosing Bing's, ${first}. Enjoy your cake!`;
    default:
      return '';
  }
}

function smsThread(o) {
  if (o.status === 'declined') return [smsText(o, 'received'), `We're sorry, we can't make ${o.id} as requested. The baker left you a message: [tracking link]`];
  const idx = TRACK_IDX[o.status];
  const texts = [];
  SMS_STAGES.forEach((st, i) => {
    if (o.lane === 'green' && (st === 'quote_ready' || st === 'approved')) return;
    if (i <= idx) texts.push(smsText(o, st));
  });
  return texts;
}

function phoneMock(o, opts = {}) {
  const texts = opts.first ? smsThread(o).slice(0, 1) : smsThread(o);
  return `<figure class="phone-wrap">
    <div class="phone" role="img" aria-label="Preview of the text messages the customer would receive">
      <div class="phone-top"><span class="phone-avatar">B</span><div><b>Bing's Bakery</b><span>Text message</span></div></div>
      <div class="phone-body">${texts.map((t) => `<p class="sms">${esc(t)}</p>`).join('')}</div>
    </div>
    <figcaption>Preview only. In the pilot, these texts send automatically (about 1¢ each). This prototype doesn’t send texts.</figcaption>
  </figure>`;
}

function smsCard(o) {
  return `<div class="card"><h3>Texts the customer gets</h3>${phoneMock(o)}</div>`;
}
